package main

import (
	"bytes"
	"encoding/hex"
	"errors"
	"fmt"
	"net"
	"strings"
	"time"

	"github.com/tebeka/strftime"
)

const (
	SSHTTP = "" +
		"HTTP/1.1 101 Switching Protocols\r\n" +
		"Server: nginx/1.18.0\r\n" +
		"Date: %s\r\n" +
		"Upgrade: websocket\r\n" +
		"Connection: Upgrade\r\n" +
		"Sec-WebSocket-Accept: %s\r\n" +
		"\r\n"

	SSRHTTP = "" +
		"HTTP/1.1 200 OK\r\n" +
		"Connection: keep-alive\r\n" +
		"Content-Encoding: gzip\r\n" +
		"Content-Type: text/html\r\n" +
		"Date: %s\r\n" +
		"Server: nginx\r\n" +
		"Vary: Accept-Encoding\r\n" +
		"\r\n"
)

var (
	SSRHTTPUA = []string{
		"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
		"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/44.0",
		"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36",
		"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Ubuntu/11.10 Chromium/27.0.1453.93 Chrome/27.0.1453.93 Safari/537.36",
		"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:35.0) Gecko/20100101 Firefox/35.0",
		"Mozilla/5.0 (compatible; WOW64; MSIE 10.0; Windows NT 6.2)",
		"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.20.25 (KHTML, like Gecko) Version/5.0.4 Safari/533.20.27",
		"Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.3; Trident/7.0; .NET4.0E; .NET4.0C)",
		"Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko",
		"Mozilla/5.0 (Linux; Android 4.4; Nexus 5 Build/BuildID) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36",
		"Mozilla/5.0 (iPad; CPU OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3",
		"Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3",
	}

	HTTPCRLF1 = []byte{0x0d, 0x0a}
	HTTPCRLF2 = []byte{0x0d, 0x0a, 0x0d, 0x0a}

	ErrDecodeHex  = errors.New("Decode Hex Failed")
	ErrFormatDate = errors.New("Format Date Failed")
)

type HTTP struct {
	net.Conn

	hasRecvHeader bool
	hasSentHeader bool

	HTTP   bool
	UUID   string
	Host   string
	Secret string

	buffer []byte
	offset int
}

func (h *HTTP) Read(data []byte) (int, error) {
	if h.buffer != nil {
		size := copy(data, h.buffer[h.offset:])
		h.offset += size

		if len(h.buffer) == h.offset {
			h.buffer = nil
			h.offset = 0
		}

		return size, nil
	}

	if !h.hasRecvHeader {
		buffer := make([]byte, 1024)
		length, err := h.Conn.Read(buffer)
		if err != nil {
			return 0, err
		}

		if !bytes.Contains(buffer[:length], HTTPCRLF2) {
			return 0, nil
		}

		h.hasRecvHeader = true

		SPL := bytes.SplitN(buffer[:length], HTTPCRLF2, 2)
		HDR := SplitHeader(SPL[0])

		h.HTTP = CheckHTTP(HDR)
		h.Host = GetHeader(HDR, "HOST")

		if strings.Contains(h.Host, ":") {
			if host, _, err := net.SplitHostPort(h.Host); err == nil {
				h.Host = host
			}
		}

		if h.HTTP {
			chunk, err := GetHTTP(GetHeader(HDR, "REQUEST"))
			if err != nil {
				return 0, ErrDecodeHex
			}

			SPL[1] = append(chunk, SPL[1]...)
		} else {
			h.Secret = GetHeader(HDR, "SEC-WEBSOCKET-KEY")
		}

		instanceContextMutex.Lock()
		instanceContext[h.UUID] = h.Host
		instanceContextMutex.Unlock()

		if len(SPL[1]) == 0 {
			if _, err = h.Write(nil); err != nil {
				return 0, err
			}

			length, err = h.Conn.Read(buffer)
			if err != nil {
				return 0, err
			}

			size := copy(data, buffer[:length])
			if length > size {
				h.buffer = buffer[:length]
				h.offset = size
			}

			return size, nil
		}

		size := copy(data, SPL[1])
		if len(SPL[1]) > size {
			h.buffer = SPL[1]
			h.offset = size
		}

		return size, nil
	}

	return h.Conn.Read(data)
}

func (h *HTTP) Write(data []byte) (int, error) {
	if !h.hasSentHeader {
		h.hasSentHeader = true

		date, err := strftime.Format("%a, %d %b %Y %H:%M:%S GMT", time.Now())
		if err != nil {
			return 0, ErrFormatDate
		}

		var buffer []byte
		if !h.HTTP {
			buffer = []byte(fmt.Sprintf(SSHTTP, date, h.Secret))
		} else {
			buffer = []byte(fmt.Sprintf(SSRHTTP, date))
		}

		if _, err = h.Conn.Write(append(buffer, data...)); err != nil {
			return 0, err
		}

		return len(data), nil
	}

	return h.Conn.Write(data)
}

func SplitHeader(data []byte) map[string]string {
	SPLB := bytes.Split(data, HTTPCRLF1)
	list := make(map[string]string)

	for i, v := range SPLB {
		text := string(v)

		if i == 0 {
			list["REQUEST"] = strings.TrimSpace(text)
			continue
		}

		if strings.Contains(text, ":") {
			SPL := strings.SplitN(text, ":", 2)

			list[strings.ToUpper(strings.TrimSpace(SPL[0]))] = strings.TrimSpace(SPL[1])
		}
	}

	return list
}

func CheckHeader(list map[string]string, name string) bool {
	_, ok := list[name]

	return ok
}

func GetHeader(list map[string]string, name string) string {
	if CheckHeader(list, name) {
		return list[name]
	}

	return ""
}

func CheckHTTP(list map[string]string) bool {
	if header := GetHeader(list, "USER-AGENT"); header != "" {
		for _, data := range SSRHTTPUA {
			if header == data {
				return true
			}
		}
	}

	return false
}

func GetHTTP(origin string) ([]byte, error) {
	splited := strings.Split(origin, "%")[1:]
	data := ""

	for _, value := range splited {
		if len(value) == 2 {
			data += value
		} else if len(value) > 2 {
			data += value[:2]
		}
	}

	return hex.DecodeString(data)
}

func newHTTP(conn net.Conn, uuid string) net.Conn {
	return &HTTP{Conn: conn, UUID: uuid}
}
