package main

import (
	"log"
	"net"
	"strconv"
	"sync"
	"time"

	"rixcloud.moe/shadowsocks/shadowsocks-sm-mod-mu-http/adns"
	"rixcloud.moe/shadowsocks/shadowsocks-sm-mod-mu-http/audit"
	"rixcloud.moe/shadowsocks/shadowsocks/socks"
)

func udpServe() {
	for {
		log.Printf("[UDP] %v", udpListen())

		time.Sleep(time.Second * 4)
	}
}

func udpListen() error {
	ln, err := net.ListenPacket("udp", net.JoinHostPort(flags.Bind, strconv.Itoa(flags.Port)))
	if err != nil {
		return err
	}
	ln = instanceCipher.PacketConn(ln)
	defer ln.Close()

	nm := NAT{m: make(map[string]net.PacketConn)}
	buffer := make([]byte, flags.UDPBufferSize)

	for {
		size, from, err := ln.ReadFrom(buffer)
		if err != nil {
			return err
		}

		if audit.UDPScan(from.String(), buffer[:size]) {
			continue
		}

		target := socks.SplitAddr(buffer[:size])
		if target == nil {
			continue
		}

		targetHost, targetPort, err := net.SplitHostPort(target.String())
		if err != nil {
			continue
		}

		targetAdtr, err := adns.FetchOne(targetHost)
		if err != nil {
			continue
		}

		targetAddr, err := net.ResolveUDPAddr("udp", net.JoinHostPort(targetAdtr.String(), targetPort))
		if err != nil {
			continue
		}

		conn := nm.Get(from.String())
		if conn == nil {
			addr := ""
			if flags.Dial != "" && targetAddr.IP.To4() != nil {
				addr = flags.Dial
			}

			conn, err = net.ListenPacket("udp", net.JoinHostPort(addr, ""))
			if err != nil {
				continue
			}

			log.Printf("[IN][0] New UDP connection from %s → %s", from, target)

			nm.Create(conn, ln, from)
		}

		if instanceBucket != nil {
			instanceBucket.Wait(int64(size))
		}

		_, _ = conn.WriteTo(buffer[len(target):size], targetAddr)
	}
}

func udpCopy(src, dst net.PacketConn, target net.Addr) {
	buffer := make([]byte, flags.UDPBufferSize)

	for {
		_ = src.SetReadDeadline(time.Now().Add(time.Second * time.Duration(flags.UDPTimeout)))
		size, from, err := src.ReadFrom(buffer)
		if err != nil {
			return
		}

		source := socks.ParseAddr(from.String())
		length := len(source) + size
		if length > flags.UDPBufferSize {
			continue
		}

		copy(buffer[len(source):], buffer[:size])
		copy(buffer, source)

		if instanceBucket != nil {
			instanceBucket.Wait(int64(size))
		}

		if _, err = dst.WriteTo(buffer[:length], target); err != nil {
			return
		}
	}
}

type NAT struct {
	sync.RWMutex

	m map[string]net.PacketConn
}

func (n *NAT) Get(id string) net.PacketConn {
	n.RLock()
	defer n.RUnlock()

	return n.m[id]
}

func (n *NAT) Set(id string, conn net.PacketConn) {
	n.Lock()
	defer n.Unlock()

	n.m[id] = conn
}

func (n *NAT) Create(src, dst net.PacketConn, target net.Addr) {
	n.Set(target.String(), src)

	go func() {
		udpCopy(src, dst, target)
		if conn := n.Delete(target.String()); conn != nil {
			conn.Close()
		}
	}()
}

func (n *NAT) Delete(id string) net.PacketConn {
	n.Lock()
	defer n.Unlock()

	conn, ok := n.m[id]
	if ok {
		delete(n.m, id)

		return conn
	}

	return nil
}
