package main

import (
	"io"
	"log"
	"net"
	"runtime"
	"strconv"
	"time"

	"github.com/juju/ratelimit"
	"rixcloud.moe/shadowsocks/shadowsocks-sm-v2raysock-mod-http/adns"
	"rixcloud.moe/shadowsocks/shadowsocks-sm-v2raysock-mod-http/alive"
	"rixcloud.moe/shadowsocks/shadowsocks-sm-v2raysock-mod-http/audit"
	"rixcloud.moe/shadowsocks/shadowsocks-sm-v2raysock-mod-http/tools"
	"rixcloud.moe/shadowsocks/shadowsocks/socks"

	reuse "github.com/libp2p/go-reuseport"
)

func tcpServe() {
	for i := 0; i < runtime.NumCPU(); i++ {
		go tcpListen()
	}
}

func tcpListen() {
	ln, err := reuse.Listen("tcp", net.JoinHostPort(flags.Bind, strconv.Itoa(flags.Port)))
	if err != nil {
		log.Fatalf("[TCP] %v", err)
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			if errno, ok := err.(net.Error); ok {
				if errno.Temporary() {
					continue
				}
			}

			log.Fatalf("[TCP] %v", err)
		}

		go tcpHandle(client)
	}
}

func tcpHandle(client net.Conn) {
	from := ""
	if flags.EnableTrueIP {
		trueip, err := socks.ReadAddr(client)
		if err != nil {
			client.Close()
			return
		}

		from = trueip.String()
	} else {
		from = client.RemoteAddr().String()
	}

	id := tools.Uuid()
	client = newHTTP(client, id)
	client = instanceCipher.StreamConn(client)
	defer client.Close()

	data := make([]byte, flags.TCPBufferSize)
	size, err := client.Read(data)
	if err != nil {
		return
	}

	instanceContextMutex.RLock()
	name, done := instanceContext[id]
	instanceContextMutex.RUnlock()

	if done {
		instanceContextMutex.Lock()
		delete(instanceContext, id)
		instanceContextMutex.Unlock()
	} else {
		return
	}

	instanceMutex.RLock()
	instance, checked := instanceList[name]
	instanceMutex.RUnlock()
	if !checked {
		return
	}

	target := socks.SplitAddr(data)
	if target == nil {
		return
	}

	targetHost, targetPort, err := net.SplitHostPort(target.String())
	if err != nil {
		return
	}

	if targetPort == "53" {
		targetHost = flags.DNSAddr
		targetPort = flags.DNSPort
	}

	if alive.Scan(instance.UserInfo.ID, from) {
		return
	}

	if audit.Scan(instance.UserInfo.ID, data[:size]) {
		return
	}

	adtr, err := adns.FetchOne(targetHost)
	if err != nil {
		return
	}

	dialer := net.Dialer{Timeout: time.Second * 10}
	if adtr.To4() != nil {
		if flags.Dial != "" {
			dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(flags.Dial)}
		} else if flags.SISO {
			addr, _, _ := net.SplitHostPort(client.LocalAddr().String())
			dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(addr)}
		}
	}

	remote, err := dialer.Dial("tcp", net.JoinHostPort(adtr.String(), targetPort))
	if err != nil {
		return
	}
	defer remote.Close()

	if _, err = remote.Write(data[len(target):size]); err != nil {
		return
	}
	data = nil

	log.Printf("[IN][%d] New TCP connection from %s → %s:%s", instance.UserInfo.ID, from, targetHost, targetPort)
	tcpRelay(instance, client, remote)
}

func tcpRelay(instance *Instance, client, remote net.Conn) {
	go func() {
		var reader io.Reader
		if instance.UPBucket != nil {
			reader = ratelimit.Reader(client, instance.UPBucket)
		} else {
			reader = client
		}

		size, _ := io.CopyBuffer(remote, reader, make([]byte, flags.TCPBufferSize))
		_ = client.SetDeadline(time.Now())
		_ = remote.SetDeadline(time.Now())
		instance.Bandwidth.IncreaseUP(int64(float64(size) * flags.UPExternalRate))
	}()

	var reader io.Reader
	if instance.DLBucket != nil {
		reader = ratelimit.Reader(remote, instance.DLBucket)
	} else {
		reader = remote
	}

	size, _ := io.CopyBuffer(client, reader, make([]byte, flags.TCPBufferSize))
	_ = client.SetDeadline(time.Now())
	_ = remote.SetDeadline(time.Now())
	instance.Bandwidth.IncreaseDL(int64(float64(size) * flags.DLExternalRate))
}
