package truev2

import (
	"net"

	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

type Conn struct {
	net.Conn

	target socks.Addr
	buffer []byte
}

func NewConn(client net.Conn, target socks.Addr) net.Conn {
	return &Conn{Conn: client, target: target}
}

func (o *Conn) Read(data []byte) (int, error) {
	return o.Conn.Read(data)
}

func (o *Conn) Write(data []byte) (int, error) {
	length := len(o.target) + len(data)
	if len(o.buffer) < length {
		o.buffer = make([]byte, length)
		copy(o.buffer[0:], o.target)
	}

	copy(o.buffer[len(o.target):], data)
	if _, err := o.Conn.Write(o.buffer[:length]); err != nil {
		return 0, err
	}

	return len(data), nil
}
