package ace

import (
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"os"
	"time"

	"google.golang.org/protobuf/proto"
)

var (
	ciph cipher.AEAD
	zero []byte
)

func init() {
	token := []byte{
		0xa3, 0xc8, 0x48, 0xc5, 0x36, 0xb4, 0x25, 0x28,
		0x1b, 0x34, 0x18, 0xda, 0xb2, 0xb9, 0x20, 0x1b,
		0x4e, 0xe6, 0xcf, 0x76, 0xd8, 0xbb, 0x43, 0x86,
		0xc9, 0xe3, 0x0c, 0x4f, 0xd7, 0x2c, 0x3a, 0x88,
	}
	nonce := []byte{
		0xba, 0x88, 0x13, 0x47, 0x7b, 0x72, 0x90, 0x24,
		0x38, 0x2f, 0x43, 0x6b, 0x1d, 0xee, 0x1e, 0xd7,
		0xf6, 0x11, 0x3e, 0xab, 0x8b, 0xf2, 0xf4, 0xff,
		0x3b, 0x6f, 0x4e, 0x92, 0xdc, 0x27, 0x27, 0x2b,
	}

	if cstr := os.Getenv("CUOCUO_ENCRYPTION_TOKEN"); cstr != "" {
		if data, err := base64.StdEncoding.DecodeString(cstr); err == nil {
			if len(data) >= 32 {
				copy(token, data)
			}
		}
	}

	if cstr := os.Getenv("CUOCUO_ENCRYPTION_NONCE"); cstr != "" {
		if data, err := base64.StdEncoding.DecodeString(cstr); err == nil {
			if len(data) >= 32 {
				copy(nonce, data)
			}
		}
	}

	zero = make([]byte, len(nonce))
	copy(zero, nonce)

	aesc, _ := aes.NewCipher(token)
	ciph, _ = cipher.NewGCM(aesc)
}

func SendRequestHeader(client net.Conn, message *RequestHeader) error {
	data, err := proto.Marshal(message)
	if err != nil {
		return fmt.Errorf("proto.Marshal: %v", err)
	}

	buffer := make([]byte, 2+ciph.Overhead()+len(data)+ciph.Overhead())
	binary.LittleEndian.PutUint16(buffer[:2], uint16(len(data)))
	ciph.Seal(buffer[:0], zero[:ciph.NonceSize()], buffer[:2], nil)
	copy(buffer[2+ciph.Overhead():], data)
	ciph.Seal(buffer[2+ciph.Overhead():2+ciph.Overhead()], zero[:ciph.NonceSize()], buffer[2+ciph.Overhead():2+ciph.Overhead()+len(data)], nil)

	if _, err = client.Write(buffer); err != nil {
		return fmt.Errorf("client.Write: %v", err)
	}

	return nil
}

func ReadRequestLength(client net.Conn) (int, error) {
	buffer := make([]byte, 2+ciph.Overhead())
	if _, err := io.ReadFull(client, buffer); err != nil {
		return 0, fmt.Errorf("io.ReadFull: %v", err)
	}

	ciph.Open(buffer[:0], zero[:ciph.NonceSize()], buffer, nil)
	return int(binary.LittleEndian.Uint16(buffer[:2])), nil
}

func ReadRequestHeader(client net.Conn) (*RequestHeader, error) {
	length, err := ReadRequestLength(client)
	if err != nil {
		return nil, fmt.Errorf("ace.ReadRequestLength: %v", err)
	}

	buffer := make([]byte, length+ciph.Overhead())
	if _, err = io.ReadFull(client, buffer); err != nil {
		return nil, fmt.Errorf("io.ReadFull: %v", err)
	}

	if _, err = ciph.Open(buffer[:0], zero[:ciph.NonceSize()], buffer, nil); err != nil {
		return nil, fmt.Errorf("ciph.Open: %v", err)
	}

	message := &RequestHeader{}
	if err := proto.Unmarshal(buffer[:length], message); err != nil {
		return nil, fmt.Errorf("proto.Unmarshal: %v", err)
	}

	return message, nil
}

func (o *RequestHeader) Validate() bool {
	date := time.Now().Unix()

	return 1679681918-date > 0 && max(o.Unix, date)-min(o.Unix, date) < 10
}

func max(a, b int64) int64 {
	if a > b {
		return a
	}

	return b
}

func min(a, b int64) int64 {
	if a > b {
		return b
	}

	return a
}
