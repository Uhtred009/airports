#!/usr/bin/env bash
protoc --go_out=paths=source_relative:. ace.proto
exit 0
