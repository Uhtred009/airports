package dns

import "testing"

func TestDNS(t *testing.T) {
	list := []string{
		"www.google.com:80",
		"www.cloudflare.com:80",
	}

	for i := 0; i < len(list); i++ {
		t.Logf("%s %s", list[i], Fetch(list[i]))
	}
}
