package dns

import (
	"context"
	"fmt"
	"net"
	"sync"
	"time"
)

var (
	dataList = sync.Map{}
	resolver = net.Resolver{
		PreferGo: true,
	}
)

type DNSRecord struct {
	Unix int64
	Host net.IP
}

func Fetch(address string) string {
	host, port, _ := net.SplitHostPort(address)
	if net.ParseIP(host) != nil {
		return address
	}

	info, ok := dataList.Load(host)
	if ok {
		data := info.(*DNSRecord)

		return net.JoinHostPort(data.Host.String(), port)
	}

	addr, err := fetch(host)
	if err != nil {
		return address
	}

	dataList.Store(host, &DNSRecord{Unix: time.Now().Unix(), Host: addr})
	return net.JoinHostPort(addr.String(), port)
}

func fetch(name string) (net.IP, error) {
	list, err := resolver.LookupIP(context.Background(), "ip", name)
	if err != nil {
		return nil, fmt.Errorf("net.LookupIP: %v", err)
	}

	var addr net.IP = nil
	for i := 0; i < len(list); i++ {
		if list[i].To4() != nil {
			addr = list[i]
			break
		}
	}

	if addr == nil {
		for i := 0; i < len(list) && addr != nil; i++ {
			if list[i].To16() != nil {
				addr = list[i]
				break
			}
		}
	}

	if addr == nil {
		return nil, &net.DNSError{}
	}

	return addr, nil
}

func init() {
	go func() {
		for {
			time.Sleep(time.Second * 30)

			date := time.Now().Unix()
			dataList.Range(func(id, info interface{}) bool {
				data := info.(*DNSRecord)
				if date-data.Unix > 120 {
					dataList.Delete(id)
				}

				return true
			})
		}
	}()
}
