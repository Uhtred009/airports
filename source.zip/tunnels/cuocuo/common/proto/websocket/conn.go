package websocket

import (
	"io"
	"net"
	"time"

	ws "github.com/gorilla/websocket"
)

type Conn struct {
	*ws.Conn

	buffer []byte
	offset int
}

func NewConn(conn *ws.Conn) net.Conn {
	return &Conn{
		Conn: conn,
	}
}

func (o *Conn) Read(data []byte) (int, error) {
	if o.buffer != nil {
		size := copy(data, o.buffer[o.offset:])
		o.offset += size

		if len(o.buffer) <= o.offset {
			o.buffer = nil
			o.offset = 0
		}

		return size, nil
	}

	message, buffer, err := o.Conn.ReadMessage()
	if err != nil {
		return 0, err
	}

	if message != ws.BinaryMessage {
		return 0, io.EOF
	}

	size := copy(data, buffer)
	if len(buffer) > size {
		o.buffer = buffer
		o.offset = size
	}
	return size, nil
}

func (o *Conn) Write(data []byte) (int, error) {
	if err := o.Conn.WriteMessage(ws.BinaryMessage, data); err != nil {
		return 0, err
	}

	return len(data), nil
}

func (o *Conn) SetDeadline(t time.Time) error {
	o.SetReadDeadline(t)
	o.SetWriteDeadline(t)

	return nil
}
