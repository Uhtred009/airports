package faketls

import "net"

type Conn struct {
	net.Conn
}

func NewConn(conn net.Conn) net.Conn {
	return &Conn{
		Conn: conn,
	}
}
