package obs

import (
	"sync"
	"time"

	"github.com/google/uuid"
	"ryzen.moe/tunnels/cuocuo/structs"
)

type Fallback struct {
	sync.RWMutex

	id     string
	buffer structs.NextList
	canuse structs.NextList
}

func NewFallback(list structs.NextList) structs.Open {
	data := &Fallback{
		id:     uuid.NewString(),
		buffer: list,
		canuse: structs.NextList{list[0]},
	}
	go data.run()

	return data
}

func (o *Fallback) run() {
	for {
		time.Sleep(time.Second * 30)

		for i := 0; i < len(o.buffer); i++ {
			if TestNext(o.buffer[0]) {
				if o.buffer[i].GetID() != o.canuse[0].GetID() {
					o.Lock()
					o.canuse[0] = o.buffer[i]
					o.Unlock()
				}

				break
			}
		}
	}
}

func (o *Fallback) GetID() string {
	return o.id
}

func (o *Fallback) GetNext() *structs.Next {
	o.RLock()
	defer o.RUnlock()

	return o.canuse[0]
}

func (o *Fallback) GetNextList() structs.NextList {
	o.RLock()
	defer o.RUnlock()

	return o.canuse
}
