package obs

import (
	"ryzen.moe/tunnels/cuocuo/outbound"
	"ryzen.moe/tunnels/cuocuo/structs"
)

func NewOBS(name string, list structs.NextList) structs.Open {
	switch name {
	case "automatic":
		return NewAutomatic(list)
	case "fallback":
		return NewFallback(list)
	default:
		return NewDefault(list)
	}
}

func TestNext(n *structs.Next) bool {
	client, err := outbound.Dial(n)
	if err != nil {
		return false
	}
	client.Close()

	return true
}

func TestNextList(list structs.NextList) structs.NextList {
	data := make(structs.NextList, 0)
	channel := make(chan *structs.Next, len(list))

	for i := 0; i < len(list); i++ {
		go func(n *structs.Next) {
			if TestNext(n) {
				channel <- n
			}

			channel <- nil
		}(list[i])
	}

	for i := 0; i < len(list); i++ {
		n := <-channel
		if n != nil {
			data = append(data, n)
		}
	}

	return data
}
