package obs

import (
	"sync"

	"github.com/google/uuid"
	"ryzen.moe/tunnels/cuocuo/structs"
)

type Default struct {
	sync.Mutex

	id     string
	buffer structs.NextList
	offset int
}

func NewDefault(list structs.NextList) structs.Open {
	data := &Default{
		id:     uuid.NewString(),
		buffer: list,
		offset: 0,
	}

	return data
}

func (o *Default) GetID() string {
	return o.id
}

func (o *Default) GetNext() *structs.Next {
	o.Lock()
	defer o.Unlock()

	o.offset += 1
	if len(o.buffer) <= o.offset {
		o.offset = 0
	}

	return o.buffer[o.offset]
}

func (o *Default) GetNextList() structs.NextList {
	return o.buffer
}
