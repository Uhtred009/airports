package obs

import (
	"sync"
	"time"

	"github.com/google/uuid"
	"ryzen.moe/tunnels/cuocuo/structs"
)

type Automatic struct {
	sync.Mutex

	id     string
	buffer structs.NextList
	canuse structs.NextList
	offset int
}

func NewAutomatic(list structs.NextList) structs.Open {
	data := &Automatic{
		id:     uuid.NewString(),
		buffer: list,
		canuse: list,
		offset: 0,
	}
	go data.run()

	return data
}

func (o *Automatic) run() {
	for {
		time.Sleep(time.Second * 30)

		list := TestNextList(o.buffer)

		o.Lock()
		o.canuse = list
		o.Unlock()
	}
}

func (o *Automatic) GetID() string {
	return o.id
}

func (o *Automatic) GetNext() *structs.Next {
	o.Lock()
	defer o.Unlock()

	if len(o.canuse) == 0 {
		return o.buffer[0]
	}

	o.offset += 1
	if len(o.canuse) <= o.offset {
		o.offset = 0
	}

	return o.canuse[o.offset]
}

func (o *Automatic) GetNextList() structs.NextList {
	o.Lock()
	defer o.Unlock()

	return o.canuse
}
