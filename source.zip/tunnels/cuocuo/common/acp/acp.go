package acp

import (
	"net"
	"sync"
	"time"

	"ryzen.moe/tunnels/cuocuo/common/dns"
)

const (
	minconn int           = 10
	maxidle int64         = 10
	intervl time.Duration = time.Millisecond * 200
)

var (
	mtx sync.Mutex
	mux = &sync.Map{}

	defaultDialer = &net.Dialer{
		Timeout:   time.Second * 3,
		KeepAlive: time.Second * 9,
	}
)

type idleConn struct {
	net.Conn

	Unix int64
}

type Pool struct {
	sync.RWMutex

	channel chan *idleConn
	newConn func() (net.Conn, error)
}

func (s *Pool) Get() (net.Conn, error) {
	date := time.Now().Unix()

	s.RLock()
	for {
		select {
		case idle := <-s.channel:
			if date-idle.Unix > maxidle {
				idle.Close()
				continue
			}

			s.RUnlock()
			return idle.Conn, nil
		default:
			s.RUnlock()
			return s.newConn()
		}
	}
}

func (s *Pool) Run() {
	wg := &sync.WaitGroup{}

	for {
		s.Lock()
		size := minconn - len(s.channel)
		if size <= 0 {
			s.Unlock()

			time.Sleep(intervl)
			continue
		}
		s.Unlock()

		wg.Add(size)
		for i := 0; i < size; i++ {
			go func() {
				conn, err := s.newConn()
				if err != nil {
					wg.Done()
					return
				}

				s.channel <- &idleConn{Conn: conn, Unix: time.Now().Unix()}
				wg.Done()
			}()
		}
		wg.Wait()
	}
}

func NewPool(create func() (net.Conn, error)) *Pool {
	haveged := &Pool{
		channel: make(chan *idleConn, minconn),
		newConn: create,
	}
	go haveged.Run()

	return haveged
}

func Dial(address string) (net.Conn, error) {
	mtx.Lock()
	dialer, ok := mux.Load(address)
	if !ok {
		dialer = NewPool(func() (net.Conn, error) {
			return defaultDialer.Dial("tcp", dns.Fetch(address))
		})

		mux.Store(address, dialer)
	}
	mtx.Unlock()

	return dialer.(*Pool).Get()
}
