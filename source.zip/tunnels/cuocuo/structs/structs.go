package structs

import (
	"crypto/tls"
	"net"
	"net/http"

	"github.com/google/uuid"
	"ryzen.moe/tunnels/cuocuo/tools"
)

type Open interface {
	GetID() string
	GetNext() *Next
	GetNextList() NextList
}

type Next struct {
	id string `json:"-"`

	ID     string `json:"id"`
	Type   string `json:"type"`
	Dialer string `json:"dialer"`
	Listen string `json:"listen"`
	Remote string `json:"remote"`
	Option string `json:"option"`

	// Dialer
	Binder net.IP `json:"-"`

	// Premium
	Premium    bool `json:"-"`
	PremiumTLS bool `json:"-"`

	// TLS
	Crt       string      `json:"-"`
	Sec       string      `json:"-"`
	Insecure  bool        `json:"-"`
	TLSConfig *tls.Config `json:"-"`

	// TLS + WebSocket
	Host string `json:"-"`

	// WebSocket
	Path string `json:"-"`

	// Fake HTTP + WebSocket
	Header http.Header `json:"-"`
}
type NextList []*Next

func (o *Next) Create() {
	o.id = uuid.NewString()
	o.Binder = net.ParseIP(o.Dialer)
	o.Header = http.Header{}

	list := tools.ParseList(o.Option)

	if tools.GetFromList(list, "Premium") == "1" {
		o.Premium = true

		delete(list, "Premium")
	}

	if tools.GetFromList(list, "PremiumTLS") == "1" {
		o.PremiumTLS = true

		delete(list, "PremiumTLS")
	}

	if tools.GetFromList(list, "Crt") != "" {
		o.Crt = tools.GetFromList(list, "Crt")

		delete(list, "Crt")
	}

	if tools.GetFromList(list, "Sec") != "" {
		o.Sec = tools.GetFromList(list, "Sec")

		delete(list, "Sec")
	}

	if tools.GetFromList(list, "Insecure") == "1" {
		o.Insecure = true

		delete(list, "Insecure")
	}

	if tools.GetFromList(list, "Host") != "" {
		o.Host = tools.GetFromList(list, "Host")
		o.Header.Set("Host", o.Host)

		delete(list, "Host")
	}

	if tools.GetFromList(list, "Path") != "" {
		o.Path = tools.GetFromList(list, "Path")

		delete(list, "Path")
	}

	for name, data := range list {
		o.Header.Set(name, data)
	}
}

func (o *Next) GetID() string {
	return o.id
}

func (o *Next) GetNext() *Next {
	return o
}

func (o *Next) GetNextList() NextList {
	return NextList{o}
}

type Fuck struct {
	id string `json:"-"`

	ID   string   `json:"id"`
	Next []string `json:"next"`
	Mode string   `json:"mode"`

	Dial Open     `json:"-"`
	List NextList `json:"-"`
}
type FuckList []*Fuck

func (o *Fuck) Create(list NextList) {
	o.id = uuid.NewString()

	o.List = make(NextList, 0)
	for i := 0; i < len(o.Next); i++ {
		for x := 0; x < len(list); x++ {
			if o.Next[i] == list[x].ID {
				o.List = append(o.List, list[x])
			}
		}
	}
}

func (o *Fuck) GetID() string {
	return o.id
}

func (o *Fuck) GetNext() *Next {
	return o.Dial.GetNext()
}

func (o *Fuck) GetNextList() NextList {
	return o.Dial.GetNextList()
}

type Rule struct {
	Dialer     string `json:"dialer"`
	ListenAddr string `json:"listen_addr"`
	ListenPort string `json:"listen_port"`
	RemoteAddr string `json:"remote_addr"`
	RemotePort string `json:"remote_port"`
	TrueIP     bool   `json:"trueip"`
	TrueV2     bool   `json:"truev2"`
	ProxyP     bool   `json:"proxyp"`
	Mode       string `json:"mode"`
	Opts       string `json:"opts"`

	Dial Open `json:"-"`
}
type RuleList []*Rule

func (o *Rule) GetNext() *Next {
	return o.Dial.GetNext()
}
