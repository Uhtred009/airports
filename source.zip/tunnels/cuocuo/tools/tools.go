package tools

import (
	"fmt"
	"net"
	"strings"

	"inet.af/netaddr"
)

func GetAddrList() ([]net.IP, error) {
	list := make([]net.IP, 0)

	adap, err := net.Interfaces()
	if err != nil {
		return nil, fmt.Errorf("net.Interfaces: %v", err)
	}

	for i := 0; i < len(adap); i++ {
		adtr, err := adap[i].Addrs()
		if err != nil {
			continue
		}

		for x := 0; x < len(adtr); x++ {
			var addr net.IP

			switch v := adtr[x].(type) {
			case *net.IPNet:
				addr = v.IP
			case *net.IPAddr:
				addr = v.IP
			}

			ipar, ok := netaddr.FromStdIP(addr)
			if !ok {
				continue
			}

			if ipar.IsGlobalUnicast() {
				list = append(list, addr)
			}
		}
	}

	return list, nil
}

func GetAddrListByName(name string) ([]net.IP, error) {
	list := make([]net.IP, 0)

	adap, err := net.InterfaceByName(name)
	if err != nil {
		return nil, fmt.Errorf("net.Interfaces: %v", err)
	}

	adtr, err := adap.Addrs()
	if err != nil {
		return nil, fmt.Errorf("adap.Addrs: %v", err)
	}

	for x := 0; x < len(adtr); x++ {
		var addr net.IP

		switch v := adtr[x].(type) {
		case *net.IPNet:
			addr = v.IP
		case *net.IPAddr:
			addr = v.IP
		}

		ipar, ok := netaddr.FromStdIP(addr)
		if !ok {
			continue
		}

		if ipar.IsGlobalUnicast() {
			list = append(list, addr)
		}
	}

	return list, nil
}

func ParseList(buffer string) map[string]string {
	list := make(map[string]string)

	{
		cstr := strings.Split(buffer, ";")
		for i := 0; i < len(cstr); i++ {
			data := strings.SplitN(cstr[i], "=", 2)
			if len(data) != 2 {
				continue
			}

			list[data[0]] = data[1]
		}
	}

	return list
}

func GetFromList(list map[string]string, name string) string {
	data, ok := list[name]
	if !ok {
		return ""
	}

	return data
}
