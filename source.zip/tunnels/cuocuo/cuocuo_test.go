package cuocuo

import (
	"crypto/rand"
	"fmt"
	"testing"
	"time"
)

func TestUnix(t *testing.T) {
	t.Log(time.Now().AddDate(0, 6, 0).Unix())
}

func TestRand(t *testing.T) {
	buffer := make([]byte, 32)
	rand.Read(buffer)

	str := ""
	for i := 0; i < len(buffer); i++ {
		if i%8 == 0 {
			str += "\n"
		}

		str += fmt.Sprintf("0x%02x, ", buffer[i])
	}

	t.Log(str)
}
