package main

import (
	"fmt"
	"io"
	"log"
	"net"
	"time"

	"github.com/pires/go-proxyproto"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
	"ryzen.moe/tunnels/cuocuo/common/ace"
	"ryzen.moe/tunnels/cuocuo/common/acp"
	"ryzen.moe/tunnels/cuocuo/common/dns"
	"ryzen.moe/tunnels/cuocuo/inbound"
	"ryzen.moe/tunnels/cuocuo/structs"
)

func tcpServe(n *structs.Next) {
	go func() {
		for {
			log.Printf("[TCP][%s] %v", n.Listen, tcpListen(n))

			time.Sleep(time.Second * 3)
		}
	}()
}

func tcpListen(n *structs.Next) error {
	ln, err := inbound.Listen(n)
	if err != nil {
		return fmt.Errorf("inbound.Listen: %v", err)
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			return fmt.Errorf("ln.Accept: %v", err)
		}

		go tcpHandle(n, client)
	}
}

func tcpHandle(n *structs.Next, client net.Conn) {
	defer client.Close()

	r, err := ace.ReadRequestHeader(client)
	if err != nil {
		return
	}

	if !r.Validate() {
		return
	}

	if r.Type == ace.C_UDP {
		udpHandle(n, r, client)
		return
	}

	var remote net.Conn
	if !n.Premium {
		dialer := net.Dialer{
			Timeout:   time.Second * 3,
			KeepAlive: time.Second * 9,
		}
		if n.Binder != nil {
			dialer.LocalAddr = &net.TCPAddr{IP: n.Binder}
		}

		remote, err = dialer.Dial("tcp", dns.Fetch(r.Next))
	} else {
		remote, err = acp.Dial(r.Next)
	}
	if err != nil {
		return
	}
	defer remote.Close()

	if r.TrueIP {
		if _, err = remote.Write(socks.ParseAddr(r.From)); err != nil {
			return
		}
	}

	if r.ProxyP {
		fromaddr, err := net.ResolveTCPAddr("tcp", r.From)
		if err != nil {
			return
		}

		nextaddr, err := net.ResolveTCPAddr("tcp", remote.RemoteAddr().String())
		if err != nil {
			return
		}

		if _, err = proxyproto.HeaderProxyFromAddrs(2, fromaddr, nextaddr).WriteTo(remote); err != nil {
			return
		}
	}

	if len(r.Data) > 0 {
		if _, err = remote.Write(r.Data); err != nil {
			return
		}
	}

	log.Printf("[TCP][%s] %s - %s - %s", n.Listen, r.From, client.RemoteAddr(), r.Next)

	go func() {
		io.CopyBuffer(client, remote, make([]byte, 1024))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
	}()

	io.CopyBuffer(remote, client, make([]byte, 1024))
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
}
