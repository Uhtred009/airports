package main

import (
	"encoding/binary"
	"io"
	"log"
	"net"
	"time"

	"ryzen.moe/shadowsocks/shadowsocks/socks"
	"ryzen.moe/tunnels/cuocuo/common/ace"
	"ryzen.moe/tunnels/cuocuo/common/truev2"
	"ryzen.moe/tunnels/cuocuo/structs"
)

func udpHandle(n *structs.Next, r *ace.RequestHeader, client net.Conn) {
	client = NewUDPConn(client)

	dialer := net.Dialer{
		Timeout:   time.Second * 3,
		KeepAlive: time.Second * 9,
	}
	if n.Binder != nil {
		dialer.LocalAddr = &net.UDPAddr{IP: n.Binder}
	}

	remote, err := dialer.Dial("udp", r.Next)
	if err != nil {
		return
	}
	if r.TrueV2 {
		remote = truev2.NewConn(remote, socks.ParseAddr(r.From))
	}
	defer remote.Close()

	if len(r.Data) > 0 {
		if _, err = remote.Write(r.Data); err != nil {
			return
		}
	}

	log.Printf("[UDP][%s] %s - %s - %s", n.Listen, r.From, client.RemoteAddr(), r.Next)

	go func() {
		io.CopyBuffer(client, remote, make([]byte, 1024))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
	}()

	io.CopyBuffer(remote, client, make([]byte, 1024))
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
}

type UDPConn struct {
	net.Conn

	rbuffer []byte
	wbuffer []byte
}

func NewUDPConn(client net.Conn) net.Conn {
	return &UDPConn{
		Conn: client,
	}
}

func (o *UDPConn) ExtendReadBuffer(length int) {
	if len(o.rbuffer) < length {
		o.rbuffer = make([]byte, length)
	}
}

func (o *UDPConn) ExtendSendBuffer(length int) {
	if len(o.wbuffer) < length {
		o.wbuffer = make([]byte, length)
	}
}

func (o *UDPConn) Read(data []byte) (int, error) {
	o.ExtendReadBuffer(2)
	if _, err := io.ReadFull(o.Conn, o.rbuffer[:2]); err != nil {
		return 0, err
	}

	length := int(binary.LittleEndian.Uint16(o.rbuffer[:2]))

	o.ExtendReadBuffer(length)
	if _, err := io.ReadFull(o.Conn, o.rbuffer[:length]); err != nil {
		return 0, err
	}

	return copy(data, o.rbuffer[:length]), nil
}

func (o *UDPConn) Write(data []byte) (int, error) {
	o.ExtendSendBuffer(2 + len(data))
	binary.LittleEndian.PutUint16(o.wbuffer[:2], uint16(len(data)))
	copy(o.wbuffer[2:], data)

	if _, err := o.Conn.Write(o.wbuffer[:2+len(data)]); err != nil {
		return 0, err
	}

	return len(data), nil
}
