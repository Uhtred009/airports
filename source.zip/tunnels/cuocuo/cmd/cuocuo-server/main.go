package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net"
	"os"
	"runtime"
	"strings"
	"time"

	"ryzen.moe/tunnels/cuocuo/structs"
	"ryzen.moe/tunnels/cuocuo/tools"
)

var (
	flags struct {
		Path    string
		VerCode bool
	}

	dataConf structs.NextList
)

func init() {
	flag.StringVar(&flags.Path, "c", "/etc/cuocuo-server/default.json", "Path")
	flag.BoolVar(&flags.VerCode, "v", false, "VerCode")
	flag.Parse()
}

func main() {
	if flags.VerCode {
		fmt.Println("Premium Tunnel for Public Internet v4.0.12")
		return
	}

	if err := nero(); err != nil {
		log.Fatalf("[cuocuo] %v", err)
		return
	}

	go func() {
		zone := time.FixedZone("Asia/Shanghai", int((time.Hour * 8).Seconds()))
		date, err := time.ParseInLocation("2006-01-02", time.Now().In(zone).Format("2006-01-02"), zone)
		if err != nil {
			return
		}

		diff := date.AddDate(0, 0, 1).Add(time.Hour * 4).Add(time.Minute * 10).Sub(time.Now().In(zone))
		log.Printf("[REBOOT] Scheduled after %s", diff)

		time.Sleep(diff)
		time.Sleep(time.Second * time.Duration(rand.Intn(300)))
		os.Exit(0)
	}()

	for i := 0; i < len(dataConf); i++ {
		tcpServe(dataConf[i])
	}

	for {
		time.Sleep(time.Minute * 30)

		runtime.GC()

		stats := runtime.MemStats{}
		runtime.ReadMemStats(&stats)
		log.Printf("[GC] Fraction %f", stats.GCCPUFraction)
		log.Printf("[GC] Obtained %dMB", stats.Sys/1024/1024)
		log.Printf("[GC] Assigned %dMB", stats.Alloc/1024/1024)
		log.Printf("[GC] Routine %d", runtime.NumGoroutine())
	}
}

func nero() error {
	m := make(structs.NextList, 0)

	{
		b, err := ioutil.ReadFile(flags.Path)
		if err != nil {
			return fmt.Errorf("ioutil.ReadFile: %v", err)
		}

		if err = json.Unmarshal(b, &m); err != nil {
			return fmt.Errorf("json.Unmarshal: %v", err)
		}
	}

	list := make(structs.NextList, 0)
	for i := 0; i < len(m); i++ {
		if m[i].Listen == "" {
			addrs, err := tools.GetAddrList()
			if err != nil {
				return fmt.Errorf("tools.GetAddrList: %v", err)
			}

			for _, addr := range addrs {
				list = append(list, &structs.Next{
					ID:     m[i].ID,
					Type:   m[i].Type,
					Dialer: m[i].Dialer,
					Listen: net.JoinHostPort(addr.String(), m[i].Remote),
					Option: m[i].Option,
				})
			}

			continue
		}

		if strings.Contains(m[i].Listen, ",") {
			names := strings.Split(m[i].Listen, ",")
			for _, name := range names {
				if addr := net.ParseIP(name); addr != nil {
					list = append(list, &structs.Next{
						ID:     m[i].ID,
						Type:   m[i].Type,
						Dialer: m[i].Dialer,
						Listen: net.JoinHostPort(addr.String(), m[i].Remote),
						Option: m[i].Option,
					})

					continue
				}

				addrs, err := tools.GetAddrListByName(name)
				if err != nil {
					return fmt.Errorf("tools.GetAddrListByName: %v", err)
				}

				for _, addr := range addrs {
					list = append(list, &structs.Next{
						ID:     m[i].ID,
						Type:   m[i].Type,
						Dialer: m[i].Dialer,
						Listen: net.JoinHostPort(addr.String(), m[i].Remote),
						Option: m[i].Option,
					})
				}
			}

			continue
		}

		if net.ParseIP(m[i].Listen) != nil {
			list = append(list, &structs.Next{
				ID:     m[i].ID,
				Type:   m[i].Type,
				Dialer: m[i].Dialer,
				Listen: net.JoinHostPort(m[i].Listen, m[i].Remote),
				Option: m[i].Option,
			})
		} else {
			addrs, err := tools.GetAddrListByName(m[i].Listen)
			if err != nil {
				return fmt.Errorf("tools.GetAddrListByName: %v", err)
			}

			for _, addr := range addrs {
				list = append(list, &structs.Next{
					ID:     m[i].ID,
					Type:   m[i].Type,
					Dialer: m[i].Dialer,
					Listen: net.JoinHostPort(addr.String(), m[i].Remote),
					Option: m[i].Option,
				})
			}
		}
	}

	for i := 0; i < len(list); i++ {
		list[i].Create()
	}

	dataConf = list
	return nil
}
