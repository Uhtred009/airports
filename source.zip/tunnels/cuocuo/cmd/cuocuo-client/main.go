package main

import (
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net"
	"os"
	"runtime"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/chacha20poly1305"
	"ryzen.moe/tunnels/cuocuo/common/obs"
	"ryzen.moe/tunnels/cuocuo/structs"
	"ryzen.moe/tunnels/cuocuo/tools"
)

type Config struct {
	Next structs.NextList `json:"nexts"`
	Fuck structs.FuckList `json:"fucks"`
	Rule structs.RuleList `json:"rules"`
}

var (
	flags struct {
		Path    string
		VerCode bool
	}

	dataConf *Config
)

func init() {
	flag.StringVar(&flags.Path, "c", "/etc/cuocuo-client/default.json", "Path")
	flag.BoolVar(&flags.VerCode, "v", false, "VerCode")
	flag.Parse()
}

func main() {
	if flags.VerCode {
		fmt.Println("Premium Tunnel for Public Internet v4.0.12")
		return
	}

	{
		ciph, _ := chacha20poly1305.NewX([]byte{
			0xec, 0xe4, 0xac, 0xe1, 0x7d, 0x61, 0x0b, 0xf4,
			0x40, 0xae, 0x9b, 0x11, 0x09, 0x3b, 0x27, 0x41,
			0xa8, 0x25, 0x27, 0x39, 0x1a, 0x75, 0x52, 0x88,
			0xbe, 0x41, 0xcf, 0x97, 0xc9, 0xcc, 0xb1, 0xda,
		})

		data, err := base64.StdEncoding.DecodeString(os.Getenv("CUOCUO_LICENSE_TOKEN"))
		if err != nil || len(data) < ciph.NonceSize()+ciph.Overhead() {
			return
		}

		if _, err = ciph.Open(data[ciph.NonceSize():ciph.NonceSize()], data[:ciph.NonceSize()], data[ciph.NonceSize():], nil); err != nil {
			return
		}

		size := int(binary.LittleEndian.Uint16(data[ciph.NonceSize() : ciph.NonceSize()+2]))
		date := int64(binary.LittleEndian.Uint64(data[ciph.NonceSize()+2+size : ciph.NonceSize()+2+size+8]))
		expr := int64(binary.LittleEndian.Uint64(data[ciph.NonceSize()+2+size+8 : ciph.NonceSize()+2+size+8+8]))
		cstr := string(data[ciph.NonceSize()+2 : ciph.NonceSize()+2+size])

		log.Printf("[LICENSE] Licensed to %s", cstr)
		log.Printf("[LICENSE] %s (%d) -> %s (%d)", time.Unix(date, 0).Format("2006-01-02 15:04:05"), date, time.Unix(expr, 0).Format("2006-01-02 15:04:05"), expr)

		if time.Now().Unix()-date < 0 {
			return
		}

		if time.Now().Unix()-expr > 0 {
			return
		}
	}

	if err := nero(); err != nil {
		log.Fatalf("[cuocuo] %v", err)
		return
	}

	go func() {
		zone := time.FixedZone("Asia/Shanghai", int((time.Hour * 8).Seconds()))
		date, err := time.ParseInLocation("2006-01-02", time.Now().In(zone).Format("2006-01-02"), zone)
		if err != nil {
			return
		}

		diff := date.AddDate(0, 0, 1).Add(time.Hour * 4).Add(time.Minute * 10).Sub(time.Now().In(zone))
		log.Printf("[REBOOT] Scheduled after %s", diff)

		time.Sleep(diff)
		time.Sleep(time.Second * time.Duration(rand.Intn(300)))
		os.Exit(0)
	}()

	for i := 0; i < len(dataConf.Rule); i++ {
		if strings.Contains(dataConf.Rule[i].Mode, "tcp") {
			tcpServe(dataConf.Rule[i])
		}

		if strings.Contains(dataConf.Rule[i].Mode, "udp") {
			udpServe(dataConf.Rule[i])
		}

		if strings.Contains(dataConf.Rule[i].Mode, "tls") {
			tlsServe(dataConf.Rule[i])
		}
	}

	for {
		time.Sleep(time.Minute * 30)

		runtime.GC()

		stats := runtime.MemStats{}
		runtime.ReadMemStats(&stats)
		log.Printf("[GC] Fraction %f", stats.GCCPUFraction)
		log.Printf("[GC] Obtained %dMB", stats.Sys/1024/1024)
		log.Printf("[GC] Assigned %dMB", stats.Alloc/1024/1024)
		log.Printf("[GC] Routine %d", runtime.NumGoroutine())
	}
}

func nero() error {
	m := &Config{}

	{
		b, err := ioutil.ReadFile(flags.Path)
		if err != nil {
			return fmt.Errorf("ioutil.ReadFile: %v", err)
		}

		if err = json.Unmarshal(b, m); err != nil {
			return fmt.Errorf("json.Unmarshal: %v", err)
		}
	}

	for i := 0; i < len(m.Next); i++ {
		m.Next[i].Create()
	}

	for i := 0; i < len(m.Fuck); i++ {
		m.Fuck[i].Create(m.Next)
		if len(m.Fuck[i].List) == 0 {
			return fmt.Errorf("missing next in %s", m.Fuck[i].ID)
		}

		m.Fuck[i].Dial = obs.NewOBS(m.Fuck[i].Mode, m.Fuck[i].List)
	}

	{
		/*
		 * 端口段规则解析
		 *
		 * 会将目标地址合并
		 */
		rules := make(structs.RuleList, 0)

		for i := 0; i < len(m.Rule); i++ {
			if !strings.Contains(m.Rule[i].ListenPort, ":") {
				rules = append(rules, &structs.Rule{
					Dialer:     m.Rule[i].Dialer,
					ListenAddr: m.Rule[i].ListenAddr,
					ListenPort: m.Rule[i].ListenPort,
					RemoteAddr: net.JoinHostPort(m.Rule[i].RemoteAddr, m.Rule[i].RemotePort),
					TrueIP:     m.Rule[i].TrueIP,
					TrueV2:     m.Rule[i].TrueV2,
					ProxyP:     m.Rule[i].ProxyP,
					Mode:       m.Rule[i].Mode,
					Opts:       m.Rule[i].Opts,
				})
				continue
			}

			s, err := strconv.Atoi(strings.SplitN(m.Rule[i].ListenPort, ":", 2)[0])
			if err != nil {
				return fmt.Errorf("strconv.Atoi: %v", err)
			}

			e, err := strconv.Atoi(strings.SplitN(m.Rule[i].ListenPort, ":", 2)[1])
			if err != nil {
				return fmt.Errorf("strconv.Atoi: %v", err)
			}

			r := s
			if m.Rule[i].RemotePort != "" {
				r, err = strconv.Atoi(m.Rule[i].RemotePort)
				if err != nil {
					return fmt.Errorf("strconv.Atoi: %v", err)
				}
			}

			for x := s; x <= e; x++ {
				rules = append(rules, &structs.Rule{
					Dialer:     m.Rule[i].Dialer,
					ListenAddr: m.Rule[i].ListenAddr,
					ListenPort: strconv.Itoa(x),
					RemoteAddr: net.JoinHostPort(m.Rule[i].RemoteAddr, strconv.Itoa(r)),
					TrueIP:     m.Rule[i].TrueIP,
					TrueV2:     m.Rule[i].TrueV2,
					ProxyP:     m.Rule[i].ProxyP,
					Mode:       m.Rule[i].Mode,
					Opts:       m.Rule[i].Opts,
				})

				r++
			}
		}

		m.Rule = rules
	}

	{
		/*
		 * 监听地址解析（解析接口地址）
		 *
		 * 会将监听地址合并
		 */
		rules := make(structs.RuleList, 0)

		for i := 0; i < len(m.Rule); i++ {
			if m.Rule[i].ListenAddr == "" {
				addrs, err := tools.GetAddrList()
				if err != nil {
					return fmt.Errorf("tools.GetAddrList: %v", err)
				}

				for _, addr := range addrs {
					rules = append(rules, &structs.Rule{
						Dialer:     m.Rule[i].Dialer,
						ListenAddr: net.JoinHostPort(addr.String(), m.Rule[i].ListenPort),
						RemoteAddr: m.Rule[i].RemoteAddr,
						TrueIP:     m.Rule[i].TrueIP,
						TrueV2:     m.Rule[i].TrueV2,
						ProxyP:     m.Rule[i].ProxyP,
						Mode:       m.Rule[i].Mode,
						Opts:       m.Rule[i].Opts,
					})
				}

				continue
			}

			if strings.Contains(m.Rule[i].ListenAddr, ",") {
				names := strings.Split(m.Rule[i].ListenAddr, ",")
				for _, name := range names {
					if addr := net.ParseIP(name); addr != nil {
						rules = append(rules, &structs.Rule{
							Dialer:     m.Rule[i].Dialer,
							ListenAddr: net.JoinHostPort(addr.String(), m.Rule[i].ListenPort),
							RemoteAddr: m.Rule[i].RemoteAddr,
							TrueIP:     m.Rule[i].TrueIP,
							TrueV2:     m.Rule[i].TrueV2,
							ProxyP:     m.Rule[i].ProxyP,
							Mode:       m.Rule[i].Mode,
							Opts:       m.Rule[i].Opts,
						})

						continue
					}

					addrs, err := tools.GetAddrListByName(name)
					if err != nil {
						return fmt.Errorf("tools.GetAddrListByName: %v", err)
					}

					for _, addr := range addrs {
						rules = append(rules, &structs.Rule{
							Dialer:     m.Rule[i].Dialer,
							ListenAddr: net.JoinHostPort(addr.String(), m.Rule[i].ListenPort),
							RemoteAddr: m.Rule[i].RemoteAddr,
							TrueIP:     m.Rule[i].TrueIP,
							TrueV2:     m.Rule[i].TrueV2,
							ProxyP:     m.Rule[i].ProxyP,
							Mode:       m.Rule[i].Mode,
							Opts:       m.Rule[i].Opts,
						})
					}
				}

				continue
			}

			if net.ParseIP(m.Rule[i].ListenAddr) != nil {
				rules = append(rules, &structs.Rule{
					Dialer:     m.Rule[i].Dialer,
					ListenAddr: net.JoinHostPort(m.Rule[i].ListenAddr, m.Rule[i].ListenPort),
					RemoteAddr: m.Rule[i].RemoteAddr,
					TrueIP:     m.Rule[i].TrueIP,
					TrueV2:     m.Rule[i].TrueV2,
					ProxyP:     m.Rule[i].ProxyP,
					Mode:       m.Rule[i].Mode,
					Opts:       m.Rule[i].Opts,
				})
			} else {
				addrs, err := tools.GetAddrListByName(m.Rule[i].ListenAddr)
				if err != nil {
					return fmt.Errorf("tools.GetAddrList: %v", err)
				}

				for _, addr := range addrs {
					rules = append(rules, &structs.Rule{
						Dialer:     m.Rule[i].Dialer,
						ListenAddr: net.JoinHostPort(addr.String(), m.Rule[i].ListenPort),
						RemoteAddr: m.Rule[i].RemoteAddr,
						TrueIP:     m.Rule[i].TrueIP,
						TrueV2:     m.Rule[i].TrueV2,
						ProxyP:     m.Rule[i].ProxyP,
						Mode:       m.Rule[i].Mode,
						Opts:       m.Rule[i].Opts,
					})
				}
			}
		}

		m.Rule = rules
	}

	{
		/*
		 * 分配 ID 和下一跳
		 */
		for i := 0; i < len(m.Rule); i++ {
			ok := false

			for x := 0; x < len(m.Next); x++ {
				if m.Rule[i].Dialer == m.Next[x].ID {
					m.Rule[i].Dial = m.Next[x]

					ok = true
					break
				}
			}

			if ok {
				continue
			}

			for x := 0; x < len(m.Fuck); x++ {
				if m.Rule[i].Dialer == m.Fuck[x].ID {
					m.Rule[i].Dial = m.Fuck[x]

					ok = true
					break
				}
			}

			if !ok {
				return fmt.Errorf("could not find %s", m.Rule[i].Dialer)
			}
		}
	}

	dataConf = m
	return nil
}
