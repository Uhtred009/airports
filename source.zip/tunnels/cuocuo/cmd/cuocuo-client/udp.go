package main

import (
	"encoding/binary"
	"fmt"
	"io"
	"log"
	"net"
	"sync"
	"time"

	"ryzen.moe/tunnels/cuocuo/common/ace"
	"ryzen.moe/tunnels/cuocuo/outbound"
	"ryzen.moe/tunnels/cuocuo/structs"
)

func udpServe(r *structs.Rule) {
	go func() {
		for {
			log.Printf("[UDP][%s] %v", r.ListenAddr, udpListen(r))

			time.Sleep(time.Second * 3)
		}
	}()
}

func udpListen(r *structs.Rule) error {
	ln, err := net.ListenPacket("udp", r.ListenAddr)
	if err != nil {
		return fmt.Errorf("net.ListenPacket: %v", err)
	}
	defer ln.Close()

	nm := NewNAT()
	data := make([]byte, 1024)

	for {
		size, from, err := ln.ReadFrom(data)
		if err != nil {
			return fmt.Errorf("ln.ReadFrom: %v", err)
		}

		remote := nm.Get(from.String())
		if remote == nil {
			n := r.GetNext()
			m := ace.RequestHeader{
				Type:   ace.C_UDP,
				Unix:   time.Now().Unix(),
				From:   from.String(),
				Next:   r.RemoteAddr,
				Data:   nil,
				TrueIP: r.TrueIP,
				TrueV2: r.TrueV2,
			}

			remote, err = outbound.Dial(n)
			if err != nil {
				continue
			}

			if err = ace.SendRequestHeader(remote, &m); err != nil {
				remote.Close()
				continue
			}

			remote = NewUDPConn(remote)

			nm.Set(from.String(), remote)
			go udpPipe(r, nm, from, ln, remote)

			log.Printf("[UDP][%s] %s - %s - %s", r.ListenAddr, from, n.Remote, r.RemoteAddr)
		}

		if _, err := remote.Write(data[:size]); err != nil {
			nm.Del(from.String())
		}
	}
}

func udpPipe(r *structs.Rule, nm *NAT, from net.Addr, client net.PacketConn, remote net.Conn) {
	data := make([]byte, 1024)

	for {
		remote.SetReadDeadline(time.Now().Add(time.Second * 10))
		size, err := remote.Read(data)
		if err != nil {
			break
		}

		if _, err = client.WriteTo(data[:size], from); err != nil {
			break
		}
	}

	nm.Del(from.String())
}

type NAT struct {
	sync.Mutex

	m map[string]net.Conn
}

func NewNAT() *NAT {
	return &NAT{m: make(map[string]net.Conn)}
}

func (o *NAT) Get(name string) net.Conn {
	o.Lock()
	defer o.Unlock()

	conn, ok := o.m[name]
	if !ok {
		return nil
	}

	return conn
}

func (o *NAT) Set(name string, conn net.Conn) {
	o.Lock()
	defer o.Unlock()

	o.m[name] = conn
}

func (o *NAT) Del(name string) {
	o.Lock()
	defer o.Unlock()

	conn, ok := o.m[name]
	if ok {
		delete(o.m, name)
		conn.Close()
	}
}

type UDPConn struct {
	net.Conn

	rbuffer []byte
	wbuffer []byte
}

func NewUDPConn(client net.Conn) net.Conn {
	return &UDPConn{
		Conn: client,
	}
}

func (o *UDPConn) ExtendReadBuffer(length int) {
	if len(o.rbuffer) < length {
		o.rbuffer = make([]byte, length)
	}
}

func (o *UDPConn) ExtendSendBuffer(length int) {
	if len(o.wbuffer) < length {
		o.wbuffer = make([]byte, length)
	}
}

func (o *UDPConn) Read(data []byte) (int, error) {
	o.ExtendReadBuffer(2)
	if _, err := io.ReadFull(o.Conn, o.rbuffer[:2]); err != nil {
		return 0, err
	}

	length := int(binary.LittleEndian.Uint16(o.rbuffer[:2]))

	o.ExtendReadBuffer(length)
	if _, err := io.ReadFull(o.Conn, o.rbuffer[:length]); err != nil {
		return 0, err
	}

	return copy(data, o.rbuffer[:length]), nil
}

func (o *UDPConn) Write(data []byte) (int, error) {
	o.ExtendSendBuffer(2 + len(data))
	binary.LittleEndian.PutUint16(o.wbuffer[:2], uint16(len(data)))
	copy(o.wbuffer[2:], data)

	if _, err := o.Conn.Write(o.wbuffer[:2+len(data)]); err != nil {
		return 0, err
	}

	return len(data), nil
}
