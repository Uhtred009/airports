package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"log"
	"net"
	"time"

	"ryzen.moe/tunnels/cuocuo/common/ace"
	"ryzen.moe/tunnels/cuocuo/outbound"
	"ryzen.moe/tunnels/cuocuo/structs"
	"ryzen.moe/tunnels/cuocuo/tools"
)

func tlsServe(r *structs.Rule) {
	go func() {
		for {
			log.Printf("[TLS][%s] %v", r.ListenAddr, tlsListen(r))

			time.Sleep(time.Second * 3)
		}
	}()
}

func tlsListen(r *structs.Rule) error {
	list := tools.ParseList(r.Opts)

	tlsCert, err := tls.LoadX509KeyPair(tools.GetFromList(list, "Crt"), tools.GetFromList(list, "Sec"))
	if err != nil {
		return fmt.Errorf("tls.LoadX509KeyPair: %v", err)
	}

	tlsConfig := tls.Config{
		Certificates: []tls.Certificate{tlsCert},
		MinVersion:   tls.VersionTLS11,
		MaxVersion:   tls.VersionTLS13,
	}
	if tools.GetFromList(list, "Host") != "" {
		name := tools.GetFromList(list, "Host")

		tlsConfig.VerifyConnection = func(info tls.ConnectionState) error {
			if info.ServerName != name {
				return io.EOF
			}

			return nil
		}
	}

	lc := net.ListenConfig{
		KeepAlive: time.Second * 9,
	}

	ln, err := lc.Listen(context.Background(), "tcp", r.ListenAddr)
	if err != nil {
		return fmt.Errorf("net.Listen: %v", err)
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			return fmt.Errorf("ln.Accept: %v", err)
		}

		go tlsHandle(r, tls.Server(client, &tlsConfig))
	}
}

func tlsHandle(r *structs.Rule, client net.Conn) {
	defer client.Close()

	data := make([]byte, 512)
	size, err := client.Read(data)
	if err != nil {
		return
	}

	n := r.GetNext()
	remote, err := outbound.Dial(n)
	if err != nil {
		return
	}
	defer remote.Close()

	m := ace.RequestHeader{
		Type:   ace.C_TCP,
		Unix:   time.Now().Unix(),
		From:   client.RemoteAddr().String(),
		Next:   r.RemoteAddr,
		Data:   data[:size],
		TrueIP: r.TrueIP,
		TrueV2: r.TrueV2,
		ProxyP: r.ProxyP,
	}
	if err = ace.SendRequestHeader(remote, &m); err != nil {
		return
	}

	log.Printf("[TLS][%s] %s - %s - %s", r.ListenAddr, m.From, n.Remote, m.Next)

	go func() {
		io.CopyBuffer(client, remote, make([]byte, 1024))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
	}()

	io.CopyBuffer(remote, client, make([]byte, 1024))
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
}
