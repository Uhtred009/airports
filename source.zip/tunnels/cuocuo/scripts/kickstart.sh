#!/usr/bin/env bash
apt update || exit $?
apt dist-upgrade -y || exit $?
apt install lsb-release openssl libssl-dev -y || exit $?
apt autoremove --purge -y || exit $?

name=''
case $(lsb_release -cs) in
    'bookworm') # Debian 12
        name='debian-bookworm'
        ;;
    'bullseye') # Debian 11
        name='debian-bullseye'
        ;;
    'buster')   # Debian 10
        name='debian-buster'
        ;;
    'stretch')  # Debian 9
        name='debian-stretch'
        ;;
    'jammy')    # Ubuntu 22.04
        name='ubuntu-jammy'
        ;;
    'impish')   # Ubuntu 21.10
        name='ubuntu-impish'
        ;;
    'focal')    # Ubuntu 20.04
        name='ubuntu-focal'
        ;;
    'bionic')   # Ubuntu 18.04
        name='ubuntu-bionic'
        ;;
    *)
        exit 1
esac

if [[ ! -d '/etc/cuocuo-client' ]]; then
    mkdir /etc/cuocuo-client
fi

if [[ ! -d '/etc/cuocuo-server' ]]; then
    mkdir /etc/cuocuo-server
fi

if [[ ! -f '/etc/cuocuo-client/default.json' ]]; then
    cp -f example.client.json /etc/cuocuo-client/default.json
fi

if [[ ! -f '/etc/cuocuo-client/default.json' ]]; then
    cp -f example.server.json /etc/cuocuo-server/default.json
fi

if [[ ! -f '/etc/default/cuocuo-client.env' ]]; then
    cp -f default.env /etc/default/cuocuo-client.env
fi

if [[ ! -f '/etc/default/cuocuo-server.env' ]]; then
    cp -f default.env /etc/default/cuocuo-server.env
fi

cp -f "./$name/cuocuo-client" .
cp -f "./$name/cuocuo-server" .
chmod +x cuocuo-client
chmod +x cuocuo-server

cp -f cuocuo-client /usr/bin
cp -f cuocuo-server /usr/bin
cp -f cuocuo-client@.service /etc/systemd/system/cuocuo-client@.service
cp -f cuocuo-server@.service /etc/systemd/system/cuocuo-server@.service
systemctl daemon-reload
exit 0
