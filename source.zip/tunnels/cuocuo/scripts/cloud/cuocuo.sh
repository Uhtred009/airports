#!/usr/bin/env bash
apt update || exit $?
apt dist-upgrade -y || exit $?
apt install zip unzip -y || exit $?
apt autoremove --purge -y || exit $?

pushd ~
wget -O release.zip https://wechatupdates.moe/downloads/cuocuo/latest.zip || exit $?
unzip release.zip && rm -f release.zip && cd release
bash kickstart.sh || exit $?
cd ~ && rm -fr release
popd

clear
echo 'ATTENTION'
echo 'Do not use the default encryption token and nonce unless you do not care that your IP address will be BLOCKED'
echo 'Your encryption token and nonce MUST be the same on all machines'
echo ''
echo 'You can generate encryption token and nonce with the following commands'
echo 'openssl rand -base64 48'
echo ''

if [[ ! -z "$1" ]]; then
    sed -i "s|.*CUOCUO_LICENSE_TOKEN=.*|CUOCUO_LICENSE_TOKEN='$1'|" /etc/default/cuocuo-client.env
else
    read -rep $'ENTER YOUR LICENSE TOKEN\n' LICENSE_TOKEN

    if [[ ! -z "$LICENSE_TOKEN" ]]; then
        sed -i "s|.*CUOCUO_LICENSE_TOKEN=.*|CUOCUO_LICENSE_TOKEN='$LICENSE_TOKEN'|" /etc/default/cuocuo-client.env
    fi
fi

if [[ ! -z "$2" ]]; then
    sed -i "s|.*CUOCUO_ENCRYPTION_TOKEN=.*|CUOCUO_ENCRYPTION_TOKEN='$2'|" /etc/default/cuocuo-client.env
    sed -i "s|.*CUOCUO_ENCRYPTION_TOKEN=.*|CUOCUO_ENCRYPTION_TOKEN='$2'|" /etc/default/cuocuo-server.env
else
    read -rep $'ENTER YOUR ENCRYPTION TOKEN\n' ENCRYPTION_TOKEN

    if [[ ! -z "$ENCRYPTION_TOKEN" ]]; then
        sed -i "s|.*CUOCUO_ENCRYPTION_TOKEN=.*|CUOCUO_ENCRYPTION_TOKEN='$ENCRYPTION_TOKEN'|" /etc/default/cuocuo-client.env
        sed -i "s|.*CUOCUO_ENCRYPTION_TOKEN=.*|CUOCUO_ENCRYPTION_TOKEN='$ENCRYPTION_TOKEN'|" /etc/default/cuocuo-server.env
    fi
fi

if [[ ! -z "$3" ]]; then
    sed -i "s|.*CUOCUO_ENCRYPTION_NONCE=.*|CUOCUO_ENCRYPTION_NONCE='$3'|" /etc/default/cuocuo-client.env
    sed -i "s|.*CUOCUO_ENCRYPTION_NONCE=.*|CUOCUO_ENCRYPTION_NONCE='$3'|" /etc/default/cuocuo-server.env
else
    read -rep $'ENTER YOUR ENCRYPTION NONCE\n' ENCRYPTION_NONCE

    if [[ ! -z "$ENCRYPTION_NONCE" ]]; then
        sed -i "s|.*CUOCUO_ENCRYPTION_NONCE=.*|CUOCUO_ENCRYPTION_NONCE='$ENCRYPTION_NONCE'|" /etc/default/cuocuo-client.env
        sed -i "s|.*CUOCUO_ENCRYPTION_NONCE=.*|CUOCUO_ENCRYPTION_NONCE='$ENCRYPTION_NONCE'|" /etc/default/cuocuo-server.env
    fi
fi

exit 0
