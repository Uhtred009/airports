package websocket

import (
	"fmt"
	"net"
	"net/http"
	"time"

	"ryzen.moe/tunnels/cuocuo/common/proto/websocket"
	"ryzen.moe/tunnels/cuocuo/structs"

	ws "github.com/gorilla/websocket"
)

var (
	upgrader = &ws.Upgrader{
		HandshakeTimeout: time.Second * 3,
		ReadBufferSize:   1400,
		WriteBufferSize:  1400,
	}
)

type Listener struct {
	srv *http.Server
	mux *http.ServeMux

	data *structs.Next

	close chan error
	conns chan net.Conn
}

func NewListener(n *structs.Next) net.Listener {
	ln := &Listener{
		srv:   &http.Server{},
		mux:   http.NewServeMux(),
		data:  n,
		close: make(chan error),
		conns: make(chan net.Conn),
	}
	if n.Path != "" {
		ln.mux.HandleFunc(fmt.Sprintf("/%s", n.Path), ln.handleConn)
		ln.mux.HandleFunc("/", ln.handle)
	} else {
		ln.mux.HandleFunc("/", ln.handleConn)
	}
	ln.srv.Addr = n.Listen
	ln.srv.Handler = ln.mux
	go ln.Listen()

	return ln
}

func (o *Listener) Listen() {
	o.close <- fmt.Errorf("http.ListenAndServe: %v", o.srv.ListenAndServe())
}

func (o *Listener) Accept() (net.Conn, error) {
	select {
	case err := <-o.close:
		return nil, err
	case conn := <-o.conns:
		return conn, nil
	}
}

func (o *Listener) Close() error {
	return o.srv.Close()
}

func (o *Listener) Addr() net.Addr {
	addr, err := net.ResolveTCPAddr("tcp", o.data.Listen)
	if err != nil {
		return nil
	}

	return addr
}

func (o *Listener) handleConn(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, o.data.Header)
	if err != nil {
		return
	}

	o.conns <- websocket.NewConn(conn)
}

func (o *Listener) handle(w http.ResponseWriter, r *http.Request) {

}

func Listen(n *structs.Next) (net.Listener, error) {
	return NewListener(n), nil
}
