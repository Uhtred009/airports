package rawtls

import (
	"crypto/tls"
	"fmt"
	"io"
	"net"

	"ryzen.moe/tunnels/cuocuo/structs"
)

type Listener struct {
	net.Listener

	data      *structs.Next
	tlsConfig *tls.Config
}

func (o *Listener) Accept() (net.Conn, error) {
	client, err := o.Listener.Accept()
	if err != nil {
		return nil, err
	}
	client = tls.Server(client, o.tlsConfig)

	return client, nil
}

func Listen(n *structs.Next) (net.Listener, error) {
	tlsCert, err := tls.LoadX509KeyPair(n.Crt, n.Sec)
	if err != nil {
		return nil, fmt.Errorf("tls.LoadX509KeyPair: %v", err)
	}

	tlsConfig := &tls.Config{
		Certificates: []tls.Certificate{tlsCert},
		MinVersion:   tls.VersionTLS11,
		MaxVersion:   tls.VersionTLS13,
	}
	if n.Host != "" {
		name := n.Host

		tlsConfig.VerifyConnection = func(info tls.ConnectionState) error {
			if info.ServerName != name {
				return io.EOF
			}

			return nil
		}
	}

	ln, err := net.Listen("tcp", n.Listen)
	if err != nil {
		return nil, fmt.Errorf("net.Listen: %v", err)
	}

	return &Listener{Listener: ln, data: n, tlsConfig: tlsConfig}, nil
}
