package opentls

import (
	"fmt"
	"net"

	"ryzen.moe/openssl/openssl"
	"ryzen.moe/tunnels/cuocuo/structs"
)

type Listener struct {
	net.Listener

	ctx  *openssl.Ctx
	data *structs.Next
}

func (o *Listener) Accept() (net.Conn, error) {
	client, err := o.Listener.Accept()
	if err != nil {
		return nil, fmt.Errorf("o.Listener.Accept: %v", err)
	}

	client, err = openssl.Server(client, o.ctx)
	if err != nil {
		client.Close()
		return nil, fmt.Errorf("openssl.Server: %v", err)
	}

	return client, nil
}

func Listen(n *structs.Next) (net.Listener, error) {
	ctx, err := openssl.NewCtxFromFiles(n.Crt, n.Sec)
	if err != nil {
		return nil, fmt.Errorf("openssl.NewContext: %v", err)
	}
	ctx.SetVerify(openssl.VerifyNone, nil)
	ctx.SetOptions(openssl.NoCompression | openssl.NoSSLv2 | openssl.NoSSLv3 | openssl.NoTLSv1)

	ln, err := net.Listen("tcp", n.Listen)
	if err != nil {
		return nil, fmt.Errorf("rawtcp.Listen: %v", err)
	}

	return &Listener{
		Listener: ln,

		ctx:  ctx,
		data: n,
	}, nil
}
