package rawtcp

import (
	"fmt"
	"net"

	"ryzen.moe/tunnels/cuocuo/structs"
)

func Listen(n *structs.Next) (net.Listener, error) {
	ln, err := net.Listen("tcp", n.Listen)
	if err != nil {
		return nil, fmt.Errorf("net.Listen: %v", err)
	}

	return ln, nil
}
