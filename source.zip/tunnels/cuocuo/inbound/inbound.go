package inbound

import (
	"fmt"
	"net"

	"ryzen.moe/tunnels/cuocuo/inbound/opentls"
	"ryzen.moe/tunnels/cuocuo/inbound/rawtcp"
	"ryzen.moe/tunnels/cuocuo/inbound/rawtls"
	"ryzen.moe/tunnels/cuocuo/inbound/websocket"
	"ryzen.moe/tunnels/cuocuo/structs"
)

func Listen(n *structs.Next) (net.Listener, error) {
	switch n.Type {
	case "TCP":
		return rawtcp.Listen(n)
	case "TLS":
		return rawtls.Listen(n)
	case "OpenTLS":
		return opentls.Listen(n)
	case "WebSocket":
		return websocket.Listen(n)
	default:
		return nil, fmt.Errorf("unknown type: %s", n.Type)
	}
}
