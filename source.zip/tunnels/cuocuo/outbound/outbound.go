package outbound

import (
	"fmt"
	"net"
	"sync"

	"ryzen.moe/tunnels/cuocuo/common/acp"
	"ryzen.moe/tunnels/cuocuo/outbound/opentls"
	"ryzen.moe/tunnels/cuocuo/outbound/rawtcp"
	"ryzen.moe/tunnels/cuocuo/outbound/rawtls"
	"ryzen.moe/tunnels/cuocuo/outbound/websocket"
	"ryzen.moe/tunnels/cuocuo/structs"
)

var (
	mtx sync.Mutex
	mux = make(map[string]*acp.Pool)
)

func dial(n *structs.Next) (net.Conn, error) {
	switch n.Type {
	case "TCP":
		return rawtcp.Dial(n)
	case "TLS":
		return rawtls.Dial(n)
	case "OpenTLS":
		return opentls.Dial(n)
	case "WebSocket":
		return websocket.Dial(n)
	default:
		return nil, fmt.Errorf("unknown type: %s", n.Type)
	}
}

func Dial(n *structs.Next) (net.Conn, error) {
	if !n.Premium {
		return dial(n)
	}

	mtx.Lock()
	dialer, ok := mux[n.GetID()]
	if !ok {
		dialer = acp.NewPool(func() (net.Conn, error) { return dial(n) })

		mux[n.GetID()] = dialer
	}
	mtx.Unlock()

	return dialer.Get()
}
