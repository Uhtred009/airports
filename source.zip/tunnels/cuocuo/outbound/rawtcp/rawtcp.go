package rawtcp

import (
	"net"
	"time"

	"ryzen.moe/tunnels/cuocuo/common/dns"
	"ryzen.moe/tunnels/cuocuo/structs"
)

func Dial(n *structs.Next) (net.Conn, error) {
	dialer := net.Dialer{
		Timeout:   time.Second * 3,
		KeepAlive: time.Second * 9,
	}
	if n.Binder != nil {
		dialer.LocalAddr = &net.TCPAddr{IP: n.Binder}
	}

	return dialer.Dial("tcp", dns.Fetch(n.Remote))
}
