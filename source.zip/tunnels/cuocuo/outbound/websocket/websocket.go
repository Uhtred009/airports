package websocket

import (
	"fmt"
	"net"
	"time"

	"ryzen.moe/tunnels/cuocuo/common/proto/websocket"
	"ryzen.moe/tunnels/cuocuo/outbound/rawtcp"
	"ryzen.moe/tunnels/cuocuo/structs"

	ws "github.com/gorilla/websocket"
)

func Dial(n *structs.Next) (net.Conn, error) {
	remote, err := rawtcp.Dial(n)
	if err != nil {
		return nil, fmt.Errorf("rawtcp.Dial: %v", err)
	}

	dialer := ws.Dialer{
		NetDial: func(network, address string) (net.Conn, error) {
			return remote, nil
		},
		HandshakeTimeout: time.Second * 3,
		ReadBufferSize:   1400,
		WriteBufferSize:  1400,
	}

	conn, _, err := dialer.Dial(fmt.Sprintf("ws://%s/%s", n.Remote, n.Path), n.Header)
	if err != nil {
		remote.Close()

		return nil, fmt.Errorf("dialer.Dial: %v", err)
	}

	return websocket.NewConn(conn), nil
}
