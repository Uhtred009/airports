package rawtls

import (
	"crypto/tls"
	"fmt"
	"net"

	"ryzen.moe/tunnels/cuocuo/outbound/rawtcp"
	"ryzen.moe/tunnels/cuocuo/structs"
)

func Dial(n *structs.Next) (net.Conn, error) {
	if n.TLSConfig == nil {
		n.TLSConfig = &tls.Config{
			ServerName:         n.Host,
			InsecureSkipVerify: n.Insecure,
			ClientSessionCache: tls.NewLRUClientSessionCache(0),
			MinVersion:         tls.VersionTLS11,
			MaxVersion:         tls.VersionTLS13,
		}
	}

	remote, err := rawtcp.Dial(n)
	if err != nil {
		return nil, fmt.Errorf("rawtcp.Dial: %v", err)
	}
	remote = tls.Client(remote, n.TLSConfig)

	if n.PremiumTLS {
		// 取消注释这里，配合 Premium 可以将 TLS 延迟降低至极低，但是你的服务端会出现巨额 CPU 占用
		if err = remote.(*tls.Conn).Handshake(); err != nil {
			remote.Close()

			return nil, fmt.Errorf("tls.Handshake: %v", err)
		}
	}

	return remote, nil
}
