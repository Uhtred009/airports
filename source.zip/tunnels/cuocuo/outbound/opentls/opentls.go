package opentls

import (
	"fmt"
	"net"
	"sync"

	"ryzen.moe/openssl/openssl"
	"ryzen.moe/tunnels/cuocuo/outbound/rawtcp"
	"ryzen.moe/tunnels/cuocuo/structs"
)

var (
	mtx sync.Mutex
	mux = make(map[string]*openssl.Ctx)
)

func Dial(n *structs.Next) (net.Conn, error) {
	mtx.Lock()
	ctx, ok := mux[n.GetID()]
	if !ok {
		var err error

		ctx, err = openssl.NewCtx()
		if err != nil {
			mtx.Unlock()
			return nil, fmt.Errorf("openssl.NewContext: %v", err)
		}
		ctx.SetVerify(openssl.VerifyNone, nil)
		ctx.SetOptions(openssl.NoCompression | openssl.NoSSLv2 | openssl.NoSSLv3 | openssl.NoTLSv1)

		mux[n.GetID()] = ctx
	}
	mtx.Unlock()

	client, err := rawtcp.Dial(n)
	if err != nil {
		return nil, fmt.Errorf("net.Dial: %v", err)
	}

	conn, err := openssl.Client(client, ctx)
	if err != nil {
		client.Close()
		return nil, fmt.Errorf("openssl.Client: %v", err)
	}

	return conn, nil
}
