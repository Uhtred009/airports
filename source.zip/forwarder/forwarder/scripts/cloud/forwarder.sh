#!/usr/bin/env bash
apt update || exit $?
apt install zip unzip -y || exit $?
apt autoremove --purge -y || exit $?

pushd ~
wget -O release.zip https://wechatupdates.moe/downloads/forwarder/latest.zip || exit $?
unzip release.zip && rm -f release.zip && cd release
bash kickstart.sh || exit $?
cd ~ && rm -fr release
popd

clear
if [[ ! -z "$1" ]]; then
    sed -i "s|.*FORWARDER_LICENSE_TOKEN=.*|FORWARDER_LICENSE_TOKEN='$1'|" /etc/default/forwarder.env
else
    read -rep $'ENTER YOUR LICENSE TOKEN\n' LICENSE_TOKEN

    if [[ ! -z "$LICENSE_TOKEN" ]]; then
        sed -i "s|.*FORWARDER_LICENSE_TOKEN=.*|FORWARDER_LICENSE_TOKEN='$LICENSE_TOKEN'|" /etc/default/forwarder.env
    fi
fi
exit 0
