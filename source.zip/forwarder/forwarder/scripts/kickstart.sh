#!/usr/bin/env bash
apt update
apt install lsb-release -y

name=''
case $(lsb_release -cs) in
    'bookworm') # Debian 12
        name='debian-bookworm'
        ;;
    'bullseye') # Debian 11
        name='debian-bullseye'
        ;;
    'buster')   # Debian 10
        name='debian-buster'
        ;;
    'stretch')  # Debian 9
        name='debian-stretch'
        ;;
    'jammy')    # Ubuntu 22.04
        name='ubuntu-jammy'
        ;;
    'impish')   # Ubuntu 21.10
        name='ubuntu-impish'
        ;;
    'focal')    # Ubuntu 20.04
        name='ubuntu-focal'
        ;;
    'bionic')   # Ubuntu 18.04
        name='ubuntu-bionic'
        ;;
    *)
        exit 1
esac

if [[ ! -d '/etc/forwarder' ]]; then
    mkdir /etc/forwarder
fi

if [[ ! -f '/etc/forwarder/default.json' ]]; then
    cp -f example.json /etc/forwarder/default.json
fi

if [[ ! -f '/etc/default/forwarder.env' ]]; then
    cp -f example.env /etc/default/forwarder.env
fi

cp -f "./$name/forwarder" .
chmod +x forwarder

cp -f forwarder /usr/bin
cp -f example.service /etc/systemd/system/forwarder.service
cp -f example@.service /etc/systemd/system/forwarder@.service
systemctl daemon-reload
exit 0
