package structs

import (
	"net"
	"strings"
)

var (
	List ForwarderList
)

type Forwarder struct {
	ListenAddr string `json:"listen_addr"`
	ListenPort string `json:"listen_port"`
	RemoteAddr string `json:"remote_addr"`
	RemotePort string `json:"remote_port"`
	DialerAddr string `json:"dialer_addr"`
	TrueIP     bool   `json:"trueip"`
	TrueV2     bool   `json:"truev2"`
	Mode       string `json:"mode"`
	UseC       bool   `json:"usec"`
	Opts       string `json:"opts"`

	Binder net.IP `json:"-"`
}
type ForwarderList []*Forwarder

func (o *Forwarder) Get(name string) string {
	list := make(map[string]string)

	data := strings.Split(o.Opts, ";")
	for i := 0; i < len(data); i++ {
		cstr := strings.SplitN(data[i], "=", 2)
		if len(cstr) != 2 {
			continue
		}

		list[cstr[0]] = cstr[1]
	}

	cstr, ok := list[name]
	if !ok {
		return ""
	}

	return cstr
}
