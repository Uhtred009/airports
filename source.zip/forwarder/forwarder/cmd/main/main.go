package main

import (
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net"
	"os"
	"runtime"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/chacha20poly1305"
	"ryzen.moe/forwarder/forwarder/structs"
	"ryzen.moe/forwarder/forwarder/tools"
)

var (
	flags struct {
		Path string
	}
)

func init() {
	flag.StringVar(&flags.Path, "c", "", "Path")
	flag.Parse()
}

func main() {
	{
		ciph, _ := chacha20poly1305.NewX([]byte{
			0x27, 0x6e, 0x02, 0x18, 0xe5, 0x02, 0x35, 0xbe,
			0x45, 0x8d, 0xaa, 0xe8, 0x26, 0xcc, 0x35, 0x36,
			0xdb, 0xfa, 0xb2, 0xca, 0x8c, 0xf6, 0x36, 0x98,
			0x4a, 0x76, 0x32, 0x99, 0x35, 0x01, 0xf9, 0xd5,
		})

		data, err := base64.StdEncoding.DecodeString(os.Getenv("FORWARDER_LICENSE_TOKEN"))
		if err != nil {
			return
		}

		if _, err = ciph.Open(data[ciph.NonceSize():ciph.NonceSize()], data[:ciph.NonceSize()], data[ciph.NonceSize():], nil); err != nil {
			return
		}

		size := int(binary.LittleEndian.Uint16(data[ciph.NonceSize() : ciph.NonceSize()+2]))
		date := int64(binary.LittleEndian.Uint64(data[ciph.NonceSize()+2+size : ciph.NonceSize()+2+size+8]))
		expr := int64(binary.LittleEndian.Uint64(data[ciph.NonceSize()+2+size+8 : ciph.NonceSize()+2+size+8+8]))
		cstr := string(data[ciph.NonceSize()+2 : ciph.NonceSize()+2+size])

		log.Printf("%s", cstr)
		log.Printf("%s (%d) -> %s (%d)", time.Unix(date, 0).Format("2006-01-02 15:04:05"), date, time.Unix(expr, 0).Format("2006-01-02 15:04:05"), expr)

		if time.Now().Unix()-date < 0 {
			return
		}

		if time.Now().Unix()-expr > 0 {
			return
		}
	}

	if err := nero(); err != nil {
		log.Fatalf("[Forwarder] %v", err)
		return
	}

	for m := 0; m < len(structs.List); m++ {
		if strings.Contains(structs.List[m].Mode, "tcp") {
			go tcpServe(structs.List[m])
		}

		if strings.Contains(structs.List[m].Mode, "udp") {
			go udpServe(structs.List[m])
		}

		if strings.Contains(structs.List[m].Mode, "tls") {
			go tlsServe(structs.List[m])
		}
	}

	{
		go func() {
			zone := time.FixedZone("Asia/Shanghai", int((time.Hour * 8).Seconds()))
			date, err := time.ParseInLocation("2006-01-02", time.Now().In(zone).Format("2006-01-02"), zone)
			if err != nil {
				return
			}

			diff := date.AddDate(0, 0, 1).Add(time.Hour * 4).Add(time.Minute * 10).Sub(time.Now().In(zone))
			log.Printf("[REBOOT] Scheduled after %s", diff)

			time.Sleep(diff)
			time.Sleep(time.Second * time.Duration(rand.Intn(300)))
			os.Exit(0)
		}()
	}

	for {
		time.Sleep(time.Minute * 30)

		runtime.GC()

		stats := runtime.MemStats{}
		runtime.ReadMemStats(&stats)
		log.Printf("[GC] Fraction %f", stats.GCCPUFraction)
		log.Printf("[GC] Obtained %dMB", stats.Sys/1024/1024)
		log.Printf("[GC] Assigned %dMB", stats.Alloc/1024/1024)
		log.Printf("[GC] Routine %d", runtime.NumGoroutine())
	}
}

func nero() error {
	rule := make(structs.ForwarderList, 0)

	{
		data, err := ioutil.ReadFile(flags.Path)
		if err != nil {
			return fmt.Errorf("ioutil.ReadFile: %v", err)
		}

		list := make(structs.ForwarderList, 0)
		if err := json.Unmarshal(data, &list); err != nil {
			return fmt.Errorf("json.Unmarshal: %v", err)
		}

		for i := 0; i < len(list); i++ {
			if strings.Contains(list[i].ListenPort, ":") {
				SPL := strings.SplitN(list[i].ListenPort, ":", 2)

				s := tools.Atoi(SPL[0])
				e := tools.Atoi(SPL[1])

				j := s
				if list[i].RemotePort != "" {
					j = tools.Atoi(list[i].RemotePort)
				}

				for m := s; m <= e; m++ {
					rule = append(rule, &structs.Forwarder{
						ListenAddr: list[i].ListenAddr,
						ListenPort: strconv.Itoa(m),
						RemoteAddr: net.JoinHostPort(list[i].RemoteAddr, strconv.Itoa(j)),
						TrueIP:     list[i].TrueIP,
						TrueV2:     list[i].TrueV2,
						Mode:       list[i].Mode,
						UseC:       list[i].UseC,
						Opts:       list[i].Opts,

						Binder: net.ParseIP(list[i].DialerAddr),
					})

					j++
				}

				continue
			}

			rule = append(rule, &structs.Forwarder{
				ListenAddr: list[i].ListenAddr,
				ListenPort: list[i].ListenPort,
				RemoteAddr: net.JoinHostPort(list[i].RemoteAddr, list[i].RemotePort),
				TrueIP:     list[i].TrueIP,
				TrueV2:     list[i].TrueV2,
				Mode:       list[i].Mode,
				UseC:       list[i].UseC,
				Opts:       list[i].Opts,

				Binder: net.ParseIP(list[i].DialerAddr),
			})
		}
	}

	{
		for i := 0; i < len(rule); i++ {
			if rule[i].ListenAddr == "" {
				addr, err := tools.GetAddrList()
				if err != nil {
					return err
				}

				for x := 0; x < len(addr); x++ {
					structs.List = append(structs.List, &structs.Forwarder{
						ListenAddr: net.JoinHostPort(addr[x].String(), rule[i].ListenPort),
						RemoteAddr: rule[i].RemoteAddr,
						TrueIP:     rule[i].TrueIP,
						TrueV2:     rule[i].TrueV2,
						Mode:       rule[i].Mode,
						UseC:       rule[i].UseC,
						Opts:       rule[i].Opts,

						Binder: rule[i].Binder,
					})
				}

				continue
			}

			if net.ParseIP(rule[i].ListenAddr) != nil {
				structs.List = append(structs.List, &structs.Forwarder{
					ListenAddr: net.JoinHostPort(rule[i].ListenAddr, rule[i].ListenPort),
					RemoteAddr: rule[i].RemoteAddr,
					TrueIP:     rule[i].TrueIP,
					TrueV2:     rule[i].TrueV2,
					Mode:       rule[i].Mode,
					UseC:       rule[i].UseC,
					Opts:       rule[i].Opts,

					Binder: rule[i].Binder,
				})

				continue
			}

			adps := strings.Split(rule[i].ListenAddr, ",")
			for x := 0; x < len(adps); x++ {
				if addr := net.ParseIP(adps[x]); addr != nil {
					structs.List = append(structs.List, &structs.Forwarder{
						ListenAddr: net.JoinHostPort(addr.String(), rule[i].ListenPort),
						RemoteAddr: rule[i].RemoteAddr,
						TrueIP:     rule[i].TrueIP,
						TrueV2:     rule[i].TrueV2,
						Mode:       rule[i].Mode,
						UseC:       rule[i].UseC,
						Opts:       rule[i].Opts,

						Binder: rule[i].Binder,
					})

					continue
				}

				addr, err := tools.GetAddrListByName(adps[x])
				if err != nil {
					continue
				}

				for y := 0; y < len(addr); y++ {
					structs.List = append(structs.List, &structs.Forwarder{
						ListenAddr: net.JoinHostPort(addr[y].String(), rule[i].ListenPort),
						RemoteAddr: rule[i].RemoteAddr,
						TrueIP:     rule[i].TrueIP,
						TrueV2:     rule[i].TrueV2,
						Mode:       rule[i].Mode,
						UseC:       rule[i].UseC,
						Opts:       rule[i].Opts,

						Binder: rule[i].Binder,
					})
				}
			}
		}
	}

	return nil
}
