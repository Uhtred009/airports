package main

import (
	"crypto/tls"
	"fmt"
	"io"
	"log"
	"net"
	"time"

	"ryzen.moe/forwarder/forwarder/common/acp"
	"ryzen.moe/forwarder/forwarder/common/tfo"
	"ryzen.moe/forwarder/forwarder/structs"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func tlsServe(r *structs.Forwarder) {
	for {
		log.Printf("[TLS][%s] %v", r.ListenAddr, tlsListen(r))

		time.Sleep(time.Second * 3)
	}
}

func tlsListen(r *structs.Forwarder) error {
	tlsCert, err := tls.LoadX509KeyPair(r.Get("Crt"), r.Get("Sec"))
	if err != nil {
		return fmt.Errorf("tls.LoadX509KeyPair: %v", err)
	}

	tlsConfig := tls.Config{
		Certificates: []tls.Certificate{tlsCert},
		MinVersion:   tls.VersionTLS11,
		MaxVersion:   tls.VersionTLS13,
	}
	if r.Get("Host") != "" {
		name := r.Get("Host")

		tlsConfig.VerifyConnection = func(info tls.ConnectionState) error {
			if info.ServerName != name {
				return io.EOF
			}

			return nil
		}
	}

	ln, err := tfo.Listen("tcp", r.ListenAddr)
	if err != nil {
		return fmt.Errorf("lc.Listen: %v", err)
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			return fmt.Errorf("ln.Accept: %v", err)
		}

		go tlsHandle(r, tls.Server(client, &tlsConfig))
	}
}

func tlsHandle(r *structs.Forwarder, client net.Conn) {
	defer client.Close()

	target := socks.ParseAddr(client.RemoteAddr().String())
	if target == nil {
		return
	}

	buffer := make([]byte, 1446)
	size, err := client.Read(buffer[len(target):])
	if err != nil {
		return
	}

	if r.TrueIP {
		copy(buffer[0:], target)
	}

	remote, err := acp.Dial(r)
	if err != nil {
		return
	}
	defer remote.Close()

	if r.TrueIP {
		if _, err = remote.Write(buffer[:len(target)+size]); err != nil {
			return
		}
	} else {
		if _, err = remote.Write(buffer[len(target) : len(target)+size]); err != nil {
			return
		}
	}
	target = nil

	log.Printf("[TLS][%s] %s <-> %s", r.ListenAddr, client.RemoteAddr(), r.RemoteAddr)

	go func() {
		io.CopyBuffer(remote, client, make([]byte, 1446))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
	}()

	io.CopyBuffer(client, remote, buffer)
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
}
