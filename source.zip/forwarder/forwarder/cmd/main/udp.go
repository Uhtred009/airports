package main

import (
	"fmt"
	"log"
	"net"
	"sync"
	"time"

	"ryzen.moe/forwarder/forwarder/structs"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func udpServe(r *structs.Forwarder) {
	for {
		log.Printf("[UDP][%s] %v", r.ListenAddr, udpListen(r))

		time.Sleep(time.Second * 3)
	}
}

func udpListen(r *structs.Forwarder) error {
	ln, err := net.ListenPacket("udp", r.ListenAddr)
	if err != nil {
		return fmt.Errorf("net.ListenPacket: %v", err)
	}
	defer ln.Close()

	nm := newNAT()
	buffer := make([]byte, 1441)
	packed := make([]byte, 2048)

	for {
		size, from, err := ln.ReadFrom(buffer)
		if err != nil {
			return fmt.Errorf("ln.ReadFrom: %v", err)
		}

		addr := socks.ParseAddr(from.String())
		if addr == nil {
			continue
		}

		remote := nm.Get(from.String())
		if remote == nil {
			dialer := net.Dialer{}
			if r.Binder != nil {
				dialer.LocalAddr = &net.UDPAddr{IP: r.Binder}
			}

			remote, err = dialer.Dial("udp", r.RemoteAddr)
			if err != nil {
				continue
			}

			log.Printf("[UDP][%s] %s <-> %s", r.ListenAddr, from, r.RemoteAddr)
			nm.Create(from, remote, ln)
		}

		if r.TrueV2 {
			copy(packed[0:], addr)
			copy(packed[0+len(addr):], buffer[:size])

			size += len(addr)
		} else {
			copy(packed[0:], buffer[:size])
		}

		if _, err = remote.Write(packed[:size]); err != nil {
			continue
		}
	}
}

func udpPipe(src net.Conn, dst net.PacketConn, from net.Addr) {
	buffer := make([]byte, 1458)

	for {
		src.SetReadDeadline(time.Now().Add(time.Second * 10))
		size, err := src.Read(buffer)
		if err != nil {
			return
		}

		if _, err = dst.WriteTo(buffer[:size], from); err != nil {
			return
		}
	}
}

type NAT struct {
	sync.RWMutex

	m map[string]net.Conn
}

func newNAT() *NAT {
	return &NAT{m: make(map[string]net.Conn)}
}

func (m *NAT) Get(id string) net.Conn {
	m.RLock()
	defer m.RUnlock()

	return m.m[id]
}

func (m *NAT) Set(id string, conn net.Conn) {
	m.Lock()
	defer m.Unlock()

	m.m[id] = conn
}

func (m *NAT) Create(from net.Addr, src net.Conn, dst net.PacketConn) {
	m.Set(from.String(), src)

	go func() {
		udpPipe(src, dst, from)
		if conn := m.Delete(from.String()); conn != nil {
			conn.Close()
		}
	}()
}

func (m *NAT) Delete(id string) net.Conn {
	m.Lock()
	defer m.Unlock()

	if conn, ok := m.m[id]; ok {
		delete(m.m, id)

		return conn
	}

	return nil
}
