package main

import (
	"fmt"
	"io"
	"log"
	"net"
	"time"

	"ryzen.moe/forwarder/forwarder/common/acp"
	"ryzen.moe/forwarder/forwarder/common/tfo"
	"ryzen.moe/forwarder/forwarder/structs"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func tcpServe(r *structs.Forwarder) {
	for {
		log.Printf("[TCP][%s] %v", r.ListenAddr, tcpListen(r))

		time.Sleep(time.Second * 3)
	}
}

func tcpListen(r *structs.Forwarder) error {
	ln, err := tfo.Listen("tcp", r.ListenAddr)
	if err != nil {
		return fmt.Errorf("lc.Listen: %v", err)
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			return fmt.Errorf("ln.Accept: %v", err)
		}

		go tcpHandle(r, client)
	}
}

func tcpHandle(r *structs.Forwarder, client net.Conn) {
	defer client.Close()

	target := socks.ParseAddr(client.RemoteAddr().String())
	if target == nil {
		return
	}

	buffer := make([]byte, 1446)
	size, err := client.Read(buffer[len(target):])
	if err != nil {
		return
	}

	remote, err := acp.Dial(r)
	if err != nil {
		return
	}
	defer remote.Close()

	if r.TrueIP {
		copy(buffer[0:], target)

		if _, err = remote.Write(buffer[:len(target)+size]); err != nil {
			return
		}
	} else {
		if _, err = remote.Write(buffer[len(target) : len(target)+size]); err != nil {
			return
		}
	}
	target = nil

	log.Printf("[TCP][%s] %s <-> %s", r.ListenAddr, client.RemoteAddr(), r.RemoteAddr)

	go func() {
		io.CopyBuffer(remote, client, make([]byte, 1446))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
	}()

	io.CopyBuffer(client, remote, buffer)
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
}
