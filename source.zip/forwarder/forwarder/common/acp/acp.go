package acp

import (
	"net"
	"sync"
	"time"

	"ryzen.moe/forwarder/forwarder/common/dns"
	"ryzen.moe/forwarder/forwarder/structs"
)

const (
	minconn int   = 10
	maxidle int64 = 10
)

type idleConn struct {
	net.Conn

	Unix int64
}

type Pool struct {
	sync.RWMutex

	channel chan *idleConn
	newConn func() (net.Conn, error)
}

func (s *Pool) Get() (net.Conn, error) {
	date := time.Now().Unix()

	s.RLock()
	for {
		select {
		case idle := <-s.channel:
			if date-idle.Unix > maxidle {
				idle.Close()
				continue
			}

			s.RUnlock()
			return idle.Conn, nil
		default:
			s.RUnlock()
			return s.newConn()
		}
	}
}

func (s *Pool) Run() {
	wg := &sync.WaitGroup{}

	for {
		s.Lock()
		size := minconn - len(s.channel)
		if size <= 0 {
			s.Unlock()

			time.Sleep(time.Millisecond * 200)
			continue
		}
		s.Unlock()

		wg.Add(size)
		for i := 0; i < size; i++ {
			go func() {
				conn, err := s.newConn()
				if err != nil {
					wg.Done()
					return
				}

				s.channel <- &idleConn{Conn: conn, Unix: time.Now().Unix()}
				wg.Done()
			}()
		}
		wg.Wait()
	}
}

func NewPool(create func() (net.Conn, error)) *Pool {
	haveged := &Pool{
		channel: make(chan *idleConn, minconn),
		newConn: create,
	}
	go haveged.Run()

	return haveged
}

var (
	mtx sync.Mutex
	mux = &sync.Map{}
)

func Dial(r *structs.Forwarder) (net.Conn, error) {
	if !r.UseC {
		return dialConn(r)
	}

	mtx.Lock()
	dialer, ok := mux.Load(r.RemoteAddr)
	if !ok {
		dialer = NewPool(func() (net.Conn, error) { return dialConn(r) })

		mux.Store(r.RemoteAddr, dialer)
	}
	mtx.Unlock()

	return dialer.(*Pool).Get()
}

func dialConn(r *structs.Forwarder) (net.Conn, error) {
	dialer := net.Dialer{
		Timeout:   time.Second * 3,
		KeepAlive: time.Second * 9,
	}
	if r.Binder != nil {
		dialer.LocalAddr = &net.TCPAddr{IP: r.Binder}
	}

	addr, err := dns.Fetch(r.RemoteAddr)
	if err != nil {
		return nil, err
	}

	return dialer.Dial("tcp", addr)
}
