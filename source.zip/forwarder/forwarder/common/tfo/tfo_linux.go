package tfo

import (
	"context"
	"net"
	"syscall"
	"time"

	"golang.org/x/sys/unix"
)

var (
	lc = net.ListenConfig{
		KeepAlive: time.Second * 9,
		Control: func(network, address string, c syscall.RawConn) error {
			return c.Control(func(fd uintptr) {
				_ = syscall.SetsockoptInt(int(fd), syscall.SOL_TCP, unix.TCP_FASTOPEN, 1)
			})
		},
	}
)

func Listen(network, address string) (net.Listener, error) {
	return lc.Listen(context.Background(), network, address)
}
