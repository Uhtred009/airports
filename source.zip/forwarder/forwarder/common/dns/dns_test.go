package dns

import "testing"

func TestDNS(t *testing.T) {
	for i := 0; i < 10; i++ {
		address, err := Fetch("www.baidu.com:80")
		if err != nil {
			t.Errorf("dns.Fetch: %v", err)
			continue
		}

		t.Logf("%s", address)
	}
}
