#!/usr/bin/env bash

if [[ "$1" == 'remove' ]]; then
    for i in $(ls scripts/build); do
        P1=$(echo $i | sed 's/\.sh//' | awk -F'-' '{print $1}')
        P2=$(echo $i | sed 's/\.sh//' | awk -F'-' '{print $2}')

        docker container rm -f "${P1}_${P2}"
    done

    exit 0
fi

echo 'BEGIN COMPILE: ' $(date -R)
go mod vendor
for i in $(ls scripts/build); do
    P1=$(echo $i | sed 's/\.sh//' | awk -F'-' '{print $1}')
    P2=$(echo $i | sed 's/\.sh//' | awk -F'-' '{print $2}')
    rm -fr release && mkdir release

    docker container run \
        --volume /usr/bin/garble:/usr/bin/garble \
        --volume /usr/local/go:/usr/local/go \
        --volume $(pwd):/opt \
        --user $(id -u $USER):$(id -g $USER) \
        --name "${P1}_${P2}" -d --rm $P1:$P2 \
        "/opt/scripts/build/$i" > /dev/null || exit $?
done

for i in $(ls scripts/build); do
    P1=$(echo $i | sed 's/\.sh//' | awk -F'-' '{print $1}')
    P2=$(echo $i | sed 's/\.sh//' | awk -F'-' '{print $2}')

    docker wait "${P1}_${P2}" > /dev/null 2>&1
done
echo 'END COMPILE: ' $(date -R)

echo 'BEGIN VMPROTECT: ' $(date -R)
for i in $(ls scripts/build); do
    P1=$(echo $i | sed 's/\.sh//' | awk -F'-' '{print $1}')
    P2=$(echo $i | sed 's/\.sh//' | awk -F'-' '{print $2}')

    /usr/local/vmp/vmprotect_con "release/$P1-$P2/forwarder" "release/$P1-$P2/forwarder" -pf default.vmp > /dev/null 2>&1 &
    chmod +x ./release/$P1-$P2/forwarder
done
wait
echo 'END VMPROTECT: ' $(date -R)
rm -fr vendor

cp -f example/* release
cp -f scripts/kickstart.sh release
zip -9 -r release.zip release

sha256sum release.zip
exit 0
