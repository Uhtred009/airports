package tools

import (
	"fmt"
	"net"
	"strconv"

	"inet.af/netaddr"
)

func Atoi(s string) int {
	i, _ := strconv.Atoi(s)

	return i
}

func GetAddrList() ([]net.IP, error) {
	list := make([]net.IP, 0)

	adap, err := net.Interfaces()
	if err != nil {
		return nil, fmt.Errorf("net.Interfaces: %v", err)
	}

	for i := 0; i < len(adap); i++ {
		adtr, err := adap[i].Addrs()
		if err != nil {
			continue
		}

		for x := 0; x < len(adtr); x++ {
			var addr net.IP

			switch v := adtr[x].(type) {
			case *net.IPNet:
				addr = v.IP
			case *net.IPAddr:
				addr = v.IP
			}

			ipar, ok := netaddr.FromStdIP(addr)
			if !ok {
				continue
			}

			if ipar.IsGlobalUnicast() {
				list = append(list, addr)
			}
		}
	}

	return list, nil
}

func GetAddrListByName(name string) ([]net.IP, error) {
	list := make([]net.IP, 0)

	adap, err := net.InterfaceByName(name)
	if err != nil {
		return nil, fmt.Errorf("net.Interfaces: %v", err)
	}

	adtr, err := adap.Addrs()
	if err != nil {
		return nil, fmt.Errorf("adap.Addrs: %v", err)
	}

	for x := 0; x < len(adtr); x++ {
		var addr net.IP

		switch v := adtr[x].(type) {
		case *net.IPNet:
			addr = v.IP
		case *net.IPAddr:
			addr = v.IP
		}

		ipar, ok := netaddr.FromStdIP(addr)
		if !ok {
			continue
		}

		if ipar.IsGlobalUnicast() {
			list = append(list, addr)
		}
	}

	return list, nil
}
