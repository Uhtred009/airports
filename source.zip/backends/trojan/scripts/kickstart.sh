#!/usr/bin/env bash
chmod +x trojan

[[ ! -d '/etc/trojan' ]]              && mkdir /etc/trojan
[[ ! -f '/etc/trojan/default.env' ]]  && cp -f example.env  /etc/trojan/default.env
[[ ! -f '/etc/trojan/default.json' ]] && cp -f example.json /etc/trojan/default.json
cp -f trojan           /usr/bin/trojan
cp -f example.service  /etc/systemd/system/trojan.service
cp -f example@.service /etc/systemd/system/trojan@.service

systemctl daemon-reload
exit 0
