package main

import (
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net"
	"os"
	"sync"
	"time"
)

var (
	flags struct {
		PATH string

		PORT string
		SNI  string
		CRT  string
		SEC  string
	}

	hashLock sync.RWMutex
	hashList = make(map[[56]byte]interface{})
)

func init() {
	flag.StringVar(&flags.PATH, "c", "/etc/trojan/default.json", "PATH")
	flag.Parse()

	flags.PORT = os.Getenv("PORT")
	flags.SNI = os.Getenv("SNI")
	flags.CRT = os.Getenv("CRT")
	flags.SEC = os.Getenv("SEC")
}

func main() {
	if err := nero(); err != nil {
		log.Printf("[APP] %v", err)
		return
	}

	tlsCert, err := tls.LoadX509KeyPair(flags.CRT, flags.SEC)
	if err != nil {
		log.Printf("[APP] tls.LoadX509KeyPair: %v", err)
		return
	}

	tlsConf := tls.Config{
		Certificates: []tls.Certificate{tlsCert},
		MinVersion:   tls.VersionTLS11,
		MaxVersion:   tls.VersionTLS13,
	}
	if flags.SNI != "" {
		tlsConf.VerifyConnection = func(info tls.ConnectionState) error {
			if info.ServerName != flags.SNI {
				return io.EOF
			}

			return nil
		}
	}

	lc := net.ListenConfig{
		KeepAlive: time.Second * 9,
	}

	ln, err := lc.Listen(context.Background(), "tcp", net.JoinHostPort("", flags.PORT))
	if err != nil {
		log.Printf("[APP] lc.Listen: %v", err)
		return
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			log.Printf("[APP] ln.Accept: %v", err)
			return
		}

		go tcpHandle(tls.Server(client, &tlsConf))
	}
}

func nero() error {
	data := []string{}

	buffer, err := ioutil.ReadFile(flags.PATH)
	if err != nil {
		return fmt.Errorf("ioutil.ReadFile: %v", err)
	}

	if err = json.Unmarshal(buffer, &data); err != nil {
		return fmt.Errorf("json.Unmarshal: %v", err)
	}

	for i := 0; i < len(data); i++ {
		var encode [56]byte

		checksum := sha256.Sum224([]byte(data[i]))
		hex.Encode(encode[:], checksum[:])

		hashList[encode] = nil
	}

	return nil
}
