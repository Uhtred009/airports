package main

import (
	"io"
	"log"
	"net"
	"time"

	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func tcpHandle(client net.Conn) {
	defer client.Close()

	buffer := make([]byte, 1400)
	if _, err := io.ReadFull(client, buffer[:59]); err != nil {
		return
	}

	{
		var hash [56]byte
		copy(hash[:], buffer[:56])

		hashLock.RLock()
		if _, ok := hashList[hash]; !ok {
			hashLock.RUnlock()
			return
		}
		hashLock.RUnlock()
	}

	target, err := socks.ReadAddr(client)
	if err != nil {
		return
	}

	if _, err = io.ReadFull(client, buffer[:2]); err != nil {
		return
	}

	if buffer[58] == 0x03 {
		log.Printf("[UDP] %s - %s", client.RemoteAddr(), target)

		udpHandle(client)
		return
	}

	dialer := net.Dialer{
		Timeout:   time.Second * 3,
		KeepAlive: time.Second * 9,
	}

	remote, err := dialer.Dial("tcp", target.String())
	if err != nil {
		return
	}
	defer remote.Close()

	log.Printf("[TCP] %s - %s (%s)", client.RemoteAddr(), target, remote.RemoteAddr())

	go func() {
		io.CopyBuffer(remote, client, make([]byte, 1400))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
	}()

	io.CopyBuffer(client, remote, buffer)
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
}
