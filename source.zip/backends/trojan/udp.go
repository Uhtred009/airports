package main

import (
	"encoding/binary"
	"io"
	"net"
	"time"

	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func udpHandle(client net.Conn) {
	remote, err := net.ListenPacket("udp", "")
	if err != nil {
		return
	}
	defer remote.Close()

	go func() {
		buffer := make([]byte, 1400)
		for {
			client.SetReadDeadline(time.Now().Add(time.Second * 10))
			target, err := socks.ReadAddr(client)
			if err != nil {
				break
			}

			targetUP, err := net.ResolveUDPAddr("udp", target.String())
			if err != nil {
				continue
			}

			if _, err = io.ReadFull(client, buffer[:4]); err != nil {
				break
			}

			length := int(binary.BigEndian.Uint16(buffer[:2]))
			if len(buffer) < length {
				buffer = make([]byte, length)
			}

			if _, err = io.ReadFull(client, buffer[:length]); err != nil {
				break
			}

			if _, err = remote.WriteTo(buffer[:length], targetUP); err != nil {
				break
			}
		}
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
	}()

	buffer := make([]byte, 1400)
	packed := make([]byte, 1400+1+16+2+2+2)
	for {
		remote.SetReadDeadline(time.Now().Add(time.Second * 10))
		size, from, err := remote.ReadFrom(buffer)
		if err != nil {
			break
		}

		addr := socks.ParseAddr(from.String())
		if addr == nil {
			break
		}

		copy(packed[0:], addr)
		copy(packed[len(addr)+2:], []byte{0x0d, 0x0a})
		copy(packed[len(addr)+2+2:], buffer[:size])
		binary.BigEndian.PutUint16(packed[len(addr):len(addr)+2], uint16(size))

		if _, err = client.Write(packed[:len(addr)+2+2+size]); err != nil {
			break
		}
	}
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
}
