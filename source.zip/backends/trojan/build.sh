#!/usr/bin/env bash
rm -fr release release.zip

export CGO_ENABLED='0'
export GOROOT_FINAL='/usr'

export GOOS='linux'
export GOARCH='amd64'
go build -a -trimpath -asmflags '-s -w' -ldflags '-s -w' -o release/trojan || exit $?

upx --ultra-brute release/trojan || exit $?

cp -f example/* release
cp -f scripts/kickstart.sh release

zip -9 -r release.zip release
sha256sum release.zip
exit 0
