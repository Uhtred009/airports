package main

import (
	"context"
	"fmt"
	"io"
	"log"
	"net"
	"strconv"
	"time"

	"github.com/database64128/tfo-go"
	"ryzen.moe/backends/dns"
	"ryzen.moe/backends/shadowsocks-aio/features/logging"
	"ryzen.moe/backends/shadowsocks-aio/tools"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func tcpServe(addr net.IP) {
	go func() {
		for {
			log.Printf("[TCP][%s] %v", addr.String(), tcpListen(addr))

			time.Sleep(time.Second * 3)
		}
	}()
}

func tcpListen(addr net.IP) error {
	lc := tfo.ListenConfig{
		ListenConfig: net.ListenConfig{
			KeepAlive: time.Second * 9,
		},
	}

	ln, err := lc.Listen(context.Background(), "tcp", net.JoinHostPort(addr.String(), strconv.Itoa(flags.PORT)))
	if err != nil {
		return fmt.Errorf("lc.Listen: %v", err)
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			return fmt.Errorf("ln.Accept: %v", err)
		}

		go tcpHandle(addr, client)
	}
}

func tcpHandle(addr net.IP, client net.Conn) {
	defer client.Close()

	date := time.Now().Unix()
	from := ""

	if flags.TRUEIP {
		data, err := socks.ReadAddr(client)
		if err != nil {
			client.Close()
			return
		}

		from = data.String()
	} else {
		from = client.RemoteAddr().String()
	}

	id := uint64(0)
	{
		host, _, err := net.SplitHostPort(from)
		if err != nil {
			host = from
		}

		id = tools.ChecksumCRC64(addr, []byte(host))
	}

	if SearchInstanceBlock(id) {
		return
	}

	client = NewTCPOBFS(client, id)
	target, err := socks.ReadAddr(client)
	if err != nil {
		return
	}

	targetHost, targetPort, err := net.SplitHostPort(target.String())
	if err != nil {
		return
	}

	targetIP, err := dns.Fetch(targetHost)
	if err != nil || targetIP == nil {
		return
	}

	if done, err := banned.Contains(targetIP); err == nil && done {
		return
	}

	dialer := net.Dialer{
		Timeout:   time.Second * 3,
		KeepAlive: time.Second * 9,
	}
	if flags.SISO {
		dialer.LocalAddr = &net.TCPAddr{IP: addr}
	} else if flags.DIAL != nil {
		dialer.LocalAddr = &net.TCPAddr{IP: flags.DIAL}
	}

	remote, err := dialer.Dial("tcp", net.JoinHostPort(targetIP.String(), targetPort))
	if err != nil {
		return
	}
	defer remote.Close()

	UP := int64(0)
	DL := int64(0)
	channel := make(chan int, 1)

	go func() {
		DL, _ = io.CopyBuffer(client, remote, make([]byte, flags.TCPBUFFERSIZE))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
		channel <- 1
	}()

	UP, _ = io.CopyBuffer(remote, client, make([]byte, flags.TCPBUFFERSIZE))
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
	<-channel

	log.Printf("[TCP][%s][%d - %d] %s - %s:%s (%s) [%.2fKB]",
		addr.String(),
		date,
		time.Now().Unix(),
		from,
		targetHost, targetPort,
		targetIP.String(),
		float64(UP+DL)/1024,
	)

	logging.Create(client.(*TCPOBFS).instance.UserInfo.ID, &logging.Record{
		Client:   from,
		Server:   addr.String(),
		Remote:   net.JoinHostPort(targetHost, targetPort),
		Length:   UP + DL,
		CreateAt: date,
		FinishAt: time.Now().Unix(),
	})
}
