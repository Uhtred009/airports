package dns

import (
	"context"
	"fmt"
	"net"
	"os"
	"strconv"
	"sync"
	"time"
)

var (
	DNS    string = "1.1.1.1:53"
	DNSTTL int64  = 120
	DNSIP4 bool   = true
	DNSIP6 bool   = false

	dialer = &net.Dialer{
		Timeout:   time.Second * 3,
		KeepAlive: time.Second * 9,
	}
	client = &net.Resolver{
		PreferGo: true,
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			return dialer.DialContext(ctx, network, DNS)
		},
	}

	dataLock sync.RWMutex
	dataList = make(map[string]*DNSRecord)
)

func init() {
	DNS = os.Getenv("DNS")

	if data := os.Getenv("DNSTTL"); data != "" {
		if i, err := strconv.Atoi(data); err == nil {
			DNSTTL = int64(i)
		}
	}

	if data := os.Getenv("DNSIP4"); data != "" {
		if i, err := strconv.ParseBool(data); err != nil {
			DNSIP4 = i
		}
	}

	if data := os.Getenv("DNSIP6"); data != "" {
		if i, err := strconv.ParseBool(data); err != nil {
			DNSIP6 = i
		}
	}

	go func() {
		for {
			time.Sleep(time.Second * 10)

			date := time.Now().Unix()
			dataLock.Lock()
			for id, data := range dataList {
				if date-data.Unix > DNSTTL {
					delete(dataList, id)
				}
			}
			dataLock.Unlock()
		}
	}()
}

func Fetch(name string) (net.IP, error) {
	if addr := net.ParseIP(name); addr != nil {
		return addr, nil
	}

	dataLock.RLock()
	if data, ok := dataList[name]; ok {
		dataLock.RUnlock()
		return data.Get(), nil
	}
	dataLock.RUnlock()

	ipv4, err := client.LookupIP(context.Background(), "ip4", name)
	if err != nil {
		if errno, ok := err.(*net.DNSError); !ok || !errno.IsNotFound {
			return nil, fmt.Errorf("client.LookupIP4: %v", err)
		}
	}

	ipv6, err := client.LookupIP(context.Background(), "ip6", name)
	if err != nil {
		if errno, ok := err.(*net.DNSError); !ok || !errno.IsNotFound {
			return nil, fmt.Errorf("client.LookupIP6: %v", err)
		}
	}

	data := &DNSRecord{
		Unix: time.Now().Unix(),

		IPv4: ipv4,
		IPv6: ipv6,
	}

	dataLock.Lock()
	dataList[name] = data
	dataLock.Unlock()

	return data.Get(), nil
}

type DNSRecord struct {
	Unix int64

	IPv4 []net.IP
	IPv6 []net.IP
}

func (o *DNSRecord) Get() net.IP {
	if DNSIP6 && len(o.IPv6) > 0 {
		return o.IPv6[0]
	}

	if DNSIP4 && len(o.IPv4) > 0 {
		return o.IPv4[0]
	}

	return nil
}
