package dns

import "testing"

func TestDNS(t *testing.T) {
	DNS = "119.29.29.29:53"

	DNSIP4 = true
	DNSIP6 = false
	t.Log(Fetch("www.baidu.com"))
	t.Log(Fetch("www.google.com"))

	DNSIP4 = false
	DNSIP6 = true
	t.Log(Fetch("www.baidu.com"))
	t.Log(Fetch("www.google.com"))
}
