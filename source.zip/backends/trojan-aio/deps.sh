#!/usr/bin/env bash
rm -f go.*

go mod init
go mod tidy
exit 0
