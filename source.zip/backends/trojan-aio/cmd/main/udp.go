package main

import (
	"encoding/binary"
	"io"
	"net"
	"strconv"
	"time"

	"ryzen.moe/backends/dns"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func udpHandle(addr net.IP, client net.Conn, instance *Instance) {
	bind := ""
	if flags.SISO {
		bind = addr.String()
	} else if flags.DIAL != nil {
		bind = flags.DIAL.String()
	}

	remote, err := net.ListenPacket("udp", net.JoinHostPort(bind, ""))
	if err != nil {
		return
	}
	defer remote.Close()

	go func() {
		buffer := make([]byte, flags.UDPBUFFERSIZE)
		for {
			client.SetReadDeadline(time.Now().Add(flags.UDPTIMEOUT))
			target, err := socks.ReadAddr(client)
			if err != nil {
				break
			}

			if _, err = io.ReadFull(client, buffer[:4]); err != nil {
				break
			}

			length := int(binary.BigEndian.Uint16(buffer[:2]))
			if len(buffer) < length {
				buffer = make([]byte, length)
			}

			if _, err = io.ReadFull(client, buffer[:length]); err != nil {
				break
			}
			instance.Bandwidth.IncreaseUP(int64(length))

			targetHost, targetPort, err := net.SplitHostPort(target.String())
			if err != nil {
				break
			}

			targetIP, err := dns.Fetch(targetHost)
			if err != nil {
				break
			}

			targetUP := net.UDPAddr{IP: targetIP}
			if targetUP.Port, err = strconv.Atoi(targetPort); err != nil {
				break
			}

			if _, err = remote.WriteTo(buffer[:length], &targetUP); err != nil {
				break
			}
		}
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
	}()

	buffer := make([]byte, flags.UDPBUFFERSIZE)
	packed := make([]byte, flags.UDPBUFFERSIZE+1+16+2+2+2)
	for {
		remote.SetReadDeadline(time.Now().Add(flags.UDPTIMEOUT))
		size, from, err := remote.ReadFrom(buffer)
		if err != nil {
			break
		}
		instance.Bandwidth.IncreaseDL(int64(size))

		addr := socks.ParseAddr(from.String())
		if addr == nil {
			break
		}

		copy(packed[0:], addr)
		copy(packed[len(addr)+2:], []byte{0x0d, 0x0a})
		copy(packed[len(addr)+2+2:], buffer[:size])
		binary.BigEndian.PutUint16(packed[len(addr):len(addr)+2], uint16(size))

		if _, err = client.Write(packed[:len(addr)+2+2+size]); err != nil {
			break
		}
	}
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
}
