package main

import (
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"log"
	"math/rand"
	"net"
	"os"
	"runtime"
	"strings"
	"time"

	"golang.org/x/crypto/chacha20poly1305"
	"ryzen.moe/backends/api"
	"ryzen.moe/backends/trojan-aio/tools"
)

var (
	flags struct {
		SYNCINTERVAL time.Duration

		BIND string
		PORT string
		DIAL net.IP
		SISO bool
		SNI  string
		CRT  string
		SEC  string
		TLS  bool

		TCP           bool
		TCPBUFFERSIZE int

		UDP           bool
		UDPTIMEOUT    time.Duration
		UDPBUFFERSIZE int

		TRUEIP bool
		STREAM bool

		AUTOGC     bool
		AUTOREBOOT bool
	}
)

func main() {
	log.Println("Premium Trojan Backend (AIO) v1.0.0")

	{
		ciph, _ := chacha20poly1305.NewX([]byte{
			0xb1, 0x8f, 0x33, 0x6b, 0xcf, 0x82, 0x59, 0x6b,
			0x10, 0x8f, 0x4d, 0xf6, 0xc8, 0xf0, 0x1c, 0x77,
			0x77, 0xd2, 0x67, 0x7e, 0xe7, 0x07, 0x9d, 0x8a,
			0x50, 0xac, 0x7b, 0x9e, 0xfe, 0xc9, 0x04, 0xbd,
		})

		data, err := base64.StdEncoding.DecodeString(os.Getenv("LICENSE"))
		if err != nil || len(data) < ciph.NonceSize()+ciph.Overhead() {
			return
		}

		if _, err = ciph.Open(data[ciph.NonceSize():ciph.NonceSize()], data[:ciph.NonceSize()], data[ciph.NonceSize():], nil); err != nil {
			return
		}

		size := int(binary.LittleEndian.Uint16(data[ciph.NonceSize() : ciph.NonceSize()+2]))
		date := int64(binary.LittleEndian.Uint64(data[ciph.NonceSize()+2+size : ciph.NonceSize()+2+size+8]))
		expr := int64(binary.LittleEndian.Uint64(data[ciph.NonceSize()+2+size+8 : ciph.NonceSize()+2+size+8+8]))
		cstr := string(data[ciph.NonceSize()+2 : ciph.NonceSize()+2+size])

		log.Printf("[LICENSE] %s", cstr)
		log.Printf("[LICENSE] %s (%d) -> %s (%d)", time.Unix(date, 0).Format("2006-01-02 15:04:05"), date, time.Unix(expr, 0).Format("2006-01-02 15:04:05"), expr)

		if time.Now().Unix()-date < 0 {
			return
		}

		if time.Now().Unix()-expr > 0 {
			return
		}
	}

	if err := nero(); err != nil {
		log.Printf("[APP] %v", err)
		return
	}

	{
		if flags.BIND != "" {
			list := strings.Split(flags.BIND, ",")
			for i := 0; i < len(list); i++ {
				if addr := net.ParseIP(list[i]); addr != nil {
					tcpServe(addr)
					continue
				}

				data, err := tools.GetAddrListByName(list[i])
				if err != nil {
					log.Printf("[APP] tools.GetAddrList: %v", err)
					return
				}

				for _, addr := range data {
					tcpServe(addr)
				}
			}
		} else {
			data, err := tools.GetAddrList()
			if err != nil {
				log.Printf("[APP] tools.GetAddrList: %v", err)
				return
			}

			for _, addr := range data {
				tcpServe(addr)
			}
		}
	}

	for {
		if err := UpdateUserBandwidth(); err != nil {
			log.Printf("[APP] update user bandwidth failed: %v", err)

			time.Sleep(time.Second * time.Duration(rand.Int63n(10)))
			continue
		}

		if err := UpdateUserList(); err != nil {
			log.Printf("[APP] update user list failed: %v", err)

			time.Sleep(time.Second * time.Duration(rand.Int63n(10)))
			continue
		}

		time.Sleep(flags.SYNCINTERVAL + (time.Duration(rand.Int63n(30)) * time.Second))
	}
}

func nero() error {
	flags.SYNCINTERVAL = time.Duration(tools.GetInt64("SYNCINTERVAL", 120)) * time.Second

	flags.BIND = os.Getenv("BIND")
	flags.PORT = os.Getenv("PORT")
	flags.DIAL = net.ParseIP(os.Getenv("DIAL"))
	flags.SISO = tools.GetBool("SISO", false)
	flags.SNI = os.Getenv("SNI")
	flags.CRT = os.Getenv("CRT")
	flags.SEC = os.Getenv("SEC")
	flags.TLS = tools.GetBool("TLS", true)

	flags.TCP = tools.GetBool("TCP", true)
	flags.TCPBUFFERSIZE = tools.GetInt("TCPBUFFERSIZE", 1400)

	flags.UDP = tools.GetBool("UDP", true)
	flags.UDPTIMEOUT = time.Duration(tools.GetInt64("UDPTIMEOUT", 10)) * time.Second
	flags.UDPBUFFERSIZE = tools.GetInt("UDPBUFFERSIZE", 1400)

	flags.TRUEIP = tools.GetBool("TRUEIP", false)
	flags.STREAM = tools.GetBool("STREAM", false)

	clean()
	reboot()
	return nil
}

func UpdateUserList() error {
	list, err := api.GetUserList()
	if err != nil {
		return fmt.Errorf("api.GetUserList: %v", err)
	}

	instanceLock.Lock()
	defer instanceLock.Unlock()

	instanceHashLock.Lock()
	defer instanceHashLock.Unlock()

	for i := 0; i < len(list); i++ {
		instance, ok := instanceList[list[i].ID]
		if !ok {
			continue
		}

		if !list[i].Equals(instance.UserInfo) {
			delete(instanceList, list[i].ID)
			delete(instanceHashList, instance.KDF)
		}
	}

	for i := 0; i < len(list); i++ {
		if _, ok := instanceList[list[i].ID]; !ok {
			instance := NewInstance(list[i])

			instanceList[list[i].ID] = instance
			instanceHashList[instance.KDF] = list[i].ID
		}
	}

	for id, instance := range instanceList {
		ok := false

		for i := 0; i < len(list); i++ {
			if list[i].ID == id {
				ok = true
			}
		}

		if !ok {
			delete(instanceList, id)
			delete(instanceHashList, instance.KDF)
		}
	}

	return nil
}

func UpdateUserBandwidth() error {
	list := make(api.UserBandwidthList, 0)

	instanceLock.RLock()
	for id, instance := range instanceList {
		UP := instance.Bandwidth.GetUP()
		DL := instance.Bandwidth.GetDL()
		if UP <= 0 && DL <= 0 {
			continue
		}

		list = append(list, &api.UserBandwidth{
			ID: id,
			UP: UP,
			DL: DL,
		})
	}
	instanceLock.RUnlock()

	if err := api.UpdateUserBandwidthList(list); err != nil {
		return fmt.Errorf("api.UpdateUserBandwidthList: %v", err)
	}

	instanceLock.RLock()
	for i := 0; i < len(list); i++ {
		instanceList[list[i].ID].Bandwidth.DecreaseUP(list[i].UP)
		instanceList[list[i].ID].Bandwidth.DecreaseDL(list[i].DL)
	}
	instanceLock.RUnlock()

	return nil
}

func clean() {
	if flags.AUTOGC {
		return
	}

	go func() {
		stats := runtime.MemStats{}
		for {
			time.Sleep(time.Minute * 30)

			runtime.GC()
			runtime.ReadMemStats(&stats)
			log.Printf("[GC] Fraction %f", stats.GCCPUFraction)
			log.Printf("[GC] Obtained %dMB", stats.Sys/1024/1024)
			log.Printf("[GC] Assigned %dMB", stats.Alloc/1024/1024)
			log.Printf("[GC] Routine %d", runtime.NumGoroutine())
		}
	}()
}

func reboot() {
	if flags.AUTOREBOOT {
		return
	}

	go func() {
		zone := time.FixedZone("Asia/Shanghai", int((time.Hour * 8).Seconds()))
		date, err := time.ParseInLocation("2006-01-02", time.Now().In(zone).Format("2006-01-02"), zone)
		if err != nil {
			return
		}

		diff := date.AddDate(0, 0, 1).Add(time.Hour * 4).Add(time.Minute * 10).Sub(time.Now().In(zone))
		log.Printf("[REBOOT] Scheduled after %s", diff)

		time.Sleep(diff)
		time.Sleep(time.Second * time.Duration(rand.Intn(600)))
		os.Exit(0)
	}()
}
