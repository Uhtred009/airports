#!/usr/bin/env bash
apt update || exit $?
apt dist-upgrade -y || exit $?
apt install lsb-release -y || exit $?
apt autoremove --purge -y || exit $?

name=''
case $(lsb_release -cs) in
    'bookworm') # Debian 12
        name='debian-bookworm'
        ;;
    'bullseye') # Debian 11
        name='debian-bullseye'
        ;;
    'buster')   # Debian 10
        name='debian-buster'
        ;;
    'stretch')  # Debian 9
        name='debian-stretch'
        ;;
    'jammy')    # Ubuntu 22.04
        name='ubuntu-jammy'
        ;;
    'impish')   # Ubuntu 21.10
        name='ubuntu-impish'
        ;;
    'focal')    # Ubuntu 20.04
        name='ubuntu-focal'
        ;;
    'bionic')   # Ubuntu 18.04
        name='ubuntu-bionic'
        ;;
    *)
        exit 1
esac

if [[ ! -d '/etc/trojan-aio' ]]; then
    mkdir /etc/trojan-aio
fi

if [[ ! -f '/etc/trojan-aio/default.env' ]]; then
    cp -f example.env /etc/trojan-aio/default.env
fi

cp -f "./$name/trojan-aio" .
chmod +x trojan-aio

cp -f trojan-aio /usr/bin
cp -f example.service /etc/systemd/system/trojan-aio.service
cp -f example@.service /etc/systemd/system/trojan-aio@.service
systemctl daemon-reload
exit 0
