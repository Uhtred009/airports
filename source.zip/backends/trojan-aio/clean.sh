#!/usr/bin/env bash
rm -fr vendor release release.zip
exit 0
