package main

import (
	"fmt"
	"io"
	"log"
	"net"
	"time"

	"ryzen.moe/backends/dns"
	"ryzen.moe/backends/shadowsocksr-aio/features/logging"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func tcpServe(addr net.IP) {
	go func() {
		for {
			log.Printf("[TCP][%s] %v", addr, tcpListen(addr))

			time.Sleep(time.Second * 3)
		}
	}()
}

func tcpListen(addr net.IP) error {
	ln, err := net.Listen("tcp", net.JoinHostPort(addr.String(), flags.PORT))
	if err != nil {
		return fmt.Errorf("net.Listen: %v", err)
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			return fmt.Errorf("ln.Accept: %v", err)
		}

		go tcpHandle(addr, client)
	}
}

func tcpHandle(addr net.IP, client net.Conn) {
	defer client.Close()

	date := time.Now().Unix()
	from := client.RemoteAddr().String()
	if flags.TRUEIP {
		fromaddr, err := socks.ReadAddr(client)
		if err != nil {
			return
		}

		from = fromaddr.String()
	}
	client = instanceCiph.StreamConn(client)
	client = NewTCPOBFS(client)

	target, err := socks.ReadAddr(client)
	if err != nil {
		return
	}

	targetHost, targetPort, err := net.SplitHostPort(target.String())
	if err != nil {
		return
	}

	targetIP, err := dns.Fetch(targetHost)
	if err != nil || targetIP == nil {
		return
	}

	if done, err := banned.Contains(targetIP); err == nil && done {
		return
	}

	dialer := net.Dialer{
		Timeout:   time.Second * 3,
		KeepAlive: time.Second * 9,
	}
	if flags.SISO {
		dialer.LocalAddr = &net.TCPAddr{IP: addr}
	} else if flags.DIAL != nil {
		dialer.LocalAddr = &net.TCPAddr{IP: flags.DIAL}
	}

	remote, err := dialer.Dial("tcp", net.JoinHostPort(targetIP.String(), targetPort))
	if err != nil {
		return
	}
	defer remote.Close()

	UP := int64(0)
	DL := int64(0)
	channel := make(chan int, 1)

	go func() {
		UP, _ = io.CopyBuffer(client, remote, make([]byte, flags.TCPBUFFERSIZE))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
		channel <- 1
	}()

	DL, _ = io.CopyBuffer(remote, client, make([]byte, flags.TCPBUFFERSIZE))
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
	<-channel

	log.Printf("[TCP][%s][%d - %d] %s - %s:%s (%s) [%.2fKB]",
		addr,
		date,
		time.Now().Unix(),
		from,
		targetHost,
		targetPort,
		targetIP,
		float64(UP+DL)/1024,
	)

	logging.Create(client.(*TCPOBFS).instance.UserInfo.ID, &logging.Record{
		Client:   from,
		Server:   addr.String(),
		Remote:   net.JoinHostPort(targetHost, targetPort),
		Length:   UP + DL,
		CreateAt: date,
		FinishAt: time.Now().Unix(),
	})
}
