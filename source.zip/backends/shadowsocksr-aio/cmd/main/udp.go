package main

import (
	"fmt"
	"log"
	"net"
	"sync"
	"time"

	"ryzen.moe/backends/dns"
	"ryzen.moe/backends/shadowsocksr-aio/tools"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func udpServe(addr net.IP) {
	go func() {
		for {
			log.Printf("[UDP][%s] %v", addr, udpListen(addr))

			time.Sleep(time.Second * 3)
		}
	}()
}

func udpListen(addr net.IP) error {
	ln, err := net.ListenPacket("udp", net.JoinHostPort(addr.String(), flags.PORT))
	if err != nil {
		return fmt.Errorf("net.ListenPacket: %v", err)
	}
	ln = instanceCiph.PacketConn(ln)
	defer ln.Close()

	nm := NewNAT()
	buffer := make([]byte, flags.UDPBUFFERSIZE)

	for {
		size, from, err := ln.ReadFrom(buffer)
		if err != nil {
			return fmt.Errorf("ln.ReadFrom: %v", err)
		}

		target := socks.SplitAddr(buffer)
		if target == nil {
			continue
		}

		targetHost, targetPort, err := net.SplitHostPort(target.String())
		if err != nil {
			continue
		}

		targetIP, err := dns.Fetch(targetHost)
		if err != nil {
			continue
		}

		if done, err := banned.Contains(targetIP); err == nil && done {
			continue
		}

		targetUP, err := net.ResolveUDPAddr("udp", net.JoinHostPort(targetIP.String(), targetPort))
		if err != nil {
			continue
		}

		remote := nm.Get(from.String())
		if remote == nil {
			remote = NewUDPOBFS()
			if err = remote.Decode(buffer[:size]); err != nil {
				continue
			}

			bind := ""
			if flags.SISO {
				bind = addr.String()
			} else if flags.DIAL != nil {
				bind = flags.DIAL.String()
			}

			conn, err := net.ListenPacket("udp", net.JoinHostPort(bind, ""))
			if err != nil {
				continue
			}

			remote.PacketConn = conn
			nm.Create(from, ln, remote)

			log.Printf("[UDP][%s] %s - %s:%s (%s)",
				addr,
				from,
				targetHost,
				targetPort,
				targetIP,
			)
		}

		if _, err = remote.WriteTo(buffer[len(target):size-8], targetUP); err != nil {
			nm.Delete(from.String())
		}
	}
}

type NAT struct {
	sync.RWMutex

	m map[string]*UDPOBFS
}

func NewNAT() *NAT {
	data := new(NAT)
	data.m = make(map[string]*UDPOBFS)

	return data
}

func (o *NAT) Get(id string) *UDPOBFS {
	o.RLock()
	defer o.RUnlock()

	return o.m[id]
}

func (o *NAT) Set(id string, data *UDPOBFS) {
	o.Lock()
	defer o.Unlock()

	o.m[id] = data
}

func (o *NAT) Create(from net.Addr, client net.PacketConn, remote *UDPOBFS) {
	o.Set(from.String(), remote)

	go func(target net.Addr, client net.PacketConn, remote *UDPOBFS) {
		buffer := make([]byte, flags.UDPBUFFERSIZE)

		for {
			remote.SetReadDeadline(time.Now().Add(flags.UDPTIMEOUT))
			size, from, err := remote.ReadFrom(buffer)
			if err != nil {
				break
			}

			source := socks.ParseAddr(from.String())
			length := len(source) + size + 4
			if length > flags.UDPBUFFERSIZE {
				continue
			}

			copy(buffer[len(source):], buffer[:size])
			copy(buffer, source)
			copy(buffer[length-4:], tools.HMAC(newHashMethod, flags.SECRET, buffer[:length-4])[:4])

			if _, err = client.WriteTo(buffer[:length], target); err != nil {
				break
			}
		}

		o.Delete(target.String())
	}(from, client, remote)
}

func (o *NAT) Delete(id string) {
	o.Lock()
	defer o.Unlock()

	data, ok := o.m[id]
	if ok {
		delete(o.m, id)
		data.Close()
	}
}
