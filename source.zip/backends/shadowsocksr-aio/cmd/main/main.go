package main

import (
	"crypto/md5"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"hash"
	"log"
	"math/rand"
	"net"
	"os"
	"runtime"
	"strings"
	"time"

	"golang.org/x/crypto/chacha20poly1305"
	"ryzen.moe/backends/api"
	"ryzen.moe/backends/shadowsocksr-aio/tools"
	"ryzen.moe/shadowsocks/shadowsocks/core"
)

var (
	flags struct {
		SYNCINTERVAL time.Duration

		BIND   string
		DIAL   net.IP
		PORT   string
		SISO   bool
		PASSWD string
		METHOD string
		PROTOC string

		TCP           bool
		TCPBUFFERSIZE int

		UDP           bool
		UDPTIMEOUT    time.Duration
		UDPBUFFERSIZE int

		TRUEIP bool
		STREAM bool

		AUTOGC     bool
		AUTOREBOOT bool

		SECRET []byte
	}

	cipherList = map[string]int{
		"RC4-MD5":       16,
		"AES-128-CTR":   16,
		"AES-192-CTR":   24,
		"AES-256-CTR":   32,
		"AES-128-CFB":   16,
		"AES-192-CFB":   24,
		"AES-256-CFB":   32,
		"CHACHA20":      32,
		"CHACHA20-IETF": 32,
		"XCHACHA20":     32,
	}
	newHashMethod func() hash.Hash
)

func main() {
	log.Println("Premium ShadowsocksR Backend (AIO) v1.0.0")

	{
		ciph, _ := chacha20poly1305.NewX([]byte{
			0x94, 0x46, 0xbe, 0x2a, 0x04, 0xcc, 0xd3, 0x7a,
			0x96, 0x84, 0x1e, 0xe2, 0x37, 0x1e, 0x0b, 0x5a,
			0xd3, 0x39, 0x08, 0x52, 0xd2, 0x2e, 0x4d, 0x17,
			0x3b, 0x4d, 0x94, 0x80, 0xfc, 0x48, 0x58, 0x2d,
		})

		data, err := base64.StdEncoding.DecodeString(os.Getenv("LICENSE"))
		if err != nil {
			return
		}

		if _, err = ciph.Open(data[ciph.NonceSize():ciph.NonceSize()], data[:ciph.NonceSize()], data[ciph.NonceSize():], nil); err != nil {
			return
		}

		size := int(binary.LittleEndian.Uint16(data[ciph.NonceSize() : ciph.NonceSize()+2]))
		date := int64(binary.LittleEndian.Uint64(data[ciph.NonceSize()+2+size : ciph.NonceSize()+2+size+8]))
		expr := int64(binary.LittleEndian.Uint64(data[ciph.NonceSize()+2+size+8 : ciph.NonceSize()+2+size+8+8]))
		cstr := string(data[ciph.NonceSize()+2 : ciph.NonceSize()+2+size])

		log.Printf("%s", cstr)
		log.Printf("%s (%d) -> %s (%d)", time.Unix(date, 0).Format("2006-01-02 15:04:05"), date, time.Unix(expr, 0).Format("2006-01-02 15:04:05"), expr)

		if time.Now().Unix()-date < 0 {
			return
		}

		if time.Now().Unix()-expr > 0 {
			return
		}
	}

	if err := nero(); err != nil {
		log.Printf("[APP] %v", err)
		return
	}

	{
		if flags.BIND != "" {
			list := strings.Split(flags.BIND, ",")
			for i := 0; i < len(list); i++ {
				if addr := net.ParseIP(list[i]); addr != nil {
					if flags.TCP {
						tcpServe(addr)
					}

					if flags.UDP {
						udpServe(addr)
					}

					continue
				}

				data, err := tools.GetAddrListByName(list[i])
				if err != nil {
					log.Printf("[APP] tools.GetAddrList: %v", err)
					return
				}

				for _, addr := range data {
					if flags.TCP {
						tcpServe(addr)
					}

					if flags.UDP {
						udpServe(addr)
					}
				}
			}
		} else {
			data, err := tools.GetAddrList()
			if err != nil {
				log.Printf("[APP] tools.GetAddrList: %v", err)
				return
			}

			for _, addr := range data {
				if flags.TCP {
					tcpServe(addr)
				}

				if flags.UDP {
					udpServe(addr)
				}
			}
		}
	}

	for {
		if err := UpdateUserBandwidth(); err != nil {
			log.Printf("[APP] update user bandwidth failed: %v", err)

			time.Sleep(time.Second * time.Duration(rand.Int63n(10)))
			continue
		}

		if err := UpdateUserList(); err != nil {
			log.Printf("[APP] update user list failed: %v", err)

			time.Sleep(time.Second * time.Duration(rand.Int63n(10)))
			continue
		}

		time.Sleep(flags.SYNCINTERVAL + (time.Duration(rand.Int63n(30)) * time.Second))
	}
}

func nero() error {
	flags.SYNCINTERVAL = time.Duration(tools.GetInt64("SYNCINTERVAL", 120)) * time.Second

	flags.BIND = os.Getenv("BIND")
	flags.DIAL = net.ParseIP(os.Getenv("DIAL"))
	flags.PORT = os.Getenv("PORT")
	flags.SISO = tools.GetBool("SISO", false)
	flags.PASSWD = os.Getenv("PASSWD")
	flags.METHOD = strings.ToUpper(os.Getenv("METHOD"))
	flags.PROTOC = os.Getenv("PROTOC")

	flags.TCP = tools.GetBool("TCP", true)
	flags.TCPBUFFERSIZE = tools.GetInt("TCPBUFFERSIZE", 1024)

	flags.UDP = tools.GetBool("UDP", true)
	flags.UDPTIMEOUT = time.Duration(tools.GetInt64("UDPTIMEOUT", 10)) * time.Second
	flags.UDPBUFFERSIZE = tools.GetInt("TCPBUFFERSIZE", 1024)

	flags.TRUEIP = tools.GetBool("TRUEIP", false)
	flags.STREAM = tools.GetBool("STREAM", false)

	flags.AUTOGC = tools.GetBool("AUTOGC", true)
	flags.AUTOREBOOT = tools.GetBool("AUTOREBOOT", true)

	{
		switch flags.PROTOC {
		case "auth_aes128_md5":
			newHashMethod = md5.New
		case "auth_aes128_sha1":
			newHashMethod = sha1.New
		default:
			return fmt.Errorf("unknown protocol type: %s", flags.PROTOC)
		}
	}

	{
		var err error

		size, ok := cipherList[flags.METHOD]
		if !ok {
			return fmt.Errorf("unsupported encryption method: %s", flags.METHOD)
		}
		flags.SECRET = tools.KDF(flags.PASSWD, size)

		instanceCiph, err = core.PickCipher(flags.METHOD, flags.SECRET, flags.PASSWD)
		if err != nil {
			return fmt.Errorf("core.PickCipher: %v", err)
		}
	}

	if flags.AUTOGC {
		go clean()
	}

	if flags.AUTOREBOOT {
		go reboot()
	}

	return nil
}

func UpdateUserList() error {
	list, err := api.GetUserList()
	if err != nil {
		return fmt.Errorf("api.GetUserList: %v", err)
	}

	instanceLock.Lock()
	defer instanceLock.Unlock()

	instanceHashLock.Lock()
	defer instanceHashLock.Unlock()

	for i := 0; i < len(list); i++ {
		instance, ok := instanceList[list[i].ID]
		if !ok {
			continue
		}

		if !list[i].Equals(instance.UserInfo) {
			delete(instanceList, list[i].ID)
		}
	}

	for i := 0; i < len(list); i++ {
		if _, ok := instanceList[list[i].ID]; !ok {
			instanceList[list[i].ID] = NewInstance(list[i])
			instanceHashList[list[i].Port] = list[i].ID
		}
	}

	for id, instance := range instanceList {
		ok := false

		for i := 0; i < len(list); i++ {
			if list[i].ID == id {
				ok = true
			}
		}

		if !ok {
			delete(instanceList, id)
			delete(instanceHashList, instance.UserInfo.Port)
		}
	}

	return nil
}

func UpdateUserBandwidth() error {
	list := make(api.UserBandwidthList, 0)

	instanceLock.RLock()
	for id, instance := range instanceList {
		UP := instance.Bandwidth.GetUP()
		DL := instance.Bandwidth.GetDL()
		if UP <= 0 && DL <= 0 {
			continue
		}

		list = append(list, &api.UserBandwidth{
			ID: id,
			UP: UP,
			DL: DL,
		})
	}
	instanceLock.RUnlock()

	if err := api.UpdateUserBandwidthList(list); err != nil {
		return fmt.Errorf("api.UpdateUserBandwidthList: %v", err)
	}

	instanceLock.RLock()
	for i := 0; i < len(list); i++ {
		instanceList[list[i].ID].Bandwidth.DecreaseUP(list[i].UP)
		instanceList[list[i].ID].Bandwidth.DecreaseDL(list[i].DL)
	}
	instanceLock.RUnlock()

	return nil
}

func clean() {
	stats := runtime.MemStats{}
	for {
		time.Sleep(time.Minute * 30)

		runtime.GC()
		runtime.ReadMemStats(&stats)
		log.Printf("[GC] Fraction %f", stats.GCCPUFraction)
		log.Printf("[GC] Obtained %dMB", stats.Sys/1024/1024)
		log.Printf("[GC] Assigned %dMB", stats.Alloc/1024/1024)
		log.Printf("[GC] Routine %d", runtime.NumGoroutine())
	}
}

func reboot() {
	zone := time.FixedZone("Asia/Shanghai", int((time.Hour * 8).Seconds()))
	date, err := time.ParseInLocation("2006-01-02", time.Now().In(zone).Format("2006-01-02"), zone)
	if err != nil {
		return
	}

	diff := date.AddDate(0, 0, 1).Add(time.Hour * 4).Add(time.Minute * 10).Sub(time.Now().In(zone))
	log.Printf("[REBOOT] Scheduled after %s", diff)

	time.Sleep(diff)
	time.Sleep(time.Second * time.Duration(rand.Intn(300)))
	os.Exit(0)
}
