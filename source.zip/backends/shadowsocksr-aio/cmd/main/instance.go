package main

import (
	"net"
	"sync"

	"github.com/yl2chen/cidranger"
	"ryzen.moe/backends/api"
	"ryzen.moe/backends/shadowsocksr-aio/tools"
	"ryzen.moe/shadowsocks/shadowsocks/core"
)

var (
	banned cidranger.Ranger

	instanceCiph core.Cipher

	instanceLock sync.RWMutex
	instanceList = make(map[int64]*Instance)

	instanceHashLock sync.RWMutex
	instanceHashList = make(map[int]int64)
)

func init() {
	list := []string{
		"0.0.0.0/8",
		"10.0.0.0/8",
		"100.64.0.0/10",
		"127.0.0.0/8",
		"169.254.0.0/16",
		"172.16.0.0/12",
		"192.0.0.0/24",
		"192.0.2.0/24",
		"192.88.99.0/24",
		"192.168.0.0/16",
		"198.18.0.0/15",
		"198.51.100.0/24",
		"203.0.113.0/24",
		"224.0.0.0/4",
		"233.252.0.0/24",
		"240.0.0.0/4",
		"255.255.255.255/32",
		"::1/128",
		"fc00::/7",
		"fe80::/10",
		"fd00::/8",
	}

	banned = cidranger.NewPCTrieRanger()
	for i := 0; i < len(list); i++ {
		_, cidr, _ := net.ParseCIDR(list[i])

		banned.Insert(cidranger.NewBasicRangerEntry(*cidr))
	}
}

type Instance struct {
	Passwd []byte

	UserInfo  *api.UserInfo
	Bandwidth *Bandwidth
}

func NewInstance(info *api.UserInfo) *Instance {
	instance := new(Instance)
	instance.Passwd = tools.Sum(newHashMethod, []byte(info.Passwd))
	instance.UserInfo = info
	instance.Bandwidth = NewBandwidth()

	return instance
}

func GetInstance(name uint32) *Instance {
	instanceHashLock.RLock()
	id, ok := instanceHashList[int(name)]
	if !ok {
		instanceHashLock.RUnlock()
		return nil
	}
	instanceHashLock.RUnlock()

	instanceLock.RLock()
	instance, ok := instanceList[id]
	if !ok {
		instanceLock.RUnlock()
		return nil
	}
	instanceLock.RUnlock()

	return instance
}
