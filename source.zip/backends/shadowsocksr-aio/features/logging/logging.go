package logging

import (
	"database/sql"
	"fmt"
	"log"
	"os"
	"sync"
	"time"

	"ryzen.moe/backends/shadowsocksr-aio/tools"

	_ "github.com/ClickHouse/clickhouse-go/v2"
)

type Record struct {
	Client   string `json:"client"`
	Server   string `json:"server"`
	Remote   string `json:"remote"`
	Length   int64  `json:"length"`
	CreateAt int64  `json:"create_at"`
	FinishAt int64  `json:"finish_at"`
}

var (
	LOG bool

	mtx sync.Mutex
	mux = make(map[int64][]*Record)
)

func init() {
	LOG = tools.GetBool("LOG", false)

	if LOG {
		go func() {
			for {
				time.Sleep(time.Second * 30)

				if err := Submit(); err != nil {
					log.Printf("[LOGGING] %v", err)
				}
			}
		}()
	}
}

func newConn() (*sql.DB, error) {
	client, err := sql.Open("clickhouse", os.Getenv("LOGDSN"))
	if err != nil {
		return nil, fmt.Errorf("sql.Open: %v", err)
	}
	client.SetConnMaxLifetime(time.Second * 30)
	client.SetConnMaxIdleTime(time.Second * 10)
	client.SetMaxOpenConns(4)
	client.SetMaxIdleConns(1)

	if err = client.Ping(); err != nil {
		client.Close()
		return nil, fmt.Errorf("client.Ping: %v", err)
	}

	return client, nil
}

func Create(id int64, r *Record) {
	if !LOG {
		return
	}

	mtx.Lock()
	list, ok := mux[id]
	if !ok {
		list = make([]*Record, 0)
	}
	mux[id] = append(list, r)
	mtx.Unlock()
}

func Submit() error {
	client, err := newConn()
	if err != nil {
		return fmt.Errorf("newConn: %v", err)
	}
	defer client.Close()

	mtx.Lock()
	data := mux
	mux = make(map[int64][]*Record)
	mtx.Unlock()

	for id, list := range data {
		tx, err := client.Begin()
		if err != nil {
			return fmt.Errorf("client.Begin: %v", err)
		}

		if _, err = tx.Exec(fmt.Sprintf(`
			CREATE TABLE IF NOT EXISTS %d (
				id        UUID,
				client    String,
				server    String,
				remote    String,
				length    Int64,
				create_at Int64,
				finish_at Int64,
			) Engine = StripeLog
		`, id)); err != nil {
			return fmt.Errorf("tx.Exec: %v", err)
		}

		for i := 0; i < len(list); i++ {
			if _, err = tx.Exec(fmt.Sprintf(
				"INSERT INTO %d (id, client, server, remote, length, create_at, finish_at) VALUES (generateUUIDv4(), '%s', '%s', '%s', %d, %d, %d)",
				id,
				list[i].Client,
				list[i].Server,
				list[i].Remote,
				list[i].Length,
				list[i].CreateAt,
				list[i].FinishAt,
			)); err != nil {
				return fmt.Errorf("tx.Exec: %v", err)
			}
		}

		if err = tx.Commit(); err != nil {
			return fmt.Errorf("tx.Commit: %v", err)
		}
	}

	return nil
}
