package tools

import (
	"crypto/hmac"
	"crypto/md5"
	"fmt"
	"hash"
	"net"
	"os"
	"strconv"

	"inet.af/netaddr"
)

func Sum(h func() hash.Hash, data []byte) []byte {
	m := h()
	_, _ = m.Write(data)

	return m.Sum(nil)
}

func KDF(s string, length int) []byte {
	var a, b []byte
	h := md5.New()

	for len(a) < length {
		_, _ = h.Write(b)
		_, _ = h.Write([]byte(s))
		a = h.Sum(a)
		b = a[len(a)-h.Size():]
		h.Reset()
	}

	return a[:length]
}

func HMAC(h func() hash.Hash, k []byte, data []byte) []byte {
	m := hmac.New(h, k)
	_, _ = m.Write(data)

	return m.Sum(nil)[:10]
}

func GetBool(name string, value bool) bool {
	if v, ok := os.LookupEnv(name); ok {
		if i, err := strconv.ParseBool(v); err == nil {
			return i
		}
	}

	return value
}

func GetInt(name string, value int) int {
	if v, ok := os.LookupEnv(name); ok {
		if i, err := strconv.Atoi(v); err == nil {
			return i
		}
	}

	return value
}

func GetInt64(name string, value int64) int64 {
	if v, ok := os.LookupEnv(name); ok {
		if i, err := strconv.ParseInt(v, 10, 64); err == nil {
			return i
		}
	}

	return value
}

func GetAddrList() ([]net.IP, error) {
	list := make([]net.IP, 0)

	adap, err := net.Interfaces()
	if err != nil {
		return nil, fmt.Errorf("net.Interfaces: %v", err)
	}

	for i := 0; i < len(adap); i++ {
		adtr, err := adap[i].Addrs()
		if err != nil {
			continue
		}

		for x := 0; x < len(adtr); x++ {
			var addr net.IP

			switch v := adtr[x].(type) {
			case *net.IPNet:
				addr = v.IP
			case *net.IPAddr:
				addr = v.IP
			}

			ipar, ok := netaddr.FromStdIP(addr)
			if !ok {
				continue
			}

			if ipar.IsGlobalUnicast() {
				list = append(list, addr)
			}
		}
	}

	return list, nil
}

func GetAddrListByName(name string) ([]net.IP, error) {
	list := make([]net.IP, 0)

	adap, err := net.InterfaceByName(name)
	if err != nil {
		return nil, fmt.Errorf("net.Interfaces: %v", err)
	}

	adtr, err := adap.Addrs()
	if err != nil {
		return nil, fmt.Errorf("adap.Addrs: %v", err)
	}

	for x := 0; x < len(adtr); x++ {
		var addr net.IP

		switch v := adtr[x].(type) {
		case *net.IPNet:
			addr = v.IP
		case *net.IPAddr:
			addr = v.IP
		}

		ipar, ok := netaddr.FromStdIP(addr)
		if !ok {
			continue
		}

		if ipar.IsGlobalUnicast() {
			list = append(list, addr)
		}
	}

	return list, nil
}
