package api

type UserInfo struct {
	ID     int64
	Port   int
	Uuid   string
	Passwd string
}
type UserList []*UserInfo

func (o *UserInfo) Equals(info *UserInfo) bool {
	return o.ID == info.ID && o.Port == info.Port && o.Uuid == info.Uuid && o.Passwd == info.Passwd
}

type UserBandwidth struct {
	ID int64
	UP int64
	DL int64
}
type UserBandwidthList []*UserBandwidth
