package api

import (
	"database/sql"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

type DB interface {
	GetUserList() (UserList, error)
	UpdateUserBandwidth(UserBandwidth) error
	UpdateUserBandwidthList(UserBandwidthList) error
}

var (
	ErrUnknownDBMode = errors.New("unknown db mode")

	dbm DB
)

func init() {
	switch strings.ToUpper(os.Getenv("DBMODE")) {
	case "TESTING":
		dbm = &TESTING{}
	case "BOOMCLOUD":
		dbm = &BOOMCLOUD{}
	case "NEXITALLY":
		dbm = &NEXITALLY{}
	case "LEGENDSOCK":
		dbm = &LEGENDSOCK{}
	case "V2RAYSOCK":
		dbm = &V2RAYSOCK{}
	}
}

func newConn() (*sql.DB, error) {
	client, err := sql.Open(os.Getenv("DBTYPE"), os.Getenv("DBSPEC"))
	if err != nil {
		return nil, fmt.Errorf("sql.Open: %v", err)
	}
	client.SetConnMaxLifetime(time.Second * 30)
	client.SetConnMaxIdleTime(time.Second * 10)
	client.SetMaxOpenConns(4)
	client.SetMaxIdleConns(1)

	if err = client.Ping(); err != nil {
		client.Close()
		return nil, fmt.Errorf("client.Ping: %v", err)
	}

	return client, nil
}

func GetUserList() (UserList, error) {
	if dbm == nil {
		return nil, ErrUnknownDBMode
	}

	return dbm.GetUserList()
}

func UpdateUserBandwidth(data UserBandwidth) error {
	if dbm == nil {
		return ErrUnknownDBMode
	}

	return dbm.UpdateUserBandwidth(data)
}

func UpdateUserBandwidthList(list UserBandwidthList) error {
	if dbm == nil {
		return ErrUnknownDBMode
	}

	return dbm.UpdateUserBandwidthList(list)
}
