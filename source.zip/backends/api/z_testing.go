package api

type TESTING struct {
}

func (o *TESTING) GetUserList() (UserList, error) {
	return UserList{&UserInfo{
		ID:     0,
		Port:   0,
		Uuid:   "114514",
		Passwd: "114514",
	}}, nil
}

func (o *TESTING) UpdateUserBandwidth(data UserBandwidth) error {
	return nil
}

func (o *TESTING) UpdateUserBandwidthList(list UserBandwidthList) error {
	return nil
}
