package api

import (
	"fmt"
	"time"
)

type NEXITALLY struct {
}

func (o *NEXITALLY) GetUserList() (UserList, error) {
	client, err := newConn()
	if err != nil {
		return nil, err
	}
	defer client.Close()

	result, err := client.Query("SELECT mid, port, uuid, passwd FROM user WHERE enable=1 AND u+d<transfer_enable")
	if err != nil {
		return nil, fmt.Errorf("sql.Query: %v", err)
	}
	defer result.Close()

	info := UserInfo{}
	list := make(UserList, 0)

	for result.Next() {
		if err = result.Scan(&info.ID, &info.Port, &info.Uuid, &info.Passwd); err != nil {
			return nil, fmt.Errorf("sql.Scan: %v", err)
		}

		list = append(list, &UserInfo{
			ID:     info.ID,
			Port:   info.Port,
			Uuid:   info.Uuid,
			Passwd: info.Passwd,
		})
	}

	return list, nil
}

func (o *NEXITALLY) UpdateUserBandwidth(data UserBandwidth) error {
	client, err := newConn()
	if err != nil {
		return err
	}
	defer client.Close()

	if _, err = client.Exec(fmt.Sprintf("UPDATE user SET u = u + %d, d = d + %d, t = %d WHERE mid = %d", data.UP, data.DL, time.Now().Unix(), data.ID)); err != nil {
		return fmt.Errorf("sql.Exec: %v", err)
	}

	return nil
}

func (o *NEXITALLY) UpdateUserBandwidthList(list UserBandwidthList) error {
	if len(list) == 0 {
		return nil
	}

	client, err := newConn()
	if err != nil {
		return err
	}
	defer client.Close()

	when1 := ""
	when2 := ""
	in := ""

	for i := 0; i < len(list); i++ {
		when1 += fmt.Sprintf(" WHEN %d THEN u+%d", list[i].ID, list[i].UP)
		when2 += fmt.Sprintf(" WHEN %d THEN d+%d", list[i].ID, list[i].DL)

		if in != "" {
			in += fmt.Sprintf(", %d", list[i].ID)
		} else {
			in = fmt.Sprintf("%d", list[i].ID)
		}
	}

	if _, err := client.Exec(fmt.Sprintf("UPDATE user SET u = CASE mid %s END, d = CASE mid %s END, t = %d WHERE mid IN (%s)", when1, when2, time.Now().Unix(), in)); err != nil {
		return fmt.Errorf("sql.Exec: %v", err)
	}

	return nil
}
