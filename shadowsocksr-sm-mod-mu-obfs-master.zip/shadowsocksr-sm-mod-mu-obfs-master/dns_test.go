package main

import (
	"testing"

	"rixcloud.moe/shadowsocks/shadowsocks/socks"
)

func TestDNS1(t *testing.T) {
	flags.DNSHijack = true
	flags.DNSAddr = "1.1.1.1"
	flags.DNSPort = 53

	targetHost, targetPort := dnsHijack(socks.ParseAddr("8.8.8.8:80"))
	t.Logf("%v %v", targetHost, targetPort)
}

func TestDNS2(t *testing.T) {
	flags.DNSHijack = true
	flags.DNSAddr = "1.1.1.1"
	flags.DNSPort = 53

	targetHost, targetPort := dnsHijack(socks.ParseAddr("8.8.8.8:53"))
	t.Logf("%v %v", targetHost, targetPort)
}

func TestIPv6DNS(t *testing.T) {
	flags.DNSHijack = true
	flags.DNSAddr = "1.1.1.1"
	flags.DNSPort = 53

	targetHost, targetPort := dnsHijack(socks.ParseAddr("[2001:4860:4860::8888]:53"))
	t.Logf("%v %v", targetHost, targetPort)
}
