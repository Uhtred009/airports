package main

import (
	"io"
	"log"
	"net"
	"runtime"
	"strconv"
	"time"

	"github.com/juju/ratelimit"
	"rixcloud.moe/shadowsocks/shadowsocks/socks"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-mod-mu-obfs/adns"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-mod-mu-obfs/alive"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-mod-mu-obfs/audit"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-mod-mu-obfs/obfs"

	reuse "github.com/libp2p/go-reuseport"
)

func tcpServe() {
	if !flags.TCP {
		return
	}

	for i := 0; i < runtime.NumCPU(); i++ {
		go tcpListen()
	}
}

func tcpListen() {
	ln, err := reuse.Listen("tcp", net.JoinHostPort(flags.Bind, strconv.Itoa(flags.Port)))
	if err != nil {
		log.Fatalf("[TCP][reuse.Listen] %v", err)
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			if errno, ok := err.(net.Error); ok {
				if errno.Temporary() {
					continue
				}
			}

			log.Fatalf("[TCP][ln.Accept] %v", err)
		}

		go tcpHandle(client)
	}
}

func tcpHandle(client net.Conn) {
	from := ""
	if flags.EnableTrueIP {
		trueip, err := socks.ReadAddr(client)
		if err != nil {
			client.Close()
			return
		}

		from = trueip.String()
	} else {
		from = client.RemoteAddr().String()
	}

	if flags.EnableTLS {
		client = obfs.NewTLS(client)
	} else if flags.EnableHTTP {
		client = obfs.NewHTTP(client)
	}

	client = instanceCipher.StreamConn(client)
	client = newTCPOBFS(client)
	defer client.Close()

	data := make([]byte, 1024)
	size, err := client.Read(data)
	if err != nil {
		return
	}

	target := socks.SplitAddr(data[:size])
	if target == nil {
		log.Printf("[TCP][client.Target][%s] Unknown Target", client.RemoteAddr())
		return
	}
	targetHost, targetPort := dnsHijack(target)

	instanceMutex.RLock()
	instance := instanceList[client.(*TCPOBFS).UserID]
	instanceMutex.RUnlock()

	if alive.Scan(instance.UserInfo.ID, from) {
		return
	}

	if audit.Scan(instance.UserInfo.ID, data[:size]) {
		return
	}

	adtr, err := adns.FetchOne(targetHost)
	if err != nil {
		return
	}

	dialer := net.Dialer{Timeout: time.Second * 10}
	if adtr.To4() != nil {
		if flags.Dial != "" {
			dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(flags.Dial)}
		} else if flags.SISO {
			addr, _, _ := net.SplitHostPort(client.LocalAddr().String())
			dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(addr)}
		}
	}

	remote, err := dialer.Dial("tcp", net.JoinHostPort(adtr.String(), strconv.Itoa(targetPort)))
	if err != nil {
		return
	}
	defer remote.Close()

	if _, err := remote.Write(data[len(target):size]); err != nil {
		return
	}
	data = nil

	log.Printf("[IN][%d] New TCP connection from %s → %s:%d", instance.UserInfo.ID, from, targetHost, targetPort)
	tcpRelay(instance, client, remote)
}

func tcpRelay(instance *Instance, client, remote net.Conn) {
	go func() {
		var reader io.Reader
		if instance.UPBucket != nil {
			reader = ratelimit.Reader(client, instance.UPBucket)
		} else {
			reader = client
		}

		size, _ := io.CopyBuffer(remote, reader, make([]byte, flags.TCPBufferSize))
		_ = client.SetDeadline(time.Now())
		_ = remote.SetDeadline(time.Now())
		instance.Bandwidth.IncreaseUP(int64(float64(size) * flags.UPExternalRate))
	}()

	var reader io.Reader
	if instance.DLBucket != nil {
		reader = ratelimit.Reader(remote, instance.DLBucket)
	} else {
		reader = remote
	}

	size, _ := io.CopyBuffer(client, reader, make([]byte, flags.TCPBufferSize))
	_ = client.SetDeadline(time.Now())
	_ = remote.SetDeadline(time.Now())
	instance.Bandwidth.IncreaseDL(int64(float64(size) * flags.DLExternalRate))
}
