package obfs

import (
	"bytes"
	"crypto/sha1"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net"
	"time"

	"github.com/lestrrat-go/strftime"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-mod-mu-obfs/tools"
)

var (
	ErrNotHTTP    = errors.New("Not HTTP")
	ErrFormatDate = errors.New("Format Date Failed")

	HTTPCRLF = []byte{0x0d, 0x0a, 0x0d, 0x0a}

	Secret []byte
)

type TLS struct {
	net.Conn

	hasSentHeader bool
	hasRecvHeader bool

	SessionID []byte

	buffer []byte
	offset int
}

func (o *TLS) Read(data []byte) (int, error) {
	if o.buffer != nil {
		size := copy(data, o.buffer[o.offset:])
		o.offset += size

		if len(o.buffer) == o.offset {
			o.buffer = nil
			o.offset = 0
		}

		return size, nil
	}

	if !o.hasRecvHeader {
		o.hasRecvHeader = true

		/////////////////// Client Hello ///////////////////
		buffer := make([]byte, 9)
		_, err := io.ReadFull(o.Conn, buffer)
		if err != nil {
			return 0, err
		}
		length := binary.BigEndian.Uint16(buffer[7:9])

		buffer = make([]byte, length)
		_, err = io.ReadFull(o.Conn, buffer)
		if err != nil {
			return 0, err
		}
		buffer = buffer[34:]

		o.SessionID = make([]byte, int(buffer[0]))
		copy(o.SessionID, buffer[1:int(buffer[0])+1])
		/////////////////// Client Hello ///////////////////

		/////////////////// Server Hello ///////////////////
		_, err = o.Write(nil)
		if err != nil {
			return 0, err
		}
		/////////////////// Server Hello ///////////////////

		//////////////// Change Cipher Spec ////////////////
		buffer = make([]byte, 5)
		_, err = io.ReadFull(o.Conn, buffer)
		if err != nil {
			return 0, err
		}

		length = binary.BigEndian.Uint16(buffer[3:5])
		buffer = make([]byte, length)
		_, err = io.ReadFull(o.Conn, buffer)
		if err != nil {
			return 0, err
		}
		//////////////// Change Cipher Spec ////////////////

		//////////// Encrypted Handshake Message ///////////
		buffer = make([]byte, 5)
		_, err = io.ReadFull(o.Conn, buffer)
		if err != nil {
			return 0, err
		}

		length = binary.BigEndian.Uint16(buffer[3:5])
		buffer = make([]byte, length)
		_, err = io.ReadFull(o.Conn, buffer)
		if err != nil {
			return 0, err
		}
		//////////// Encrypted Handshake Message ///////////

		buffer = nil
	}

	buffer := make([]byte, 5)
	_, err := io.ReadFull(o.Conn, buffer)
	if err != nil {
		return 0, err
	}
	length := int(binary.BigEndian.Uint16(buffer[3:5]))

	buffer = make([]byte, length)
	_, err = io.ReadFull(o.Conn, buffer)
	if err != nil {
		return 0, err
	}

	size := copy(data, buffer)
	if length > size {
		o.buffer = buffer
		o.offset = size
	}

	return size, nil
}

func (o *TLS) Write(data []byte) (int, error) {
	if !o.hasSentHeader {
		o.hasSentHeader = true

		is := []int{
			// Server Hello
			1 + 2 + 2 + 2 + 2 + 2 + 32 + 1 + len(o.SessionID) + 2 + 1 + 2 + 5,

			// Session Ticket
			0,

			// Change Cipher Spec
			6,

			// Encrypted Handshake Message
			37,
		}

		if rand.Intn(8) < 1 {
			is[1] = 1 + 2 + 2 + 2 + 2 + 128
		}

		/////////////////// Server Hello ///////////////////
		buffer := make([]byte, is[0]+is[1]+is[2]+is[3])
		buffer[0] = 0x16
		buffer[1] = 0x03
		buffer[2] = 0x03
		binary.BigEndian.PutUint16(buffer[3:5], uint16(4+35+len(o.SessionID)+10))
		buffer[5] = 0x02
		buffer[6] = 0x00
		binary.BigEndian.PutUint16(buffer[7:9], uint16(35+len(o.SessionID)+10))
		buffer[9] = 0x03
		buffer[10] = 0x03
		binary.BigEndian.PutUint32(buffer[11:15], uint32(time.Now().Unix()&0xffffffff))
		rand.Read(buffer[15:33])
		copy(buffer[33:43], tools.HMAC(sha1.New, append(Secret, o.SessionID...), buffer[11:33])[:10])
		buffer[43] = byte(len(o.SessionID))
		copy(buffer[44:44+len(o.SessionID)], o.SessionID)
		copy(buffer[44+len(o.SessionID):], []byte{0xc0, 0x2f, 0x00, 0x00, 0x05, 0xff, 0x01, 0x00, 0x01, 0x00})
		/////////////////// Server Hello ///////////////////

		////////////////// Session Ticket //////////////////
		if is[1] != 0 {
			buffer[is[0]] = 0x16
			buffer[is[0]+1] = 0x03
			buffer[is[0]+2] = 0x03
			binary.BigEndian.PutUint16(buffer[is[0]+3:is[0]+5], uint16(2+2+128))
			buffer[is[0]+5] = 0x04
			buffer[is[0]+6] = 0x00
			binary.BigEndian.PutUint16(buffer[is[0]+7:is[0]+9], uint16(128))
			rand.Read(buffer[is[0]+9 : is[0]+13])
			binary.BigEndian.PutUint16(buffer[is[0]+13:is[0]+15], uint16(128-4-2))
			rand.Read(buffer[is[0]+15 : is[0]+15+122])
		}
		////////////////// Session Ticket //////////////////

		//////////////// Change Cipher Spec ////////////////
		copy(buffer[is[0]+is[1]:], []byte{0x14, 0x03, 0x03, 0x00, 0x01, 0x01})
		//////////////// Change Cipher Spec ////////////////

		//////////// Encrypted Handshake Message ///////////
		copy(buffer[is[0]+is[1]+is[2]:], []byte{0x16, 0x03, 0x03})
		binary.BigEndian.PutUint16(buffer[is[0]+is[1]+is[2]+3:is[0]+is[1]+is[2]+5], uint16(32))
		rand.Read(buffer[is[0]+is[1]+is[2]+5 : is[0]+is[1]+is[2]+27])
		copy(buffer[len(buffer)-10:], tools.HMAC(sha1.New, append(Secret, o.SessionID...), buffer[:len(buffer)-10])[:10])
		//////////// Encrypted Handshake Message ///////////

		_, err := o.Conn.Write(buffer)
		if err != nil {
			return 0, err
		}
	}

	if len(data) != 0 {
		buffer := bytes.NewBuffer(nil)
		buffer.Write([]byte{0x17, 0x03, 0x03})
		_ = binary.Write(buffer, binary.BigEndian, uint16(len(data)))
		buffer.Write(data)

		_, err := o.Conn.Write(buffer.Bytes())
		if err != nil {
			return 0, err
		}

		return len(data), nil
	}

	return 0, nil
}

func NewTLS(client net.Conn) net.Conn {
	obfs := new(TLS)
	obfs.Conn = client
	obfs.hasSentHeader = false
	obfs.hasRecvHeader = false

	return obfs
}

type HTTP struct {
	net.Conn

	hasSentHeader bool
	hasRecvHeader bool

	buffer []byte
	offset int
}

func (o *HTTP) Read(data []byte) (int, error) {
	if o.buffer != nil {
		size := copy(data, o.buffer[o.offset:])
		o.offset += size

		if len(o.buffer) == o.offset {
			o.buffer = nil
			o.offset = 0
		}

		return size, nil
	}

	if !o.hasRecvHeader {
		buffer := make([]byte, 1024)
		length, err := o.Conn.Read(buffer)
		if err != nil {
			return 0, err
		}

		if !bytes.Contains(buffer[:length], HTTPCRLF) {
			return 0, nil
		}

		o.hasRecvHeader = true

		SPL := bytes.SplitN(buffer[:length], HTTPCRLF, 2)
		HDR := SplitHeader(SPL[0])

		if CheckHeader(HDR, "REQUEST") {
			header, err := GetHTTP(HDR["REQUEST"])
			if err != nil {
				return 0, err
			}

			SPL[1] = append(header, SPL[1]...)
		}

		if len(SPL[1]) == 0 {
			if _, err = o.Write(nil); err != nil {
				return 0, err
			}

			length, err = o.Conn.Read(buffer)
			if err != nil {
				return 0, err
			}

			size := copy(data, buffer[:length])
			if length > size {
				o.buffer = buffer[:length]
				o.offset = size
			}

			return size, nil
		}

		size := copy(data, SPL[1])
		if len(SPL[1]) > size {
			o.buffer = SPL[1]
			o.offset = size
		}

		return size, nil
	}

	return o.Conn.Read(data)
}

func (o *HTTP) Write(data []byte) (int, error) {
	if !o.hasSentHeader {
		o.hasSentHeader = true

		date, err := strftime.Format("%a, %d %b %Y %H:%M:%S GMT", time.Now())
		if err != nil {
			return 0, ErrFormatDate
		}

		buffer := []byte(fmt.Sprintf(""+
			"HTTP/1.1 200 OK\r\n"+
			"Connection: keep-alive\r\n"+
			"Content-Encoding: gzip\r\n"+
			"Content-Type: text/html\r\n"+
			"Date: %s\r\n"+
			"Server: nginx\r\n"+
			"Vary: Accept-Encoding\r\n"+
			"\r\n", date))

		if _, err = o.Conn.Write(append(buffer, data...)); err != nil {
			return 0, err
		}

		return len(data), nil
	}

	return o.Conn.Write(data)
}

func NewHTTP(client net.Conn) net.Conn {
	obfs := new(HTTP)
	obfs.Conn = client
	obfs.hasSentHeader = false
	obfs.hasRecvHeader = false

	return obfs
}
