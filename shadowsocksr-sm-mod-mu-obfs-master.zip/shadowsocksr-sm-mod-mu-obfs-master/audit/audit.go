package audit

import (
	"log"
	"regexp"
	"sync"

	api "rixcloud.moe/shadowsocks/mod-mu-api"
)

var (
	audits   = make(api.AuditList, 0)
	detected = make(api.AuditInfoList, 0)
	aMutex   sync.RWMutex
	xMutex   sync.Mutex
)

func Get() error {
	data, err := api.GetAuditList()
	if err != nil {
		return err
	}

	list := make(api.AuditList, 0)
	for i := 0; i < len(data); i++ {
		regex, err := regexp.Compile(data[i].Regex)
		if err != nil {
			log.Printf("[APP][regexp.Compile][%d][%s] %v", data[i].ID, data[i].Regex, err)
			continue
		}

		list = append(list, api.Audit{
			ID:       data[i].ID,
			Type:     data[i].Type,
			Name:     data[i].Name,
			Text:     data[i].Text,
			Regex:    data[i].Regex,
			Compiled: regex,
		})
	}

	aMutex.Lock()
	audits = list
	aMutex.Unlock()

	return nil
}

func Update() error {
	xMutex.Lock()
	list := detected
	detected = make(api.AuditInfoList, 0)
	xMutex.Unlock()

	err := api.UpdateAuditInfoList(list)
	if err != nil {
		xMutex.Lock()
		detected = append(detected, list...)
		xMutex.Unlock()

		return err
	}

	return nil
}

func Scan(id uint32, data []byte) bool {
	aMutex.RLock()

	for i := 0; i < len(audits); i++ {
		if audits[i].Compiled.Match(data) {
			log.Printf("[APP][audit.Scan][%d][%d] Matched", id, audits[i].ID)

			xMutex.Lock()
			detected = append(detected, api.AuditInfo{
				UserID: id,
				RuleID: audits[i].ID,
			})
			xMutex.Unlock()

			aMutex.RUnlock()
			return true
		}
	}

	aMutex.RUnlock()
	return false
}
