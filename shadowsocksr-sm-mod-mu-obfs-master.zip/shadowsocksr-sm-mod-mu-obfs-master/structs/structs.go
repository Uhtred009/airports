package structs

var Default struct {
	Version string
}

func init() {
	Default.Version = "1.0.3"
}
