package adns

import (
	"errors"
	"net"
	"sync"
	"time"

	"github.com/miekg/dns"
)

var (
	ErrDNSFailure   = errors.New("DNS Failure")
	ErrNoIPResolved = errors.New("No IP Resolved")

	DNS       = "1.1.1.1:53"
	TTL int64 = 120

	list   = &sync.Map{}
	client = &dns.Client{}
)

type value struct {
	Unix int64

	IPs []net.IP
}

func fetch(name string) ([]net.IP, error) {
	v, ok := list.Load(name)
	if !ok {
		m := dns.Msg{}
		m.SetQuestion(name, dns.TypeA)

		in, _, err := client.Exchange(&m, DNS)
		if err != nil {
			return nil, ErrDNSFailure
		}

		ips := make([]net.IP, 0)
		for i := 0; i < len(in.Answer); i++ {
			if answer, ok := in.Answer[i].(*dns.A); ok {
				ips = append(ips, answer.A)
			}
		}

		m.SetQuestion(name, dns.TypeAAAA)
		if in, _, err = client.Exchange(&m, DNS); err == nil {
			for i := 0; i < len(in.Answer); i++ {
				if answer, ok := in.Answer[i].(*dns.AAAA); ok {
					ips = append(ips, answer.AAAA)
				}
			}
		}

		if len(ips) == 0 {
			return nil, ErrNoIPResolved
		}

		v = &value{Unix: time.Now().Unix(), IPs: ips}
		list.Store(name, v)
	}

	return v.(*value).IPs, nil
}

func Run() {
	go func() {
		for {
			time.Sleep(time.Second * 120)

			last := time.Now().Unix()
			list.Range(func(k interface{}, v interface{}) bool {
				if last-v.(*value).Unix > TTL {
					list.Delete(k)
				}

				return true
			})
		}
	}()
}

func Fetch(name string) ([]net.IP, error) {
	if host, _, err := net.SplitHostPort(name); err == nil {
		name = host
	}

	if addr := net.ParseIP(name); addr != nil {
		return []net.IP{addr}, nil
	}

	return fetch(name + ".")
}

func FetchOne(name string) (net.IP, error) {
	ips, err := Fetch(name)
	if err != nil {
		return nil, err
	}

	return ips[0], nil
}
