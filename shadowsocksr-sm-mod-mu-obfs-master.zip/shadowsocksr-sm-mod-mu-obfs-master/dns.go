package main

import (
	"net"

	"rixcloud.moe/shadowsocks/shadowsocks/socks"
)

func dnsHijack(target socks.Addr) (targetHost string, targetPort int) {
	switch target[0] {
	case socks.AtypDomainName:
		targetHost = string(target[2 : 2+int(target[1])])
		targetPort = (int(target[2+int(target[1])]) << 8) | int(target[2+int(target[1])+1])
	case socks.AtypIPv4:
		targetHost = net.IP(target[1 : 1+net.IPv4len]).String()
		targetPort = (int(target[1+net.IPv4len]) << 8) | int(target[1+net.IPv4len+1])
	case socks.AtypIPv6:
		targetHost = net.IP(target[1 : 1+net.IPv6len]).String()
		targetPort = (int(target[1+net.IPv6len]) << 8) | int(target[1+net.IPv6len+1])
	}

	if flags.DNSHijack && targetPort == 53 {
		targetHost = flags.DNSAddr
		targetPort = flags.DNSPort
	}

	return
}
