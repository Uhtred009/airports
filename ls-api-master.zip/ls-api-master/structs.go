package api

import (
	"fmt"
)

type UserInfo struct {
	ID     int
	Port   uint32
	Passwd string
	Method string
}
type UserList []UserInfo

func (o *UserInfo) Get() string {
	return fmt.Sprintf("%d-%s.%s", o.Port, o.Passwd, Suffix)
}

type UserBandwidth struct {
	ID int
	UP int64
	DL int64
}
type UserBandwidthList []UserBandwidth
