package main

import (
	"log"
	"net"
	"strconv"
	"sync"
	"time"

	"rixcloud.moe/shadowsocks/shadowsocks/socks"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-v2raysock-mod/adns"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-v2raysock-mod/audit"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-v2raysock-mod/tools"
)

func udpServe() {
	if !flags.UDP {
		return
	}

	for {
		log.Printf("[UDP] %v", udpListen())

		time.Sleep(time.Second * 4)
	}
}

func udpListen() error {
	ln, err := net.ListenPacket("udp", net.JoinHostPort(flags.Bind, strconv.Itoa(flags.Port)))
	if err != nil {
		return err
	}
	ln = instanceCipher.PacketConn(ln)
	defer ln.Close()

	nm := newNAT()
	buffer := make([]byte, flags.UDPBufferSize)

	for {
		size, from, err := ln.ReadFrom(buffer)
		if err != nil {
			return err
		}

		target := socks.SplitAddr(buffer)
		if target == nil {
			continue
		}

		targetHost, targetPort, err := net.SplitHostPort(target.String())
		if err != nil {
			continue
		}

		targetAdtr, err := adns.FetchOne(targetHost)
		if err != nil {
			continue
		}

		targetAddr, err := net.ResolveUDPAddr("udp", net.JoinHostPort(targetAdtr.String(), targetPort))
		if err != nil {
			continue
		}

		remote := nm.Get(from.String())
		if remote == nil {
			remote = newUDPOBFS()
			if err = remote.ParsePacket(buffer[:size]); err != nil {
				continue
			}

			if audit.Scan(remote.Instance.UserInfo.ID, buffer[:size]) {
				continue
			}

			addr := ""
			if flags.Dial != "" && targetAddr.IP.To4() != nil {
				addr = flags.Dial
			}

			conn, err := net.ListenPacket("udp", net.JoinHostPort(addr, ""))
			if err != nil {
				continue
			}

			remote.PacketConn = conn
			nm.Create(remote, ln, from)

			log.Printf("[IN][%d] New UDP connection from %s → %s", remote.Instance.UserInfo.ID, from, target.String())
		}

		if audit.Scan(remote.Instance.UserInfo.ID, buffer[:size]) {
			continue
		}

		_, _ = remote.WriteTo(buffer[len(target):size-8], targetAddr)
	}
}

func udpRelay(remote *UDPOBFS, client net.PacketConn, target net.Addr) {
	buffer := make([]byte, flags.UDPBufferSize)

	for {
		_ = remote.SetReadDeadline(time.Now().Add(time.Second * time.Duration(flags.UDPTimeout)))
		size, from, err := remote.ReadFrom(buffer)
		if err != nil {
			return
		}

		source := socks.ParseAddr(from.String())
		length := len(source) + size + 4
		if length > flags.UDPBufferSize {
			continue
		}

		copy(buffer[len(source):], buffer[:size])
		copy(buffer, source)
		copy(buffer[length-4:], tools.HMAC(newHashMethod, flags.Secret, buffer[:length-4])[:4])

		if _, err = client.WriteTo(buffer[:length], target); err != nil {
			return
		}
	}
}

type NAT struct {
	sync.RWMutex

	m map[string]*UDPOBFS
}

func (n *NAT) Get(id string) *UDPOBFS {
	n.RLock()
	defer n.RUnlock()

	return n.m[id]
}

func (n *NAT) Set(id string, conn *UDPOBFS) {
	n.Lock()
	defer n.Unlock()

	n.m[id] = conn
}

func (n *NAT) Create(remote *UDPOBFS, client net.PacketConn, target net.Addr) {
	n.Set(target.String(), remote)

	go func() {
		udpRelay(remote, client, target)
		if conn := n.Delete(target.String()); conn != nil && conn.PacketConn != nil {
			conn.Close()
		}
	}()
}

func (n *NAT) Delete(id string) *UDPOBFS {
	n.Lock()
	defer n.Unlock()

	conn, ok := n.m[id]
	if ok {
		delete(n.m, id)
		return conn
	}

	return nil
}

func newNAT() *NAT {
	n := new(NAT)
	n.m = make(map[string]*UDPOBFS)

	return n
}
