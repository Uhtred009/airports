package main

import (
	"github.com/juju/ratelimit"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-v2raysock-mod/tools"

	api "rixcloud.moe/shadowsocks/v2raysock-mod-api"
)

type Instance struct {
	Passwd []byte

	UserInfo  api.UserInfo
	Bandwidth *Bandwidth
	UPBucket  *ratelimit.Bucket
	DLBucket  *ratelimit.Bucket
}

func newInstance(data api.UserInfo) *Instance {
	var aBucket *ratelimit.Bucket
	if flags.ForceUPSpeedLimit > 0 {
		aBucket = ratelimit.NewBucketWithRate(1024*128*float64(flags.ForceUPSpeedLimit), 1024*128*int64(flags.ForceUPSpeedLimit))
	}

	var xBucket *ratelimit.Bucket
	if data.Speed > 0 {
		xBucket = ratelimit.NewBucketWithRate(1024*128*float64(data.Speed), 1024*128*int64(data.Speed))
	} else if flags.ForceDLSpeedLimit > 0 {
		xBucket = ratelimit.NewBucketWithRate(1024*128*float64(flags.ForceDLSpeedLimit), 1024*128*int64(flags.ForceDLSpeedLimit))
	}

	instance := new(Instance)
	instance.Passwd = tools.Sum(newHashMethod, []byte(data.UUID))
	instance.UserInfo = data
	instance.Bandwidth = newBandwidth()
	instance.UPBucket = aBucket
	instance.DLBucket = xBucket
	return instance
}
