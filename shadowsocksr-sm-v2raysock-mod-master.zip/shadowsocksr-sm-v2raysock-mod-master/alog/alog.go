package alog

import (
	"encoding/json"
	"fmt"
	"os"
	"sync"
	"time"

	resty "github.com/go-resty/resty/v2"
)

type Rule struct {
	ID     string `json:"id"`
	Date   int64  `json:"date"`
	Local  string `json:"local"`
	Client string `json:"client"`
	Remote string `json:"remote"`
}
type RuleList []Rule

var (
	Enabled = false

	mutex   sync.Mutex
	records = make(RuleList, 0)
)

func Set(id uint32, local string, client string, remote string) {
	if !Enabled {
		return
	}

	mutex.Lock()
	records = append(records, Rule{
		ID:     fmt.Sprint(id),
		Date:   time.Now().Unix(),
		Local:  local,
		Client: client,
		Remote: remote,
	})
	mutex.Unlock()
}

func Update() error {
	mutex.Lock()
	if !Enabled || len(records) == 0 {
		mutex.Unlock()
		return nil
	}

	list := records
	records = make(RuleList, 0)
	mutex.Unlock()

	data, err := json.Marshal(list)
	if err != nil {
		mutex.Lock()
		records = append(list, records...)
		mutex.Unlock()

		return err
	}

	client := resty.New()

	response, err := client.R().
		SetBody(data).
		Post(fmt.Sprintf("%s?key=%s", os.Getenv("LOGURL"), os.Getenv("LOGSECRET")))
	if err != nil || response.StatusCode() != 200 {
		mutex.Lock()
		records = append(list, records...)
		mutex.Unlock()

		return err
	}

	return nil
}
