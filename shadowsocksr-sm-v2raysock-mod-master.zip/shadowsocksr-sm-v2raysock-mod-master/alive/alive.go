package alive

import (
	"net"
	"sync"

	api "rixcloud.moe/shadowsocks/v2raysock-mod-api"
)

var (
	audits   = make(api.ProhibitList, 0)
	detected = make(api.AliveInfoList, 0)
	aMutex   sync.RWMutex
	xMutex   sync.RWMutex
)

func Get() error {
	list, err := api.GetProhibitList()
	if err != nil {
		return err
	}

	aMutex.Lock()
	audits = list
	aMutex.Unlock()

	return nil
}

func Update() error {
	xMutex.Lock()
	list := detected
	detected = make(api.AliveInfoList, 0)
	xMutex.Unlock()

	err := api.UpdateAliveInfoList(list)
	if err != nil {
		xMutex.Lock()
		detected = append(detected, list...)
		xMutex.Unlock()

		return err
	}

	return nil
}

func Scan(id uint32, ip string) bool {
	addr, _, _ := net.SplitHostPort(ip)

	aMutex.RLock()
	for i := 0; i < len(audits); i++ {
		if audits[i].IP == addr {
			aMutex.RUnlock()
			return true
		}
	}
	aMutex.RUnlock()

	xMutex.RLock()
	for i := 0; i < len(detected); i++ {
		if detected[i].UserID == id && detected[i].IP == addr {
			xMutex.RUnlock()
			return false
		}
	}
	xMutex.RUnlock()

	xMutex.Lock()
	detected = append(detected, api.AliveInfo{
		UserID: id,
		IP:     addr,
	})
	xMutex.Unlock()

	return false
}
