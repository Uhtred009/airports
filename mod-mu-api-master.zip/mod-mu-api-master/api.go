package api

import (
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/valyala/fasthttp"
)

var (
	ID     int
	URL    string
	Secret string
	Offset int = 0

	Suffix string
	Prefix string

	APIOut time.Duration = time.Second * 30
)

func newHTTP() fasthttp.Client {
	return fasthttp.Client{
		Name:         "mod-mu-api",
		ReadTimeout:  APIOut,
		WriteTimeout: APIOut,
	}
}

func GetMulti() (UserInfo, error) {
	client := newHTTP()
	code, response, err := client.GetTimeout(nil, fmt.Sprintf("%s/mod_mu/users?node_id=%d&key=%s", URL, ID, Secret), APIOut)
	if err != nil {
		return UserInfo{}, err
	}

	if code != 200 {
		return UserInfo{}, ErrGetMultiFailed
	}

	var data struct {
		Code    int      `json:"ret"`
		Message string   `json:"msg"`
		Data    UserList `json:"data"`
	}
	err = json.Unmarshal(response, &data)
	if err != nil {
		return UserInfo{}, err
	}

	if data.Code != 1 {
		return UserInfo{}, ErrGetMultiFailed
	}

	list := make(UserList, 0)
	for _, value := range data.Data {
		if value.IsMultiUser == 1 || value.IsMultiUser == 2 {
			list = append(list, value)
		}
	}

	if len(list) == 0 {
		return UserInfo{}, ErrMultiNotFound
	}

	return list[Offset], nil
}

func GetNodeInfo() (NodeInfo, error) {
	client := newHTTP()
	code, response, err := client.GetTimeout(nil, fmt.Sprintf("%s/mod_mu/nodes/%d/info?key=%s", URL, ID, Secret), APIOut)
	if err != nil {
		return NodeInfo{}, err
	}

	if code != 200 {
		return NodeInfo{}, ErrGetNodeInfoFailed
	}

	var data struct {
		Code int      `json:"ret"`
		Data NodeInfo `json:"data"`
	}
	err = json.Unmarshal(response, &data)
	if err != nil {
		return NodeInfo{}, err
	}

	if data.Code != 1 {
		return NodeInfo{}, ErrGetNodeInfoFailed
	}

	return data.Data, nil
}

func GetRelayList() (RelayList, error) {
	client := newHTTP()
	code, response, err := client.GetTimeout(nil, fmt.Sprintf("%s/mod_mu/func/relay_rules?node_id=%d&key=%s", URL, ID, Secret), APIOut)
	if err != nil {
		return nil, err
	}

	if code != 200 {
		return nil, ErrGetRelayListFailed
	}

	var data struct {
		Code int       `json:"ret"`
		Data RelayList `json:"data"`
	}
	err = json.Unmarshal(response, &data)
	if err != nil {
		return nil, err
	}

	if data.Code != 1 {
		return nil, ErrGetRelayListFailed
	}

	list := make(RelayList, 0)
	for i := 0; i < len(data.Data); i++ {
		if data.Data[i].DstIP != "" {
			list = append(list, data.Data[i])
		}
	}
	return list, nil
}

func GetAuditList() (AuditList, error) {
	client := newHTTP()
	code, response, err := client.GetTimeout(nil, fmt.Sprintf("%s/mod_mu/func/detect_rules?key=%s", URL, Secret), APIOut)
	if err != nil {
		return nil, err
	}

	if code != 200 {
		return nil, ErrGetAuditListFailed
	}

	var data struct {
		Code int       `json:"ret"`
		Data AuditList `json:"data"`
	}
	err = json.Unmarshal(response, &data)
	if err != nil {
		return nil, err
	}

	if data.Code != 1 {
		return nil, ErrGetAuditListFailed
	}

	return data.Data, nil
}

func GetProhibitList() (ProhibitList, error) {
	client := newHTTP()
	code, response, err := client.GetTimeout(nil, fmt.Sprintf("%s/mod_mu/func/block_ip?key=%s", URL, Secret), APIOut)
	if err != nil {
		return nil, err
	}

	if code != 200 {
		return nil, ErrGetProhibitListFailed
	}

	var data struct {
		Code int          `json:"ret"`
		Data ProhibitList `json:"data"`
	}
	err = json.Unmarshal(response, &data)
	if err != nil {
		return nil, err
	}

	if data.Code != 1 {
		return nil, ErrGetProhibitListFailed
	}

	return data.Data, nil
}

func GetUserList() (UserList, error) {
	client := newHTTP()
	code, response, err := client.GetTimeout(nil, fmt.Sprintf("%s/mod_mu/users?node_id=%d&key=%s", URL, ID, Secret), APIOut)
	if err != nil {
		return nil, err
	}

	if code != 200 {
		return nil, ErrGetUserListFailed
	}

	var data struct {
		Code    int      `json:"ret"`
		Message string   `json:"msg"`
		Data    UserList `json:"data"`
	}
	err = json.Unmarshal(response, &data)
	if err != nil {
		return nil, err
	}

	if data.Code != 1 {
		return nil, ErrGetUserListFailed
	}

	list := make([]UserInfo, 0)
	for _, value := range data.Data {
		if value.IsMultiUser == 0 {
			list = append(list, value)
		}
	}

	return list, nil
}

func Update(list UserBandwidthList) error {
	if len(list) == 0 {
		return nil
	}

	var _list struct {
		Data UserBandwidthList `json:"data"`
	}
	_list.Data = list

	data, err := json.Marshal(_list)
	if err != nil {
		return err
	}

	request := fasthttp.AcquireRequest()
	response := fasthttp.AcquireResponse()
	defer func() {
		fasthttp.ReleaseRequest(request)
		fasthttp.ReleaseResponse(response)
	}()

	request.SetRequestURI(fmt.Sprintf("%s/mod_mu/users/traffic?node_id=%d&key=%s", URL, ID, Secret))
	request.Header.SetMethod("POST")
	request.Header.SetContentType("application/json")
	request.SetBody(data)

	client := newHTTP()
	if err := client.DoTimeout(request, response, APIOut); err != nil {
		return err
	}

	var result struct {
		Code int    `json:"ret"`
		Data string `json:"data"`
	}
	err = json.Unmarshal(response.Body(), &result)
	if err != nil {
		log.Println(string(response.Body()))

		return err
	}

	if result.Code != 1 {
		return ErrUpdateFailed
	}

	return nil
}

func UpdateAuditInfoList(list AuditInfoList) error {
	if len(list) == 0 {
		return nil
	}

	var _list struct {
		Data AuditInfoList `json:"data"`
	}
	_list.Data = list

	data, err := json.Marshal(_list)
	if err != nil {
		return err
	}

	request := fasthttp.AcquireRequest()
	response := fasthttp.AcquireResponse()
	defer func() {
		fasthttp.ReleaseRequest(request)
		fasthttp.ReleaseResponse(response)
	}()

	request.SetRequestURI(fmt.Sprintf("%s/mod_mu/users/detectlog?node_id=%d&key=%s", URL, ID, Secret))
	request.Header.SetMethod("POST")
	request.Header.SetContentType("application/json")
	request.SetBody(data)

	client := newHTTP()
	if err := client.DoTimeout(request, response, APIOut); err != nil {
		return err
	}

	var result struct {
		Code int    `json:"ret"`
		Data string `json:"data"`
	}
	err = json.Unmarshal(response.Body(), &result)
	if err != nil {
		return err
	}

	if result.Code != 1 {
		return ErrUpdateAuditInfoListFailed
	}

	return nil
}

func UpdateAliveInfoList(list AliveInfoList) error {
	if len(list) == 0 {
		return nil
	}

	var _list struct {
		Data AliveInfoList `json:"data"`
	}
	_list.Data = list

	data, err := json.Marshal(_list)
	if err != nil {
		return err
	}

	request := fasthttp.AcquireRequest()
	response := fasthttp.AcquireResponse()
	defer func() {
		fasthttp.ReleaseRequest(request)
		fasthttp.ReleaseResponse(response)
	}()

	request.SetRequestURI(fmt.Sprintf("%s/mod_mu/users/aliveip?node_id=%d&key=%s", URL, ID, Secret))
	request.Header.SetMethod("POST")
	request.Header.SetContentType("application/json")
	request.SetBody(data)

	client := newHTTP()
	if err := client.DoTimeout(request, response, APIOut); err != nil {
		return err
	}

	var result struct {
		Code int    `json:"ret"`
		Data string `json:"data"`
	}
	err = json.Unmarshal(response.Body(), &result)
	if err != nil {
		return err
	}

	if result.Code != 1 {
		return ErrUpdateAuditInfoListFailed
	}

	return nil
}
