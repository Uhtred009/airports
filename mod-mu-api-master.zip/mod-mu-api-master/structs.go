package api

import (
	"crypto/md5"
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

type NodeInfo struct {
	Group       int     `json:"node_group"`
	Class       int     `json:"node_class"`
	Speed       int     `json:"node_speedlimit"`
	Rate        float64 `json:"traffic_rate"`
	IsMultiUser int     `json:"mu_only"`
	Sort        int     `json:"sort"`
	Server      string  `json:"server"`
	Type        string  `json:"type"`
}

type Relay struct {
	ID      int    `json:"id"`
	UserID  uint32 `json:"user_id"`
	DstIP   string `json:"dist_node_server"`
	DstPort int    `json:"port"`
}
type RelayList []Relay

type Audit struct {
	ID    int    `json:"id"`
	Type  int    `json:"type"`
	Name  string `json:"name"`
	Text  string `json:"text"`
	Regex string `json:"regex"`

	Compiled *regexp.Regexp `json:"-"`
}
type AuditList []Audit

type AuditInfo struct {
	UserID uint32 `json:"user_id"`
	RuleID int    `json:"list_id"`
}
type AuditInfoList []AuditInfo

type AliveInfo struct {
	UserID uint32 `json:"user_id"`
	IP     string `json:"ip"`
}
type AliveInfoList []AliveInfo

type ProhibitInfo struct {
	IP string `json:"ip"`
}
type ProhibitList []ProhibitInfo

type UserInfo struct {
	ID          uint32 `json:"id"`
	Mail        string `json:"email"`
	Port        int    `json:"port"`
	Password    string `json:"passwd"`
	Method      string `json:"method"`
	Protocol    string `json:"protocol"`
	OBFS        string `json:"obfs"`
	UP          int64  `json:"u"`
	DL          int64  `json:"d"`
	Speed       int    `json:"node_speedlimit"`
	IsMultiUser int    `json:"is_multi_user"`
}
type UserList []UserInfo

func (o *UserInfo) Get() string {
	text := strings.Replace(strings.Replace(Prefix, "%id", fmt.Sprintf("%d", o.ID), -1), "%suffix", Suffix, -1)
	checksum := md5.Sum([]byte(fmt.Sprintf("%d%s%s%s%s", o.ID, o.Password, o.Method, o.OBFS, o.Protocol)))

	regex := regexp.MustCompile(`"|%-?[1-9]\d*m|U"`)
	for _, checked := range regex.FindAllString(text, -1) {
		size, _ := strconv.Atoi(strings.Replace(strings.Replace(checked, "%", "", -1), "m", "", -1))

		text = strings.Replace(text, checked, fmt.Sprintf("%x", checksum)[:size], 1)
	}

	return text
}

type UserBandwidth struct {
	ID uint32 `json:"user_id"`
	UP int64  `json:"u"`
	DL int64  `json:"d"`
}
type UserBandwidthList []UserBandwidth
