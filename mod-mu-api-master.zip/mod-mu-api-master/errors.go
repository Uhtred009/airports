package api

import "errors"

var (
	ErrGetMultiFailed            = errors.New("Get Multi Failed")
	ErrMultiNotFound             = errors.New("Multi Not Found")
	ErrGetNodeInfoFailed         = errors.New("Get Node Info Failed")
	ErrGetRelayListFailed        = errors.New("Get Relay List Failed")
	ErrGetAuditListFailed        = errors.New("Get Audit List Failed")
	ErrGetProhibitListFailed     = errors.New("Get Prohibit List Failed")
	ErrGetUserListFailed         = errors.New("Get User List Failed")
	ErrUpdateFailed              = errors.New("Update Failed")
	ErrUpdateAuditInfoListFailed = errors.New("Update Audit Info List Failed")
	ErrUpdateAliveInfoListFailed = errors.New("Update Alive Info List Failed")
)
