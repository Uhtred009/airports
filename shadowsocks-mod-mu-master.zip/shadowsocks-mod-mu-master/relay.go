package main

import (
	"fmt"
	"log"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"

	"rixcloud.moe/shadowsocks/shadowsocks-mod-mu/adns"
	"rixcloud.moe/shadowsocks/shadowsocks/socks"
)

func GetDestination(id uint32) string {
	destMutex.RLock()
	defer destMutex.RUnlock()

	for i := 0; i < len(destList); i++ {
		if destList[i].UserID == id && destList[i].DstIP != "" {
			if destList[i].DstPort != 0 {
				return net.JoinHostPort(destList[i].DstIP, strconv.Itoa(destList[i].DstPort))
			}

			return net.JoinHostPort(destList[i].DstIP, strconv.Itoa(instanceList[id].UserInfo.Port))
		}
	}

	return ""
}

func (i *Instance) tcpRelay() {
	if !flags.TCP {
		return
	}

	ln, err := net.Listen("tcp", fmt.Sprintf(":%d", i.UserInfo.Port))
	if err != nil {
		log.Printf("[TCP][net.Listen][%d][%d] %v", i.UserInfo.ID, i.UserInfo.Port, err)
		return
	}
	defer func() {
		if ln != nil {
			ln.Close()
			ln = nil
		}

		i.TCPStarted = false
	}()

	i.TCPSocket = ln
	i.TCPStarted = true

	for i.Started {
		client, err := ln.Accept()
		if err != nil {
			log.Printf("[TCP][ln.Accept][%d][%d] %v", i.UserInfo.ID, i.UserInfo.Port, err)
			return
		}

		go i.tcpRelayHandle(client)
	}
}
func (i *Instance) tcpRelayHandle(client net.Conn) {
	defer client.Close()

	adtr, err := adns.Fetch(i.Target)
	if err != nil {
		return
	}

	dialer := net.Dialer{Timeout: time.Second * 10}
	if strings.Count(adtr, ":") == 1 {
		if flags.Dial != "" {
			dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(flags.Dial)}
		} else if flags.SISO {
			addr, _, _ := net.SplitHostPort(client.LocalAddr().String())
			dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(addr)}
		}
	}

	remote, err := dialer.Dial("tcp", adtr)
	if err != nil {
		return
	}
	defer remote.Close()

	log.Printf("[OUT][%d] New TCP connection from %s → %s", i.UserInfo.ID, client.RemoteAddr(), i.Target)
	tcpCopy(i, client, remote)
}

func (i *Instance) udpRelay() {
	target := socks.ParseAddr(i.Target)
	if target == nil {
		log.Printf("[UDP][socks.ParseAddr][%d][%d] Parse Target Failed", i.UserInfo.ID, i.UserInfo.Port)
		return
	}

	ln, err := net.ListenPacket("udp", fmt.Sprintf(":%d", i.UserInfo.Port))
	if err != nil {
		log.Printf("[UDP][net.ListenPacket][%d][%d] %v", i.UserInfo.ID, i.UserInfo.Port, err)
		return
	}
	defer func() {
		if ln != nil {
			ln.Close()
			ln = nil
		}

		i.UDPStarted = false
	}()

	nm := newDNAT(time.Second * time.Duration(flags.UDPTimeout))
	buffer := make([]byte, flags.UDPBufferSize)

	i.UDPSocket = ln
	i.UDPStarted = true

	for i.Started {
		size, from, err := ln.ReadFrom(buffer)
		if err != nil {
			log.Printf("[UDP][ln.ReadFrom][%d][%d] %v", i.UserInfo.ID, i.UserInfo.Port, err)
			return
		}

		conn := nm.Get(from.String())
		if conn == nil {
			adtr, err := adns.Fetch(i.Target)
			if err != nil {
				continue
			}

			conn, err = net.Dial("udp", adtr)
			if err != nil {
				continue
			}

			nm.Create(i, conn, ln, from)
			log.Printf("[OUT][%d][%d] New UDP connection from %s → %s", i.UserInfo.ID, i.UserInfo.Port, from, i.Target)
		}

		if i.UPBucket != nil {
			i.UPBucket.Wait(int64(size))
		}
		i.Bandwidth.IncreaseUP(int64(float64(size) * flags.UPExternalRate))

		_, _ = conn.Write(buffer[len(target):size])
	}
}

func udpRelayCopy(instance *Instance, src net.Conn, dst net.PacketConn, target net.Addr, timeout time.Duration) {
	buffer := make([]byte, flags.UDPBufferSize)

	for {
		_ = src.SetReadDeadline(time.Now().Add(timeout))
		size, err := src.Read(buffer)
		if err != nil {
			return
		}

		if instance.DLBucket != nil {
			instance.DLBucket.Wait(int64(size))
		}
		instance.Bandwidth.IncreaseDL(int64(float64(size) * flags.DLExternalRate))

		_, err = dst.WriteTo(buffer[:size], target)
		if err != nil {
			return
		}
	}
}

type DNAT struct {
	sync.RWMutex
	m map[string]net.Conn
	t time.Duration
}

func (n *DNAT) Get(id string) net.Conn {
	n.RLock()
	defer n.RUnlock()

	return n.m[id]
}

func (n *DNAT) Set(id string, conn net.Conn) {
	n.Lock()
	defer n.Unlock()

	n.m[id] = conn
}

func (n *DNAT) Create(instance *Instance, src net.Conn, dst net.PacketConn, target net.Addr) {
	n.Set(target.String(), src)

	go func() {
		udpRelayCopy(instance, src, dst, target, n.t)
		if conn := n.Delete(target.String()); conn != nil {
			conn.Close()
		}
	}()
}

func (n *DNAT) Delete(id string) net.Conn {
	n.Lock()
	defer n.Unlock()

	conn, ok := n.m[id]
	if ok {
		delete(n.m, id)

		return conn
	}

	return nil
}

func newDNAT(timeout time.Duration) *DNAT {
	n := DNAT{}
	n.m = make(map[string]net.Conn)
	n.t = timeout

	return &n
}
