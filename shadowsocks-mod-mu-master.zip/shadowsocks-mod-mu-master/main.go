package main

import (
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"os"
	"runtime"
	"strings"
	"sync"
	"time"

	"github.com/joho/godotenv"
	"rixcloud.moe/authorize/client"
	"rixcloud.moe/shadowsocks/shadowsocks-mod-mu/adns"
	"rixcloud.moe/shadowsocks/shadowsocks-mod-mu/alive"
	"rixcloud.moe/shadowsocks/shadowsocks-mod-mu/audit"
	"rixcloud.moe/shadowsocks/shadowsocks-mod-mu/structs"
	"rixcloud.moe/shadowsocks/shadowsocks-mod-mu/tools"

	api "rixcloud.moe/shadowsocks/mod-mu-api"
)

var (
	flags struct {
		Path    string
		VerCode bool

		SyncInterval      int
		Bind              string
		Dial              string
		SISO              bool
		DNS               string
		DNSCache          int64
		DNSStack          string
		DNSHijack         bool
		TCP               bool
		UDP               bool
		UDPTimeout        int
		TCPBufferSize     int
		UDPBufferSize     int
		UPExternalRate    float64
		DLExternalRate    float64
		ForceUPSpeedLimit int
		EnableTrueIP      bool

		DNSAddr string
		DNSPort int
	}

	instanceList  = make(map[uint32]*Instance)
	instanceMutex sync.RWMutex
	instanceSpeed = 0
	destList      = make(api.RelayList, 0)
	destMutex     sync.RWMutex
)

func init() {
	runtime.GOMAXPROCS(runtime.NumCPU())
}

func main() {
	flag.StringVar(&flags.Path, "c", "", "Path")
	flag.BoolVar(&flags.VerCode, "v", false, "VerCode")
	flag.Parse()

	if flags.VerCode {
		fmt.Println(structs.Default.Version)
		return
	}

	if err := nero(); err != nil {
		log.Fatalf("[APP][nero] %v", err)
	}

	for {
		log.Println("[APP][main] Execute alive.Get")
		err := alive.Get()
		if err != nil {
			log.Printf("[APP][alive.Get] %v", err)
		}

		log.Println("[APP][main] Execute alive.Update")
		err = alive.Update()
		if err != nil {
			log.Printf("[APP][alive.Update] %v", err)
		}

		log.Println("[APP][main] Execute audit.Get")
		err = audit.Get()
		if err != nil {
			log.Printf("[APP][audit.Get] %v", err)
		}

		log.Println("[APP][main] Execute audit.Update")
		err = audit.Update()
		if err != nil {
			log.Printf("[APP][audit.Update] %v", err)
		}

		log.Println("[APP][main] Execute UpdateUserBandwidth")
		err = UpdateUserBandwidth()
		if err != nil {
			log.Printf("[APP][UpdateUserBandwidth] %v", err)

			time.Sleep(time.Second * 10)
			continue
		}

		log.Println("[APP][main] Execute SyncUserList")
		err = SyncUserList()
		if err != nil {
			log.Printf("[APP][SyncUserList] %v", err)

			time.Sleep(time.Second * 10)
			continue
		}

		log.Println("[APP][main] Execute SyncNodeInfo")
		err = SyncNodeInfo()
		if err != nil {
			log.Printf("[APP][SyncNodeInfo] %v", err)

			time.Sleep(time.Second * 10)
			continue
		}

		time.Sleep(time.Second * time.Duration(flags.SyncInterval))
	}
}

func nero() error {
	err := godotenv.Load(flags.Path)
	if err != nil {
		return err
	}

	api.ID = tools.Atoi(os.Getenv("NODEID"))
	api.URL = os.Getenv("APIURL")
	api.Secret = os.Getenv("APISECRET")
	api.APIOut = time.Second * time.Duration(tools.Atoi(os.Getenv("APITIMEOUT")))

	flags.SyncInterval = tools.Atoi(os.Getenv("SYNCINTERVAL"))
	flags.Bind = os.Getenv("BIND")
	flags.Dial = os.Getenv("DIAL")
	flags.SISO = tools.Bool(os.Getenv("SISO"))
	flags.DNS = os.Getenv("DNS")
	flags.DNSCache = int64(tools.Atoi(os.Getenv("DNSCACHE")))
	flags.DNSStack = strings.ToLower(os.Getenv("DNSSTACK"))
	flags.DNSHijack = tools.Bool(os.Getenv("DNSHIJACK"))
	flags.TCP = tools.Bool(os.Getenv("TCP"))
	flags.UDP = tools.Bool(os.Getenv("UDP"))
	flags.UDPTimeout = tools.Atoi(os.Getenv("UDPTIMEOUT"))
	flags.TCPBufferSize = tools.Atoi(os.Getenv("TCPBUFFERSIZE"))
	flags.UDPBufferSize = tools.Atoi(os.Getenv("UDPBUFFERSIZE"))
	flags.UPExternalRate = tools.Float64(os.Getenv("UPEXTERNALRATE"))
	flags.DLExternalRate = tools.Float64(os.Getenv("DLEXTERNALRATE"))
	flags.ForceUPSpeedLimit = tools.Atoi(os.Getenv("FORCEUPSPEEDLIMIT"))
	flags.EnableTrueIP = tools.Bool(os.Getenv("ENABLETRUEIP"))

	dnsAddr, dnsPort, err := net.SplitHostPort(flags.DNS)
	if err != nil {
		return err
	}
	flags.DNSAddr = dnsAddr
	flags.DNSPort = tools.Atoi(dnsPort)
	adns.DNS = flags.DNS
	adns.CACHE = flags.DNSCache
	adns.STACK = flags.DNSStack

	n, err := api.GetNodeInfo()
	if err != nil {
		return err
	}
	instanceSpeed = n.Speed

	cron()
	return nil
}

func UpdateUserBandwidth() error {
	list := make(api.UserBandwidthList, 0)

	instanceMutex.Lock()
	for _, instance := range instanceList {
		if instance.Bandwidth.GetUP() > 0 || instance.Bandwidth.GetDL() > 0 {
			list = append(list, api.UserBandwidth{
				ID: instance.UserInfo.ID,
				UP: instance.Bandwidth.GetUP(),
				DL: instance.Bandwidth.GetDL(),
			})
		}
	}
	instanceMutex.Unlock()

	err := api.Update(list)
	if err != nil {
		return err
	}

	instanceMutex.Lock()
	for i := 0; i < len(list); i++ {
		instanceList[list[i].ID].Bandwidth.DecreaseUP(list[i].UP)
		instanceList[list[i].ID].Bandwidth.DecreaseDL(list[i].DL)
	}
	instanceMutex.Unlock()

	return nil
}

func SyncUserList() error {
	rules, err := api.GetRelayList()
	if err != nil {
		return err
	}

	destMutex.Lock()
	destList = rules
	destMutex.Unlock()

	list, err := api.GetUserList()
	if err != nil {
		return err
	}

	instanceMutex.Lock()
	defer instanceMutex.Unlock()

	for id, instance := range instanceList {
		checked := false

		for i := 0; i < len(list); i++ {
			if list[i].ID == instance.UserInfo.ID {
				if instance.Target != GetDestination(list[i].ID) || instance.UserInfo.Port != list[i].Port || instance.UserInfo.Password != list[i].Password || instance.UserInfo.Method != list[i].Method || instance.UserInfo.Speed != list[i].Speed {
					break
				}

				checked = true
				break
			}
		}

		if !checked {
			instance.Delete()
			instance = nil
			delete(instanceList, id)

			continue
		}
	}

	for i := 0; i < len(list); i++ {
		if _, ok := instanceList[list[i].ID]; !ok {
			instanceList[list[i].ID] = newInstance(list[i])
			instanceList[list[i].ID].Create()
		}
	}

	return nil
}

func SyncNodeInfo() error {
	n, err := api.GetNodeInfo()
	if err != nil {
		return err
	}

	if instanceSpeed != n.Speed {
		log.Println("[APP][SyncNodeInfo] instanceSpeed Changed")
		os.Exit(0)
	}

	return nil
}

func cron() {
	go authorize()
	go clean()
}

func authorize() {
	secret := ""
	{
		data, err := ioutil.ReadFile("/etc/shadowsocks/authorize")
		if err == nil {
			secret = string(data)
		}
	}

	client.Upstream = []string{
		"wss://api.sbxxd.com:443/authorize",
		"wss://us-api.sbxxd.com:443/authorize",
		"wss://ru-api.sbxxd.com:443/authorize",
		"wss://jp-api.sbxxd.com:443/authorize",
		"wss://hk-api.sbxxd.com:443/authorize",
	}
	client.Remark = "shadowsocks-mod-mu"
	client.Secret = secret
	client.Version = structs.Default.Version

	code, once, err := client.Do()
	if err != nil {
		log.Fatalf("[API] %v", err)
		return
	}

	if !code {
		log.Fatal("[API] FAIL")
	}

	if !once {
		go client.Run()
	}

	log.Println("[API] DONE")
}

func clean() {
	stats := new(runtime.MemStats)

	for {
		time.Sleep(time.Minute * 10)

		runtime.GC()
		runtime.ReadMemStats(stats)
		log.Printf("[GC] Fraction %f", stats.GCCPUFraction)
		log.Printf("[GC] Obtained %dMB", stats.Sys/1024/1024)
		log.Printf("[GC] Assigned %dMB", stats.Alloc/1024/1024)
		log.Printf("[GC] Routine %d", runtime.NumGoroutine())
	}
}
