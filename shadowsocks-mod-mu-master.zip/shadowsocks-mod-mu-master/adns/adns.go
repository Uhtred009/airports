package adns

import (
	"context"
	"errors"
	"net"
	"sync"
	"time"
)

var (
	ErrIPNotFound = errors.New("IP Not Found")

	DNS         = "1.1.1.1:53"
	CACHE int64 = 120
	STACK       = "ip4"

	DefaultResolver = NewResolver()

	binder = net.Dialer{
		Timeout: time.Second * 10,
	}
	dialer = net.Resolver{
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			return binder.DialContext(ctx, network, DNS)
		},
	}
)

type Role struct {
	IPs []net.IP

	Last int64
}

type Resolver struct {
	sync.RWMutex

	cache map[string]*Role
}

func (r *Resolver) Lookup(address string) ([]net.IP, error) {
	list, err := dialer.LookupIP(context.Background(), STACK, address)
	if err != nil {
		return nil, err
	}

	r.Lock()
	r.cache[address] = &Role{IPs: list, Last: time.Now().Unix()}
	r.Unlock()

	return list, nil
}

func (r *Resolver) Fetch(address string) ([]net.IP, error) {
	r.RLock()
	if list, ok := r.cache[address]; ok {
		r.RUnlock()
		return list.IPs, nil
	}
	r.RUnlock()

	return r.Lookup(address)
}

func (r *Resolver) FetchOne(address string) (net.IP, error) {
	list, err := r.Fetch(address)
	if err != nil {
		return nil, err
	}

	if len(list) == 0 {
		return nil, ErrIPNotFound
	}

	return list[0], nil
}

func (r *Resolver) Run() {
	for {
		time.Sleep(time.Second * 30)

		r.Lock()
		current := time.Now().Unix()
		for id, value := range r.cache {
			if current-value.Last > CACHE {
				delete(r.cache, id)
			}
		}
		r.Unlock()
	}
}

func NewResolver() *Resolver {
	dns := &Resolver{cache: make(map[string]*Role)}
	go dns.Run()

	return dns
}

func Fetch(address string) (string, error) {
	addr, port, err := net.SplitHostPort(address)
	if err != nil {
		return "", err
	}

	if net.ParseIP(addr) != nil {
		return address, nil
	}

	adtr, err := DefaultResolver.FetchOne(addr)
	if err != nil {
		return "", err
	}

	return net.JoinHostPort(adtr.String(), port), nil
}
