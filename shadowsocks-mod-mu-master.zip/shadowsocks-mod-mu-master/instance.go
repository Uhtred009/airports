package main

import (
	"log"
	"net"

	"github.com/juju/ratelimit"
	"rixcloud.moe/shadowsocks/shadowsocks/core"

	api "rixcloud.moe/shadowsocks/mod-mu-api"
)

type Instance struct {
	Started    bool
	TCPStarted bool
	UDPStarted bool

	TCPSocket net.Listener
	UDPSocket net.PacketConn

	Target    string
	UserInfo  api.UserInfo
	Bandwidth *Bandwidth
	UPBucket  *ratelimit.Bucket
	DLBucket  *ratelimit.Bucket

	Cipher core.Cipher
}

func (i *Instance) Create() {
	if !i.Started {
		i.Started = true

		if i.Cipher == nil {
			cipher, err := core.PickCipher(i.UserInfo.Method, nil, i.UserInfo.Password)
			if err != nil {
				log.Printf("[APP][i.Create][%d] %v", i.UserInfo.ID, err)
				return
			}
			i.Cipher = cipher
		}
	}

	if i.Target == "" {
		if flags.TCP && !i.TCPStarted {
			go i.tcpListen()
		}

		if flags.UDP && !i.UDPStarted {
			go i.udpListen()
		}

		return
	}

	if flags.TCP && !i.TCPStarted {
		go i.tcpRelay()
	}

	if flags.UDP && !i.UDPStarted {
		go i.udpRelay()
	}
}

func (i *Instance) Delete() {
	if i.Started {
		i.Started = false

		if flags.TCP && i.TCPSocket != nil {
			i.TCPSocket.Close()
			i.TCPSocket = nil
		}

		if flags.UDP && i.UDPSocket != nil {
			i.UDPSocket.Close()
			i.UDPSocket = nil
		}
	}
}

func newInstance(data api.UserInfo) *Instance {
	var aBucket *ratelimit.Bucket
	if flags.ForceUPSpeedLimit > 0 {
		aBucket = ratelimit.NewBucketWithRate(1024*128*float64(flags.ForceUPSpeedLimit), 1024*128*int64(flags.ForceUPSpeedLimit))
	}

	var xBucket *ratelimit.Bucket
	if instanceSpeed > 0 {
		xBucket = ratelimit.NewBucketWithRate(1024*128*float64(instanceSpeed), 1024*128*int64(instanceSpeed))
	} else if data.Speed > 0 {
		xBucket = ratelimit.NewBucketWithRate(1024*128*float64(data.Speed), 1024*128*int64(data.Speed))
	}

	instance := new(Instance)
	instance.Started = false
	instance.TCPStarted = false
	instance.UDPStarted = false
	instance.Target = GetDestination(data.ID)
	instance.UserInfo = data
	instance.Bandwidth = newBandwidth()
	instance.UPBucket = aBucket
	instance.DLBucket = xBucket
	return instance
}
