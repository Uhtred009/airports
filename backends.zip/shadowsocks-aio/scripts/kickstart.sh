#!/usr/bin/env bash
apt update || exit $?
apt dist-upgrade -y || exit $?
apt install lsb-release -y || exit $?
apt autoremove --purge -y || exit $?

name=''
case $(lsb_release -cs) in
    'bookworm') # Debian 12
        name='debian-bookworm'
        ;;
    'bullseye') # Debian 11
        name='debian-bullseye'
        ;;
    'buster')   # Debian 10
        name='debian-buster'
        ;;
    'stretch')  # Debian 9
        name='debian-stretch'
        ;;
    'jammy')    # Ubuntu 22.04
        name='ubuntu-jammy'
        ;;
    'impish')   # Ubuntu 21.10
        name='ubuntu-impish'
        ;;
    'focal')    # Ubuntu 20.04
        name='ubuntu-focal'
        ;;
    'bionic')   # Ubuntu 18.04
        name='ubuntu-bionic'
        ;;
    *)
        exit 1
esac

if [[ ! -d '/etc/shadowsocks-aio' ]]; then
    mkdir /etc/shadowsocks-aio
fi

if [[ ! -f '/etc/shadowsocks-aio/default.env' ]]; then
    cp -f example.env /etc/shadowsocks-aio/default.env
fi

cp -f "./$name/shadowsocks-aio" .
chmod +x shadowsocks-aio

cp -f shadowsocks-aio /usr/bin
cp -f example.service /etc/systemd/system/shadowsocks-aio.service
cp -f example@.service /etc/systemd/system/shadowsocks-aio@.service
systemctl daemon-reload
exit 0
