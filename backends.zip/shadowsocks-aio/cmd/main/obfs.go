package main

import (
	"crypto/cipher"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"time"

	"ryzen.moe/backends/dns"
	"ryzen.moe/backends/shadowsocks-aio/tools"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

var (
	ErrSourceBanned = errors.New("banned (source)")
	ErrTargetBanned = errors.New("banned (target)")
	ErrUserNotFound = errors.New("user not found")
)

type TCPOBFS struct {
	net.Conn

	id uint64

	instance *Instance

	decryptor cipher.AEAD
	encryptor cipher.AEAD
	rnonce    [12]byte
	wnonce    [12]byte
	rbuffer   []byte
	wbuffer   []byte

	buffer []byte
	offset int
}

func NewTCPOBFS(client net.Conn, id uint64) net.Conn {
	return &TCPOBFS{
		Conn: client,

		id: id,
	}
}

func (o *TCPOBFS) CheckReadBuffer(length int) {
	if len(o.rbuffer) < length {
		o.rbuffer = make([]byte, length)
	}
}

func (o *TCPOBFS) CheckSendBuffer(length int) {
	if len(o.wbuffer) < length {
		o.wbuffer = make([]byte, length)
	}
}

func (o *TCPOBFS) Read(data []byte) (int, error) {
	if o.buffer != nil {
		size := copy(data, o.buffer[o.offset:])
		o.offset += size

		if len(o.buffer) <= o.offset {
			o.buffer = nil
			o.offset = 0
		}

		return size, nil
	}

	if o.decryptor == nil {
		o.CheckReadBuffer(32 + 2 + 16)
		if _, err := io.ReadFull(o.Conn, o.rbuffer[:32+2+16]); err != nil {
			return 0, fmt.Errorf("io.ReadFull: %v", err)
		}
		o.decryptor, o.instance = SearchInstance(o.id, o.rbuffer[:32+2+16])
		if o.decryptor == nil || o.instance == nil {
			CreateInstanceBlock(o.id)
			return 0, ErrUserNotFound
		}
		increment(o.rnonce[:])

		length := int(binary.BigEndian.Uint16(o.rbuffer[:2])) & 0x3fff

		o.CheckReadBuffer(length + 16)
		if _, err := io.ReadFull(o.Conn, o.rbuffer[:length+16]); err != nil {
			return 0, fmt.Errorf("io.ReadFull: %v", err)
		}
		if _, err := o.decryptor.Open(o.rbuffer[:0], o.rnonce[:], o.rbuffer[:length+16], nil); err != nil {
			return 0, fmt.Errorf("decryptor.Open: %v", err)
		}
		increment(o.rnonce[:])

		size := copy(data, o.rbuffer[:length])
		if length > size {
			o.buffer = make([]byte, length)
			o.offset = size

			copy(o.buffer, o.rbuffer[:length])
		}

		o.instance.Bandwidth.IncreaseUP(int64(length))
		return size, nil
	}

	o.CheckReadBuffer(2 + 16)
	if _, err := io.ReadFull(o.Conn, o.rbuffer[:2+16]); err != nil {
		return 0, fmt.Errorf("io.ReadFull: %v", err)
	}
	if _, err := o.decryptor.Open(o.rbuffer[:0], o.rnonce[:], o.rbuffer[:2+16], nil); err != nil {
		return 0, fmt.Errorf("o.decryptor.Open: %v", err)
	}
	increment(o.rnonce[:])

	length := int(binary.BigEndian.Uint16(o.rbuffer[:2])) & 0x3fff

	o.CheckReadBuffer(length + 16)
	if _, err := io.ReadFull(o.Conn, o.rbuffer[:length+16]); err != nil {
		return 0, fmt.Errorf("io.ReadFull: %v", err)
	}
	if _, err := o.decryptor.Open(o.rbuffer[:0], o.rnonce[:], o.rbuffer[:length+16], nil); err != nil {
		return 0, fmt.Errorf("o.decryptor.Open: %v", err)
	}
	increment(o.rnonce[:])

	size := copy(data, o.rbuffer[:length])
	if length > size {
		o.buffer = make([]byte, length)
		o.offset = size

		copy(o.buffer, o.rbuffer[:length])
	}

	o.instance.Bandwidth.IncreaseUP(int64(length))
	return size, nil
}

func (o *TCPOBFS) Write(data []byte) (int, error) {
	if o.encryptor == nil {
		o.CheckSendBuffer(32 + 2 + 16 + len(data) + 16)
		rand.Read(o.wbuffer[:32])

		o.encryptor = CreateCiph(o.instance.KDF[:], o.wbuffer[:32])
		if o.encryptor == nil {
			return 0, io.EOF
		}

		binary.BigEndian.PutUint16(o.wbuffer[32:32+2], uint16(len(data)))
		o.encryptor.Seal(o.wbuffer[32:32], o.wnonce[:], o.wbuffer[32:32+2], nil)
		increment(o.wnonce[:])

		copy(o.wbuffer[32+2+16:32+2+16+len(data)], data)
		o.encryptor.Seal(o.wbuffer[32+2+16:32+2+16], o.wnonce[:], o.wbuffer[32+2+16:32+2+16+len(data)], nil)
		increment(o.wnonce[:])

		if _, err := o.Conn.Write(o.wbuffer[:32+2+16+len(data)+16]); err != nil {
			return 0, fmt.Errorf("o.Conn.Write: %v", err)
		}

		o.instance.Bandwidth.IncreaseDL(int64(len(data)))
		return len(data), nil
	}

	o.CheckSendBuffer(2 + 16 + len(data) + 16)
	binary.BigEndian.PutUint16(o.wbuffer[0:], uint16(len(data)))
	o.encryptor.Seal(o.wbuffer[:0], o.wnonce[:], o.wbuffer[:2], nil)
	increment(o.wnonce[:])

	copy(o.wbuffer[2+16:2+16+len(data)], data)
	o.encryptor.Seal(o.wbuffer[2+16:2+16], o.wnonce[:], o.wbuffer[2+16:2+16+len(data)], nil)
	increment(o.wnonce[:])

	if _, err := o.Conn.Write(o.wbuffer[:2+16+len(data)+16]); err != nil {
		return 0, fmt.Errorf("o.Conn.Write: %v", err)
	}

	o.instance.Bandwidth.IncreaseDL(int64(len(data)))
	return len(data), nil
}

type UDPOBFS struct {
	client net.PacketConn
	remote net.PacketConn

	from     net.Addr
	instance *Instance
}

func NewUDPOBFS(client net.PacketConn, from net.Addr) *UDPOBFS {
	return &UDPOBFS{
		client: client,

		from: from,
	}
}

func (o *UDPOBFS) Create(bind net.IP, from string, data []byte, size int) error {
	id := uint64(0)
	{
		host, _, err := net.SplitHostPort(from)
		if err != nil {
			host = from
		}

		id = tools.ChecksumCRC64(bind, []byte(host))
	}

	if SearchInstanceBlock(id) {
		return ErrSourceBanned
	}

	_, o.instance = SearchInstance(id, data)
	if o.instance == nil {
		CreateInstanceBlock(id)
		return ErrUserNotFound
	}
	o.instance.Bandwidth.IncreaseUP(int64(len(data)))

	target := socks.SplitAddr(data[0:])
	if target == nil {
		return fmt.Errorf("sock.SplitAddr: failed")
	}

	targetHost, targetPort, err := net.SplitHostPort(target.String())
	if err != nil {
		return fmt.Errorf("net.SplitHostPort: %v", err)
	}

	targetIP, err := dns.Fetch(targetHost)
	if err != nil || targetIP == nil {
		return fmt.Errorf("dns.Fetch: %v", err)
	}

	if done, err := banned.Contains(targetIP); err == nil && done {
		return ErrTargetBanned
	}

	targetNP, err := net.ResolveUDPAddr("udp", net.JoinHostPort(targetIP.String(), targetPort))
	if err != nil {
		return fmt.Errorf("net.ResolveUDPAddr: %v", err)
	}

	{
		addr := ""
		if flags.SISO {
			addr = bind.String()
		}

		o.remote, err = net.ListenPacket("udp", net.JoinHostPort(addr, ""))
		if err != nil {
			return fmt.Errorf("net.ListenPacket: %v", err)
		}
	}

	if _, err = o.remote.WriteTo(data[len(target):size-32-16], targetNP); err != nil {
		o.remote.Close()
		return fmt.Errorf("remote.WriteTo: %v", err)
	}

	log.Printf("[UDP][%s][%d] %s - %s:%s (%s)",
		bind,
		time.Now().Unix(),
		from,
		targetHost, targetPort,
		targetIP.String(),
	)
	return nil
}

func (o *UDPOBFS) UP(data []byte, size int) error {
	o.instance.Bandwidth.IncreaseUP(int64(size))

	ciph := CreateCiph(o.instance.KDF[:], data[:32])
	if _, err := ciph.Open(data[32:32], zero[:12], data[32:], nil); err != nil {
		return fmt.Errorf("ciph.Open: %v", err)
	}

	target := socks.SplitAddr(data[32:])
	if target == nil {
		return fmt.Errorf("socks.SplitAddr: %d", data[32])
	}

	targetHost, targetPort, err := net.SplitHostPort(target.String())
	if err != nil {
		return fmt.Errorf("net.SplitHostPort: %v", err)
	}

	targetIP, err := dns.Fetch(targetHost)
	if err != nil || targetIP == nil {
		return fmt.Errorf("dns.Fetch: %v", err)
	}

	if done, err := banned.Contains(targetIP); err == nil && done {
		return ErrTargetBanned
	}

	targetNP, err := net.ResolveUDPAddr("udp", net.JoinHostPort(targetIP.String(), targetPort))
	if err != nil {
		return fmt.Errorf("net.ResolveUDPAddr: %v", err)
	}

	if _, err = o.remote.WriteTo(data[32+len(target):size-16], targetNP); err != nil {
		return fmt.Errorf("remote.WriteTo: %v", err)
	}

	return nil
}

func (o *UDPOBFS) DL() {
	defer o.remote.SetDeadline(time.Now())

	buffer := make([]byte, flags.UDPBUFFERSIZE)
	packed := make([]byte, 32+1+16+2+flags.UDPBUFFERSIZE+16)

	for {
		o.remote.SetReadDeadline(time.Now().Add(flags.UDPTIMEOUT))
		size, from, err := o.remote.ReadFrom(buffer)
		if err != nil {
			break
		}
		o.instance.Bandwidth.IncreaseDL(int64(size))

		target := socks.ParseAddr(from.String())
		if target == nil {
			continue
		}

		rand.Read(packed[:32])
		copy(packed[32:], target)
		copy(packed[32+len(target):], buffer[:size])

		ciph := CreateCiph(o.instance.KDF[:], packed[:32])
		ciph.Seal(packed[32:32], zero[:12], packed[32:32+len(target)+size], nil)
		if _, err = o.client.WriteTo(packed[:32+len(target)+size+16], o.from); err != nil {
			break
		}
	}
}

func increment(data []byte) {
	for i := range data {
		data[i] += 1

		if data[i] != 0 {
			return
		}
	}
}
