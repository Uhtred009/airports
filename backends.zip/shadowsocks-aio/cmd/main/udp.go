package main

import (
	"errors"
	"fmt"
	"log"
	"net"
	"strconv"
	"sync"
	"time"

	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func udpServe(addr net.IP) {
	go func() {
		for {
			log.Printf("[UDP][%s] %v", addr.String(), udpListen(addr))

			time.Sleep(time.Second * 3)
		}
	}()
}

func udpListen(addr net.IP) error {
	ln, err := net.ListenPacket("udp", net.JoinHostPort(addr.String(), strconv.Itoa(flags.PORT)))
	if err != nil {
		return fmt.Errorf("net.ListenPacket: %v", err)
	}
	defer ln.Close()

	nm := NewNAT()
	buffer := make([]byte, flags.UDPBUFFERSIZE)

	for {
		size, from, err := ln.ReadFrom(buffer)
		if err != nil {
			return fmt.Errorf("ln.ReadFrom: %v", err)
		}

		var source socks.Addr = nil
		var packed []byte = nil

		if flags.TRUEV2 {
			source = socks.SplitAddr(buffer[:size])
			packed = buffer[len(source):size]
			size -= len(source)
		} else {
			source = socks.ParseAddr(from.String())
			packed = buffer[:size]
		}

		if source == nil || packed == nil || size < 32+1+4+2+1+16 {
			continue
		}

		remote := nm.Get(from.String())
		if remote == nil {
			remote = NewUDPOBFS(ln, from)
			if err = remote.Create(addr, source.String(), packed, size); err != nil {
				continue
			}

			nm.Create(from.String(), remote)
			continue
		}

		if err = remote.UP(packed, size); !errors.Is(err, ErrTargetBanned) {
			remote.remote.Close()
		}
	}
}

type NAT struct {
	sync.RWMutex

	m map[string]*UDPOBFS
}

func NewNAT() *NAT {
	return &NAT{m: make(map[string]*UDPOBFS)}
}

func (o *NAT) Get(id string) *UDPOBFS {
	o.RLock()
	defer o.RUnlock()

	return o.m[id]
}

func (o *NAT) Set(id string, conn *UDPOBFS) {
	o.Lock()
	defer o.Unlock()

	o.m[id] = conn
}

func (o *NAT) Create(id string, conn *UDPOBFS) {
	o.Set(id, conn)

	go func() {
		conn.DL()
		if conn = o.Delete(id); conn != nil {
			conn.remote.Close()
		}
		conn.remote.Close()
	}()
}

func (o *NAT) Delete(id string) *UDPOBFS {
	o.Lock()
	defer o.Unlock()

	conn, ok := o.m[id]
	if ok {
		delete(o.m, id)
		return conn
	}

	return nil
}
