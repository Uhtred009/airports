package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha1"
	"io"
	"net"
	"sync"
	"time"

	"github.com/yl2chen/cidranger"
	"golang.org/x/crypto/chacha20poly1305"
	"golang.org/x/crypto/hkdf"
	"ryzen.moe/backends/api"
	"ryzen.moe/shadowsocks/shadowsocks/core"
)

var (
	banned cidranger.Ranger

	instanceLock sync.RWMutex
	instanceList = make(map[int64]*Instance)

	instanceBlockLock sync.RWMutex
	instanceBlockList = make(map[uint64]*InstanceBlock)

	instanceCacheLock sync.RWMutex
	instanceCacheList = make(map[uint64]*InstanceCache)

	zero [1024]byte
)

func init() {
	list := []string{
		"0.0.0.0/8",
		"10.0.0.0/8",
		"100.64.0.0/10",
		"127.0.0.0/8",
		"169.254.0.0/16",
		"172.16.0.0/12",
		"192.0.0.0/24",
		"192.0.2.0/24",
		"192.88.99.0/24",
		"192.168.0.0/16",
		"198.18.0.0/15",
		"198.51.100.0/24",
		"203.0.113.0/24",
		"224.0.0.0/4",
		"233.252.0.0/24",
		"240.0.0.0/4",
		"255.255.255.255/32",
		"::1/128",
		"fc00::/7",
		"fe80::/10",
		"fd00::/8",
	}

	banned = cidranger.NewPCTrieRanger()
	for i := 0; i < len(list); i++ {
		_, cidr, _ := net.ParseCIDR(list[i])

		banned.Insert(cidranger.NewBasicRangerEntry(*cidr))
	}

	RunInstanceBlock()
	RunInstanceCache()
}

func CreateCiph(kdf []byte, data []byte) cipher.AEAD {
	encs := make([]byte, 32)
	if _, err := io.ReadFull(hkdf.New(sha1.New, kdf, data, []byte("ss-subkey")), encs); err != nil {
		return nil
	}

	if flags.SPEC {
		ciph, err := chacha20poly1305.New(encs)
		if err != nil {
			return nil
		}

		return ciph
	}

	ciph, err := aes.NewCipher(encs)
	if err != nil {
		return nil
	}

	aead, err := cipher.NewGCM(ciph)
	if err != nil {
		return nil
	}

	return aead
}

type Instance struct {
	KDF [32]byte

	UserInfo  *api.UserInfo
	Bandwidth *Bandwidth
}

func NewInstance(info *api.UserInfo) *Instance {
	instance := &Instance{
		UserInfo:  info,
		Bandwidth: NewBandwidth(),
	}

	copy(instance.KDF[:], core.KDF(info.Passwd, 32))
	return instance
}

func SearchInstance(id uint64, data []byte) (cipher.AEAD, *Instance) {
	done := false
	encs := make([]byte, len(data)-32-16)

	var ciph cipher.AEAD = nil
	var instance *Instance = nil

	instanceLock.RLock()
	defer instanceLock.RUnlock()

	list := SearchInstanceCache(id)
	for i := 0; i < len(list); i++ {
		ok := false

		instance, ok = instanceList[list[i]]
		if !ok {
			continue
		}

		ciph = CreateCiph(instance.KDF[:], data[:32])
		if ciph == nil {
			continue
		}

		if _, err := ciph.Open(encs[:0], zero[:12], data[32:], nil); err != nil {
			continue
		}

		done = true
		break
	}

	if !done {
		for _, instance = range instanceList {
			ciph = CreateCiph(instance.KDF[:], data[:32])
			if ciph == nil {
				continue
			}

			if _, err := ciph.Open(encs[:0], zero[:12], data[32:], nil); err != nil {
				continue
			}

			done = true
			break
		}

		if done {
			CreateInstanceCache(id, instance.UserInfo.ID)
		}
	}

	if !done {
		return nil, nil
	}

	copy(data, encs)
	return ciph, instance
}

type InstanceBlock struct {
	Unix int64
	Size int64
}

func CreateInstanceBlock(id uint64) {
	if flags.AUTOBAN == 0 {
		return
	}

	instanceBlockLock.Lock()
	defer instanceBlockLock.Unlock()

	if data, ok := instanceBlockList[id]; ok {
		data.Size += 1
		return
	}

	instanceBlockList[id] = &InstanceBlock{
		Unix: time.Now().Unix(),
		Size: 1,
	}
}

func SearchInstanceBlock(id uint64) bool {
	if flags.AUTOBAN == 0 {
		return false
	}

	instanceBlockLock.RLock()
	defer instanceBlockLock.RUnlock()

	if data, ok := instanceBlockList[id]; ok {
		if data.Size > flags.AUTOBANCOUNT {
			return true
		}
	}

	return false
}

func RunInstanceBlock() {
	if flags.AUTOBAN == 0 {
		return
	}

	go func() {
		for {
			time.Sleep(time.Second * 30)

			date := time.Now().Unix()

			instanceBlockLock.Lock()
			for id, data := range instanceBlockList {
				if date-data.Unix > flags.AUTOBAN {
					delete(instanceBlockList, id)
				}
			}
			instanceBlockLock.Unlock()
		}
	}()
}

type InstanceCache struct {
	Unix int64
	List []int64
}

func CreateInstanceCache(id uint64, uid int64) {
	instanceCacheLock.Lock()
	defer instanceCacheLock.Unlock()

	if data, ok := instanceCacheList[id]; ok {
		data.Unix = time.Now().Unix()
		data.List = append(data.List, uid)
		return
	}

	instanceCacheList[id] = &InstanceCache{Unix: time.Now().Unix(), List: []int64{uid}}
}

func SearchInstanceCache(id uint64) []int64 {
	instanceCacheLock.RLock()
	defer instanceCacheLock.RUnlock()

	data, ok := instanceCacheList[id]
	if !ok {
		return nil
	}

	return data.List
}

func RunInstanceCache() {
	go func() {
		for {
			time.Sleep(time.Second * 120)

			date := time.Now().Unix()

			instanceCacheLock.Lock()
			for id, data := range instanceCacheList {
				if date-data.Unix > 600 {
					delete(instanceCacheList, id)
				}
			}
			instanceCacheLock.Unlock()
		}
	}()
}
