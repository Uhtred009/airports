package main

import (
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"flag"
	"log"
	"time"

	"golang.org/x/crypto/chacha20poly1305"
)

var (
	ciph cipher.AEAD

	flags struct {
		Decode string
		Remark string
		Expire int64
	}
)

func init() {
	ciph, _ = chacha20poly1305.NewX([]byte{
		0x94, 0x46, 0xbe, 0x2a, 0x04, 0xcc, 0xd3, 0x7a,
		0x96, 0x84, 0x1e, 0xe2, 0x37, 0x1e, 0x0b, 0x5a,
		0xd3, 0x39, 0x08, 0x52, 0xd2, 0x2e, 0x4d, 0x17,
		0x3b, 0x4d, 0x94, 0x80, 0xfc, 0x48, 0x58, 0x2d,
	})

	flag.StringVar(&flags.Decode, "d", "", "Decode")
	flag.StringVar(&flags.Remark, "n", "fly2048", "Remark")
	flag.Int64Var(&flags.Expire, "e", 1, "Expire")
	flag.Parse()

	flags.Expire = time.Now().AddDate(0, int(flags.Expire), 0).Unix()
}

func main() {
	if flags.Decode != "" {
		decode()
	} else {
		encode()
	}
}

func decode() {
	buffer, err := base64.StdEncoding.DecodeString(flags.Decode)
	if err != nil {
		return
	}

	if _, err = ciph.Open(buffer[ciph.NonceSize():ciph.NonceSize()], buffer[:ciph.NonceSize()], buffer[ciph.NonceSize():], nil); err != nil {
		return
	}

	size := int(binary.LittleEndian.Uint16(buffer[ciph.NonceSize() : ciph.NonceSize()+2]))
	date := int64(binary.LittleEndian.Uint64(buffer[ciph.NonceSize()+2+size : ciph.NonceSize()+2+size+8]))
	expr := int64(binary.LittleEndian.Uint64(buffer[ciph.NonceSize()+2+size+8 : ciph.NonceSize()+2+size+8+8]))
	cstr := string(buffer[ciph.NonceSize()+2 : ciph.NonceSize()+2+size])

	log.Printf("%s", cstr)
	log.Printf("%s (%d) -> %s (%d)", time.Unix(date, 0).Format("2006-01-02 15:04:05"), date, time.Unix(expr, 0).Format("2006-01-02 15:04:05"), expr)
}

func encode() {
	log.Printf("%s", flags.Remark)
	log.Printf("%s (%d)", time.Unix(flags.Expire, 0).Format("2006-01-02 15:04:05"), flags.Expire)

	buffer := make([]byte, ciph.NonceSize()+2+len(flags.Remark)+8+8+ciph.Overhead())
	binary.LittleEndian.PutUint16(buffer[ciph.NonceSize():], uint16(len(flags.Remark)))
	binary.LittleEndian.PutUint64(buffer[ciph.NonceSize()+2+len(flags.Remark):], uint64(time.Now().Unix()))
	binary.LittleEndian.PutUint64(buffer[ciph.NonceSize()+2+len(flags.Remark)+8:], uint64(flags.Expire))
	rand.Read(buffer[:ciph.NonceSize()])
	copy(buffer[ciph.NonceSize()+2:], []byte(flags.Remark))
	ciph.Seal(buffer[ciph.NonceSize():ciph.NonceSize()], buffer[:ciph.NonceSize()], buffer[ciph.NonceSize():ciph.NonceSize()+2+len(flags.Remark)+8+8], nil)

	log.Printf("%s", base64.StdEncoding.EncodeToString(buffer))
}
