package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"math"
	"math/rand"
	"net"
	"time"

	"ryzen.moe/backends/shadowsocksr-aio/tools"
)

type TCPOBFS struct {
	net.Conn

	hasRecvHeader bool

	instance *Instance

	UserID uint32
	Passwd []byte

	UTC  int64
	CID  uint32
	SID  uint32
	Pack uint16
	Rand uint16

	PackID uint32
	RecvID uint32

	buffer []byte
	offset int
}

func NewTCPOBFS(client net.Conn) net.Conn {
	obfs := new(TCPOBFS)
	obfs.Conn = client
	obfs.hasRecvHeader = false
	obfs.PackID = 1
	obfs.RecvID = 1

	return obfs
}

func (o *TCPOBFS) Read(data []byte) (int, error) {
	if !o.hasRecvHeader {
		o.hasRecvHeader = true

		if err := o.RequestPart1(); err != nil {
			return 0, fmt.Errorf("o.RequestPart1: %v", err)
		}

		if err := o.RequestPart2(); err != nil {
			return 0, fmt.Errorf("o.RequestPart2: %v", err)
		}

		if err := o.RequestPart3(); err != nil {
			return 0, fmt.Errorf("o.RequestPart3: %v", err)
		}
	}

	return o.doRead(data)
}

func (o *TCPOBFS) Write(data []byte) (int, error) {
	return o.doWrite(data)
}

func (o *TCPOBFS) doRead(data []byte) (int, error) {
	if o.buffer != nil {
		size := copy(data, o.buffer[o.offset:])
		o.offset += size

		if len(o.buffer) == o.offset {
			o.buffer = nil
			o.offset = 0
		}

		return size, nil
	}

	/*
		+------+----------+--------------+-------------------------+----------+
		| Size | HMAC-MD5 | Random Bytes |         Payload         | HMAC-MD5 |
		+------+----------+--------------+-------------------------+----------+
		|  2   |     2    |   Variable   | Size - Random Bytes - 8 |     4    |
		+------+----------+--------------+-------------------------+----------+
	*/
	buffer := make([]byte, 4)
	if _, err := io.ReadFull(o.Conn, buffer); err != nil {
		return 0, err
	}
	length := binary.LittleEndian.Uint16(buffer[:2])

	if !bytes.Equal(buffer[2:4], tools.HMAC(newHashMethod, o.Secret(o.RecvID), buffer[:2])[:2]) {
		return 0, errors.New("hmac invalid")
	}

	buffer = append(buffer, make([]byte, length-4)...)
	if _, err := io.ReadFull(o.Conn, buffer[4:]); err != nil {
		return 0, err
	}

	if !bytes.Equal(buffer[length-4:], tools.HMAC(newHashMethod, o.Secret(o.RecvID), buffer[:length-4])[:4]) {
		return 0, errors.New("hmac invalid")
	}

	random := int(buffer[4])
	if random == math.MaxUint8 {
		random = int(binary.LittleEndian.Uint16(buffer[5:7]))
	}
	buffer = buffer[random+4:]
	buffer = buffer[:len(buffer)-4]

	if o.RecvID != math.MaxUint32 {
		o.RecvID++
	} else {
		o.RecvID = 1
	}

	size := copy(data, buffer)
	if len(buffer) > size {
		o.buffer = buffer
		o.offset = size
	}

	o.instance.Bandwidth.IncreaseUP(int64(len(buffer)))
	return size, nil
}

func (o *TCPOBFS) doWrite(data []byte) (int, error) {
	o.instance.Bandwidth.IncreaseDL(int64(len(data)))

	/*
		+------+----------+--------------+-------------------------+----------+
		| Size | HMAC-MD5 | Random Bytes |         Payload         | HMAC-MD5 |
		+------+----------+--------------+-------------------------+----------+
		|  2   |     2    |   Variable   | Size - Random Bytes - 8 |     4    |
		+------+----------+--------------+-------------------------+----------+
	*/
	random := 1
	if len(data) <= 1200 {
		if o.PackID > 4 {
			random += rand.Intn(32)
		} else {
			if len(data) > 900 {
				random += rand.Intn(128)
			} else {
				random += rand.Intn(512)
			}
		}
	}
	length := 2 + 2 + random + len(data) + 4
	buffer := make([]byte, length)

	// Size
	binary.LittleEndian.PutUint16(buffer[:2], uint16(length))

	// HMAC-MD5
	copy(buffer[2:4], tools.HMAC(newHashMethod, o.Secret(o.PackID), buffer[:2])[:2])

	// Random Bytes
	_, _ = rand.Read(buffer[4 : 4+random])
	if random < math.MaxUint8 {
		buffer[4] = byte(random)
	} else {
		buffer[4] = 0xff
		binary.LittleEndian.PutUint16(buffer[5:], uint16(random))
	}

	// Payload
	if len(data) > 0 {
		copy(buffer[4+random:], data)
	}

	// HMAC-MD5
	copy(buffer[length-4:], tools.HMAC(newHashMethod, o.Secret(o.PackID), buffer[:length-4])[:4])

	// Pack ID
	if o.PackID != math.MaxUint32 {
		o.PackID++
	} else {
		o.PackID = 1
	}

	if _, err := o.Conn.Write(buffer); err != nil {
		return 0, err
	}

	return len(data), nil
}

func (o *TCPOBFS) RequestPart1() error {
	/*
		Part 1
		+--------+----------+
		| Random | HMAC-MD5 |
		+--------+----------+
		|    1   |     6    |
		+--------+----------+
	*/
	data := make([]byte, 7)
	if _, err := io.ReadFull(o.Conn, data); err != nil {
		return fmt.Errorf("io.ReadFull: %v", err)
	}

	return nil
}

func (o *TCPOBFS) RequestPart2() error {
	/*
		Part 2
		+-----+----------------------------+----------+
		| UID | AES-128-CBC Encrypted Data | HMAC-MD5 |
		+-----+----------------------------+----------+
		|  4  |             16             |     4    |
		+-----+----------------------------+----------+

		AES-128-CBC Encrypted Data (Before Encryption)
		+-----+-----+---------------+-------------+---------------------+
		| UTC | CID | Connection ID | Pack Length | Random Bytes Length |
		+-----+---------------------+-------------+---------------------+
		|  4  |  4  |       4       |      2      |           2         |
		+-----+-----+---------------+-------------+---------------------+
	*/
	data := make([]byte, 24)
	if _, err := io.ReadFull(o.Conn, data); err != nil {
		return fmt.Errorf("io.ReadFull: %v", err)
	}

	// User ID
	o.UserID = binary.LittleEndian.Uint32(data[:4])

	// ----------------------------------
	// Decrypt AES-128-CBC Encrypted Data
	// ----------------------------------
	o.instance = GetInstance(o.UserID)
	if o.instance == nil {
		return errors.New("unknown user id")
	}
	o.Passwd = make([]byte, len(o.instance.Passwd))
	copy(o.Passwd, o.instance.Passwd)

	// Create Cipher for Decrypt
	b, err := aes.NewCipher(tools.KDF(base64.StdEncoding.EncodeToString(o.Passwd)+flags.PROTOC, 16))
	if err != nil {
		return fmt.Errorf("aes.NewCipher: %v", err)
	}

	// Decrypt Data
	decrypted := make([]byte, 16)
	iv := make([]byte, aes.BlockSize)
	cbc := cipher.NewCBCDecrypter(b, iv)
	cbc.CryptBlocks(decrypted, data[4:20])

	// Read Data
	o.UTC = int64(binary.LittleEndian.Uint32(decrypted[0:4]))
	o.CID = binary.LittleEndian.Uint32(decrypted[4:8])
	o.SID = binary.LittleEndian.Uint32(decrypted[8:12])
	o.Pack = binary.LittleEndian.Uint16(decrypted[12:14])
	o.Rand = binary.LittleEndian.Uint16(decrypted[14:16])
	// ----------------------------------
	// Decrypt AES-128-CBC Encrypted Data
	// ----------------------------------

	date := time.Now().Unix()
	if max(date, o.UTC)-min(date, o.UTC) > 10 {
		return errors.New("expired request detected")
	}

	return nil
}

func (o *TCPOBFS) RequestPart3() error {
	/*
		Part 3
		+--------------+------------------+----------+
		| Random Bytes | Origin SS Stream | HMAC-MD5 |
		+--------------+------------------+----------+
		|   Variable   |     Variable     |     4    |
		+--------------+------------------+----------+
	*/
	data := make([]byte, o.Rand)
	if _, err := io.ReadFull(o.Conn, data); err != nil {
		return fmt.Errorf("io.ReadFull: %v", err)
	}

	length := o.Pack - o.Rand - 31 - 4
	if length != 0 {
		o.buffer = make([]byte, length)
		if _, err := io.ReadFull(o.Conn, o.buffer); err != nil {
			return fmt.Errorf("io.ReadFull: %v", err)
		}
	}

	data = make([]byte, 4)
	if _, err := io.ReadFull(o.Conn, data); err != nil {
		return fmt.Errorf("io.ReadFull: %v", err)
	}

	return nil
}

func (o *TCPOBFS) Secret(id uint32) []byte {
	data := make([]byte, len(o.Passwd)+4)
	copy(data, o.Passwd)
	binary.LittleEndian.PutUint32(data[len(o.Passwd):], id)

	return data
}

type UDPOBFS struct {
	net.PacketConn

	instance *Instance
}

func NewUDPOBFS() *UDPOBFS {
	return new(UDPOBFS)
}

func (o *UDPOBFS) Decode(data []byte) error {
	if o.instance == nil {
		length := len(data) - 4
		id := binary.LittleEndian.Uint32(data[length-4 : length])

		instance := GetInstance(id)
		if instance == nil {
			return errors.New("unknown user id")
		}

		if !bytes.Equal(data[length:], tools.HMAC(newHashMethod, instance.Passwd, data[:length])[:4]) {
			return errors.New("hmac invalid")
		}

		o.instance = instance
	}

	return nil
}

func (o *UDPOBFS) ReadFrom(data []byte) (int, net.Addr, error) {
	size, from, err := o.PacketConn.ReadFrom(data)
	if size > 0 {
		o.instance.Bandwidth.IncreaseUP(int64(size))
	}

	return size, from, err
}

func (o *UDPOBFS) WriteTo(data []byte, addr net.Addr) (int, error) {
	o.instance.Bandwidth.IncreaseDL(int64(len(data)))

	return o.PacketConn.WriteTo(data, addr)
}

func min(a, b int64) int64 {
	if a > b {
		return b
	}

	return a
}

func max(a, b int64) int64 {
	if a > b {
		return a
	}

	return b
}
