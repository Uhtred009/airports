package main

import (
	"crypto/sha256"
	"encoding/hex"
	"sync"

	"ryzen.moe/backends/api"
)

var (
	instanceLock sync.RWMutex
	instanceList = make(map[int64]*Instance)

	instanceHashLock sync.RWMutex
	instanceHashList = make(map[[56]byte]int64)
)

type Instance struct {
	KDF [56]byte

	UserInfo  *api.UserInfo
	Bandwidth *Bandwidth
}

func NewInstance(info *api.UserInfo) *Instance {
	hash := sha256.Sum224([]byte(info.Uuid))
	data := make([]byte, hex.EncodedLen(sha256.Size224))
	hex.Encode(data, hash[:])

	instance := new(Instance)
	instance.UserInfo = info
	instance.Bandwidth = NewBandwidth()
	copy(instance.KDF[:], data)

	return instance
}

func GetInstance(data []byte) *Instance {
	var hash [56]byte
	copy(hash[:], data)

	instanceHashLock.RLock()
	id, ok := instanceHashList[hash]
	if !ok {
		instanceHashLock.RUnlock()
		return nil
	}
	instanceHashLock.RUnlock()

	instanceLock.RLock()
	instance, ok := instanceList[id]
	if !ok {
		instanceLock.RUnlock()
		return nil
	}
	instanceLock.RUnlock()

	return instance
}
