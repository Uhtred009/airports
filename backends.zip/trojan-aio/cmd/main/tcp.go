package main

import (
	"crypto/tls"
	"fmt"
	"io"
	"log"
	"net"
	"time"

	"ryzen.moe/backends/dns"
	"ryzen.moe/shadowsocks/shadowsocks/socks"
)

func tcpServe(addr net.IP) {
	go func() {
		for {
			log.Printf("[TCP][%s] %v", addr.String(), tcpListen(addr))

			time.Sleep(time.Second * 3)
		}
	}()
}

func tcpListen(addr net.IP) error {
	tlsConfig := tls.Config{}
	if flags.TLS {
		tlsCert, err := tls.LoadX509KeyPair(flags.CRT, flags.SEC)
		if err != nil {
			return fmt.Errorf("tls.LoadX509KeyPair: %v", err)
		}

		tlsConfig.Certificates = []tls.Certificate{tlsCert}
		tlsConfig.MinVersion = tls.VersionTLS11
		tlsConfig.MaxVersion = tls.VersionTLS13
		if flags.SNI != "" {
			tlsConfig.VerifyConnection = func(info tls.ConnectionState) error {
				if info.ServerName != flags.SNI {
					return io.EOF
				}

				return nil
			}
		}
	}

	ln, err := net.Listen("tcp", net.JoinHostPort(addr.String(), flags.PORT))
	if err != nil {
		return fmt.Errorf("net.Listen: %v", err)
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			return fmt.Errorf("ln.Accept: %v", err)
		}

		go tcpHandle(addr, client, &tlsConfig)
	}
}

func tcpHandle(addr net.IP, client net.Conn, tlsConfig *tls.Config) {
	defer client.Close()

	date := time.Now().Unix()
	from := client.RemoteAddr().String()
	if flags.TRUEIP {
		fromaddr, err := socks.ReadAddr(client)
		if err != nil {
			return
		}

		from = fromaddr.String()
	}

	if flags.TLS {
		client = tls.Server(client, tlsConfig)
	}

	buffer := make([]byte, flags.TCPBUFFERSIZE)
	if _, err := io.ReadFull(client, buffer[:59]); err != nil {
		return
	}

	instance := GetInstance(buffer[:56])
	if instance == nil {
		return
	}

	target, err := socks.ReadAddr(client)
	if err != nil {
		return
	}

	if _, err = io.ReadFull(client, buffer[:2]); err != nil {
		return
	}

	if buffer[58] == 0x03 {
		if !flags.UDP {
			return
		}

		log.Printf("[UDP][%s] %s - %s", addr, from, target)

		udpHandle(addr, client, instance)
		return
	}

	if !flags.TCP {
		return
	}

	targetHost, targetPort, err := net.SplitHostPort(target.String())
	if err != nil {
		return
	}

	targetIP, err := dns.Fetch(targetHost)
	if err != nil || targetIP == nil {
		return
	}

	dialer := net.Dialer{
		Timeout:   time.Second * 3,
		KeepAlive: time.Second * 9,
	}
	if flags.SISO {
		dialer.LocalAddr = &net.TCPAddr{IP: addr}
	} else if flags.DIAL != nil {
		dialer.LocalAddr = &net.TCPAddr{IP: addr}
	}

	remote, err := dialer.Dial("tcp", net.JoinHostPort(targetIP.String(), targetPort))
	if err != nil {
		return
	}
	defer remote.Close()

	UP := int64(0)
	DL := int64(0)
	channel := make(chan int, 0)

	go func() {
		UP, _ = io.CopyBuffer(remote, client, make([]byte, flags.TCPBUFFERSIZE))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())
		channel <- 0
	}()

	DL, _ = io.CopyBuffer(client, remote, make([]byte, flags.TCPBUFFERSIZE))
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())
	<-channel

	instance.Bandwidth.IncreaseUP(UP)
	instance.Bandwidth.IncreaseDL(DL)

	log.Printf("[TCP][%s][%d - %d] %s - %s (%s) [%.02fKB]",
		addr,
		date,
		time.Now().Unix(),
		from,
		target,
		targetIP,
		float64(UP+DL)/1024)
}
