package main

import "sync/atomic"

type Bandwidth struct {
	UP *int64
	DL *int64
}

func NewBandwidth() *Bandwidth {
	return &Bandwidth{
		UP: new(int64),
		DL: new(int64),
	}
}

func (o *Bandwidth) GetUP() int64 {
	return atomic.LoadInt64(o.UP)
}

func (o *Bandwidth) GetDL() int64 {
	return atomic.LoadInt64(o.DL)
}

func (o *Bandwidth) IncreaseUP(i int64) {
	atomic.AddInt64(o.UP, i)
}

func (o *Bandwidth) IncreaseDL(i int64) {
	atomic.AddInt64(o.DL, i)
}

func (o *Bandwidth) DecreaseUP(i int64) {
	atomic.AddInt64(o.UP, ^i)
}

func (o *Bandwidth) DecreaseDL(i int64) {
	atomic.AddInt64(o.DL, ^i)
}
