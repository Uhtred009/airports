package main

import (
	api "rixcloud.moe/shadowsocks/ls-api"
)

type InstanceList map[string]*Instance
type Instance struct {
	UserInfo  api.UserInfo
	Bandwidth *Bandwidth
}

func newInstance(data api.UserInfo) *Instance {
	instance := new(Instance)
	instance.UserInfo = data
	instance.Bandwidth = newBandwidth()
	return instance
}
