package main

import (
	"io"
	"log"
	"net"
	"strconv"
	"time"

	"rixcloud.moe/shadowsocks/shadowsocks/socks"
	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/core"
	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/core/adns"
)

func tcpHandle(session *core.Session) {
	defer session.Client.Close()

	if flags.TRUEIP {
		addr, err := socks.ReadAddr(session.Client)
		if err != nil {
			return
		}

		session.From = addr.String()
	} else {
		session.From = session.Client.RemoteAddr().String()
	}

	if _, err := io.ReadFull(session.Client, session.Hash[:]); err != nil {
		return
	}

	instance, date := GetInstanceCache(session.From, session.Hash)
	if instance == nil {
		return
	}
	session.Uuid = instance.ID.Hash
	session.Date = date

	if err := session.DecodeRequestHeader(); err != nil {
		log.Printf("[TCP] decode request header failed: %v", err)
		return
	}

	if session.Header.Type == 0x03 {
		return
	}

	if err := session.DecodeRequestContent(); err != nil {
		log.Printf("[TCP] decode request content failed: %v", err)
	}

	if err := session.EncodeResponseHeader(); err != nil {
		log.Printf("[TCP] encode response header failed: %v", err)
	}

	if err := session.EncodeResponseContent(); err != nil {
		log.Printf("[TCP] encode response content failed: %v", err)
	}

	switch session.Header.Type {
	case 0x01:
		handleTCP(session, instance)
	case 0x02:
		handleUDP(session, instance)
	case 0x03:
		return
	default:
		return
	}
}

func handleTCP(session *core.Session, instance *Instance) {
	addr, err := adns.Fetch(session.Header.Host)
	if addr == nil || err != nil {
		return
	}

	dialer := net.Dialer{
		Timeout:   time.Second * 4,
		KeepAlive: time.Second * 10,
	}
	if flags.SISO {
		dialer.LocalAddr = &net.TCPAddr{IP: session.Host, Port: 0}
	}

	if session.Remote, err = dialer.Dial("tcp", net.JoinHostPort(addr.String(), strconv.Itoa(session.Header.Port))); err != nil {
		return
	}
	session.Remote.(*net.TCPConn).SetKeepAlive(true)
	session.Remote.(*net.TCPConn).SetKeepAlivePeriod(time.Second * 10)
	defer session.Remote.Close()

	UP := int64(0)
	DL := int64(0)

	go func() {
		UP = core.CopyBuffer(session.Remote, session.DecryptionReader, make([]byte, 1446))
		session.Client.SetDeadline(time.Now())
		session.Remote.SetDeadline(time.Now())
	}()

	DL = core.CopyBuffer(session.EncryptionWriter, session.Remote, make([]byte, 1446))
	session.Client.SetDeadline(time.Now())
	session.Remote.SetDeadline(time.Now())

	instance.Traffic.IncreaseUP(UP)
	instance.Traffic.IncreaseDL(DL)

	log.Printf("[TCP][%d -> %d] %s <-> %s (%s) [%.2f KB]",
		session.Unix,
		time.Now().Unix(),
		session.From,
		net.JoinHostPort(session.Header.Host, strconv.Itoa(session.Header.Port)),
		addr.String(),
		float64(UP+DL)/1024)
}
