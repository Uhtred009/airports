package api

import (
	"database/sql"
	"fmt"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

var (
	DBTYPE string = "mysql"
	DBSPEC string = "root:toor@tcp(1.1.1.1:3306)/v2ray?timeout=10s"
)

func newConn() (*sql.DB, error) {
	conn, err := sql.Open(DBTYPE, DBSPEC)
	if err != nil {
		return nil, fmt.Errorf("sql.Open: %v", err)
	}

	conn.SetConnMaxLifetime(time.Second * 30)
	conn.SetConnMaxIdleTime(time.Second * 10)
	conn.SetMaxOpenConns(4)
	conn.SetMaxIdleConns(4)
	return conn, nil
}

func GetUserList() (UserList, error) {
	client, err := newConn()
	if err != nil {
		return nil, err
	}
	defer client.Close()

	result, err := client.Query("SELECT id, passwd FROM user WHERE enable=1 AND (is_multi_user=0 AND u+d<transfer_enable)")
	if err != nil {
		return nil, fmt.Errorf("client.Query: %v", err)
	}
	defer result.Close()

	list := make(UserList, 0)
	for result.Next() {
		info := &UserInfo{}

		if err = result.Scan(&info.ID, &info.Password); err != nil {
			return nil, fmt.Errorf("result.Scan: %v", err)
		}

		list = append(list, info)
	}

	return list, nil
}

func UpdateUserTraffic(list UserTrafficList) error {
	if len(list) == 0 {
		return nil
	}

	client, err := newConn()
	if err != nil {
		return err
	}
	defer client.Close()

	when1 := ""
	when2 := ""
	in := ""

	for i := 0; i < len(list); i++ {
		when1 += fmt.Sprintf(" WHEN %d THEN u+%d", list[i].ID, list[i].UP)
		when2 += fmt.Sprintf(" WHEN %d THEN d+%d", list[i].ID, list[i].DL)

		if in != "" {
			in += fmt.Sprintf(", %d", list[i].ID)
		} else {
			in = fmt.Sprintf("%d", list[i].ID)
		}
	}

	if _, err = client.Exec(fmt.Sprintf("UPDATE user SET u = CASE id %s END, d = CASE id %s END, t = %d WHERE id IN (%s)", when1, when2, time.Now().Unix(), in)); err != nil {
		return fmt.Errorf("client.Exec: %v", err)
	}

	return nil
}
