package api

import (
	"crypto/md5"
	"fmt"

	"github.com/google/uuid"
)

type UserInfo struct {
	ID       int64  `json:"id"`     // ID
	Password string `json:"passwd"` // Password
}
type UserList []*UserInfo

func (o *UserInfo) GetUUID() (uuid.UUID, error) {
	h := md5.New()
	h.Write(uuid.NameSpaceDNS[:])
	h.Write([]byte(fmt.Sprintf("%d|%s", o.ID, o.Password)))

	id := uuid.New()
	copy(id[:], h.Sum(nil))

	id[6] = (id[6] & 0x0f) | (0x03 << 4)
	id[8] = (id[8]&(0xff>>2) | (0x02 << 6))
	return id, nil
}

type UserTraffic struct {
	ID int64 `json:"id"`
	UP int64 `json:"up"`
	DL int64 `json:"dl"`
}
type UserTrafficList []*UserTraffic
