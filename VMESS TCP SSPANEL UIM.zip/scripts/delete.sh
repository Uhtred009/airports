#!/usr/bin/env bash
rm -f /usr/bin/vmess
rm -f /etc/systemd/system/vmess.service
rm -f /etc/systemd/system/vmess@.service
rm -f /etc/systemd/system/multi-user.target.wants/vmess@*.service

rm -fr /etc/vmess

systemctl daemon-reload

killall vmess
exit 0