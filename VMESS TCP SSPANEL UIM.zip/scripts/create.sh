#!/usr/bin/env bash
chmod +x vmess

if [[ ! -d /etc/vmess ]]; then
    mkdir -p /etc/vmess
fi

cp -f vmess /usr/bin/vmess
cp -f example.env /etc/vmess/default.env
cp -f example.service /etc/systemd/system/vmess.service
cp -f example@.service /etc/systemd/system/vmess@.service

systemctl daemon-reload
exit 0