package main

import (
	"fmt"
	"log"
	"math/rand"
	"net"
	"os"
	"strings"
	"time"

	"inet.af/netaddr"
	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/api"
	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/core"
	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/core/adns"
	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/tools"
)

var (
	flags struct {
		DBTYPE  string
		DBSPEC  string
		BIND    string
		PORT    string
		SISO    bool
		DNS     string
		DNSTTL  int64
		ALTERID int64
		TRUEIP  bool
	}
)

func init() {
	flags.DBTYPE = tools.Getenv("DBSPEC", "mysql")
	flags.DBSPEC = tools.Getenv("DBTYPE", "root:toor@tcp(1.1.1.1:3306)/v2ray?timeout=10s")
	flags.BIND = tools.Getenv("BIND", "")
	flags.PORT = tools.Getenv("PORT", "1080")
	flags.SISO = tools.Getenv("SISO", "false") == "true"
	flags.DNS = tools.Getenv("DNS", "1.1.1.1:53")
	flags.DNSTTL = tools.Atoi(tools.Getenv("DNSTTL", "120"), 120)
	flags.ALTERID = tools.Atoi("ALTERID", 1)
	flags.TRUEIP = tools.Getenv("TRUEIP", "false") == "true"

	api.DBTYPE = flags.DBTYPE
	api.DBSPEC = flags.DBSPEC

	adns.DNS = flags.DNS
	adns.DNSTTL = flags.DNSTTL
}

func main() {
	go adns.Run()
	go UpdateUserHash()
	go RunInstanceCache()

	go func() {
		zone := time.FixedZone("Asia/Shanghai", int((time.Hour * 8).Seconds()))

		date, err := time.ParseInLocation("2006-01-02", time.Now().In(zone).Format("2006-01-02"), zone)
		if err != nil {
			return
		}
		diff := date.AddDate(0, 0, 1).Add(time.Hour * 4).Add(time.Minute * 10).Sub(time.Now().In(zone))

		log.Printf("[REBOOT] Scheduled after %s", diff)

		time.Sleep(diff)
		os.Exit(0)
	}()

	// instanceLock.Lock()
	// instanceList[0] = NewInstance(&api.UserInfo{
	// 	ID:   0,
	// 	Uuid: "80946db0-8642-4d25-a721-79b3b2cac94a",
	// })
	// instanceLock.Unlock()

	// ListenTCP(":1080")

	if flags.BIND != "" {
		for _, name := range strings.Split(flags.BIND, ",") {
			adap, err := net.InterfaceByName(name)
			if err != nil {
				continue
			}

			adtr, err := adap.Addrs()
			if err != nil {
				continue
			}

			for i := 0; i < len(adtr); i++ {
				var addr netaddr.IP

				switch m := adtr[i].(type) {
				case *net.IPNet:
					ok := false

					if addr, ok = netaddr.FromStdIP(m.IP); !ok {
						continue
					}
				default:
					continue
				}

				if addr.IsGlobalUnicast() {
					go ListenTCP(addr.IPAddr().IP)
				}
			}
		}
	} else {
		go ListenTCP(net.IPv4(0, 0, 0, 0))
	}

	for {
		if err := UpdateUserTraffic(); err != nil {
			log.Printf("[APP] UpdateUserTraffic: %v", err)

			time.Sleep(time.Second * time.Duration(10+rand.Intn(10)))
			continue
		}

		if err := UpdateUserList(); err != nil {
			log.Printf("[APP] UpdateUserList: %v", err)

			time.Sleep(time.Second * time.Duration(10+rand.Intn(10)))
			continue
		}

		time.Sleep(time.Second * time.Duration(10+rand.Intn(120)))
	}
}

func ListenTCP(addr net.IP) {
	for {
		func() {
			ln, err := net.Listen("tcp", net.JoinHostPort(addr.String(), flags.PORT))
			if err != nil {
				return
			}
			defer ln.Close()

			for {
				client, err := ln.Accept()
				if err != nil {
					return
				}
				client.(*net.TCPConn).SetKeepAlive(true)
				client.(*net.TCPConn).SetKeepAlivePeriod(time.Second * 10)

				go tcpHandle(core.NewSession(addr, client))
			}
		}()

		time.Sleep(time.Second * 1)
	}
}

func UpdateUserTraffic() error {
	list := make(api.UserTrafficList, 0)

	instanceLock.RLock()
	for id, instance := range instanceList {
		UP := instance.Traffic.GetUP()
		DL := instance.Traffic.GetDL()

		if UP > 0 && DL > 0 {
			list = append(list, &api.UserTraffic{
				ID: id,
				UP: UP,
				DL: DL,
			})

			instance.Traffic.DecreaseUP(UP)
			instance.Traffic.DecreaseDL(DL)
		}
	}
	instanceLock.RUnlock()

	if err := api.UpdateUserTraffic(list); err != nil {
		return fmt.Errorf("api.UpdateUserTraffic: %v", err)
	}

	return nil
}

func UpdateUserList() error {
	list, err := api.GetUserList()
	if err != nil {
		return fmt.Errorf("api.GetUserList: %v", err)
	}

	instanceLock.Lock()
	defer instanceLock.Unlock()

	for id, instance := range instanceList {
		checked := false

		for i := 0; i < len(list); i++ {
			if list[i].ID == instance.UserInfo.ID {
				checked = true
				break
			}
		}

		if !checked {
			delete(instanceList, id)
		}
	}

	for i := 0; i < len(list); i++ {
		instance, ok := instanceList[list[i].ID]
		if !ok {
			instanceList[list[i].ID] = NewInstance(list[i])
			continue
		}

		if instance.UserInfo.Password != list[i].Password {
			delete(instanceList, list[i].ID)

			instanceList[list[i].ID] = NewInstance(list[i])
			continue
		}
	}

	return nil
}

func UpdateUserHash() {
	for {
		time.Sleep(time.Second * time.Duration(10+rand.Intn(5)))

		instanceLock.RLock()
		for _, instance := range instanceList {
			instance.UpdateUserHash()
		}
		instanceLock.RUnlock()
	}
}
