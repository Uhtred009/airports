package main

import (
	"log"
	"net"
	"strconv"
	"time"

	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/core"
	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/core/adns"
)

func handleUDP(session *core.Session, instance *Instance) {
	addr, err := adns.Fetch(session.Header.Host)
	if addr == nil || err != nil {
		return
	}

	dialer := net.Dialer{}
	if flags.SISO {
		dialer.LocalAddr = &net.UDPAddr{IP: session.Host, Port: 0}
	}

	if session.Remote, err = net.Dial("udp", net.JoinHostPort(addr.String(), strconv.Itoa(session.Header.Port))); err != nil {
		return
	}
	defer session.Remote.Close()

	UP := int64(0)
	DL := int64(0)

	go func() {
		UP = core.CopyBuffer(session.Remote, session.DecryptionReader, make([]byte, 1458))
		session.Client.SetDeadline(time.Now())
		session.Remote.SetDeadline(time.Now())
	}()

	DL = core.CopyBuffer(session.EncryptionWriter, session.Remote, make([]byte, 1458))
	session.Client.SetDeadline(time.Now())
	session.Remote.SetDeadline(time.Now())

	instance.Traffic.IncreaseUP(UP)
	instance.Traffic.IncreaseDL(DL)

	log.Printf("[UDP][%d -> %d] %s <-> %s (%s) [%.2f KB]",
		session.Unix,
		time.Now().Unix(),
		session.From,
		net.JoinHostPort(session.Header.Host, strconv.Itoa(session.Header.Port)),
		addr.String(),
		float64(UP+DL)/1024)
}
