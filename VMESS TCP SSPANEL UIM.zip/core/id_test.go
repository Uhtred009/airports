package core

import (
	"testing"

	"github.com/google/uuid"
)

func TestGenerateID(t *testing.T) {
	i := NewID(uuid.MustParse("80946db0-8642-4d25-a721-79b3b2cac94a"))
	t.Logf("%x %x", i.Uuid[:], i.Hash)

	ids := ComputeUserID(i.Uuid, 1)
	for _, id := range ids {
		t.Logf("%x %x", id.Uuid[:], id.Hash)
	}
}
