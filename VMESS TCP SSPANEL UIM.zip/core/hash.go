package core

import (
	"crypto/hmac"
	"crypto/md5"
	"encoding/binary"

	"github.com/google/uuid"
)

func ComputeUserHash(id uuid.UUID, date int64) (buffer [16]byte) {
	h := hmac.New(md5.New, id[:])
	binary.Write(h, binary.BigEndian, date)

	h.Sum(buffer[:0])
	return buffer
}
