package core

import "io"

func CopyBuffer(dst io.Writer, src io.Reader, buffer []byte) int64 {
	length := int64(0)

	for {
		size, err := src.Read(buffer)
		if err != nil {
			return length
		}
		length += int64(size)

		if _, err = dst.Write(buffer[:size]); err != nil {
			return length
		}
	}
}
