package core

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/md5"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"time"

	"golang.org/x/crypto/chacha20poly1305"
	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/core/crypto"
)

type Session struct {
	Unix int64
	Host net.IP

	From string

	Client net.Conn
	Remote net.Conn

	Hash [16]byte
	Uuid [16]byte
	Date int64

	Header RequestHeader

	ResponseK [16]byte
	ResponseV [16]byte

	EncryptionWriter io.Writer
	DecryptionReader io.Reader
}

func NewSession(host net.IP, client net.Conn) *Session {
	return &Session{Unix: time.Now().Unix(), Host: host, Client: client}
}

func (o *Session) DecodeRequestHeader() error {
	h := md5.New()
	binary.Write(h, binary.BigEndian, o.Date)
	binary.Write(h, binary.BigEndian, o.Date)
	binary.Write(h, binary.BigEndian, o.Date)
	binary.Write(h, binary.BigEndian, o.Date)
	v := h.Sum(nil)

	var stream cipher.Stream = nil
	{
		b, err := aes.NewCipher(o.Uuid[:])
		if err != nil {
			return fmt.Errorf("aes.NewCipher: %v", err)
		}

		stream = cipher.NewCFBDecrypter(b, v)
	}

	buffer := make([]byte, 38)
	if _, err := io.ReadFull(o.Client, buffer); err != nil {
		return fmt.Errorf("io.ReadFull: %v", err)
	}
	stream.XORKeyStream(buffer, buffer)

	if buffer[0] != 0x01 {
		return fmt.Errorf("unsupported protocol version: %d", buffer[0])
	}

	copy(o.Header.V[:], buffer[1:17])
	copy(o.Header.K[:], buffer[17:33])

	o.Header.Header = buffer[33]
	o.Header.Option = buffer[34]
	o.Header.Length = int(buffer[35] >> 4)
	o.Header.Method = int(buffer[35] & 0x0f)

	o.Header.ChunkStream = o.Header.Option&0x01 != 0
	o.Header.ReuseStream = o.Header.Option&0x02 != 0
	o.Header.ChunkMaskin = o.Header.Option&0x04 != 0
	o.Header.ChunkPaddin = o.Header.Option&0x08 != 0
	o.Header.AutheLength = o.Header.Option&0x10 != 0

	if o.Header.ReuseStream {
		return fmt.Errorf("unsupported option: reuse stream")
	}

	o.Header.Type = buffer[37]
	switch o.Header.Type {
	case 0x01, 0x02:
		{
			if _, err := io.ReadFull(o.Client, buffer[:3]); err != nil {
				return fmt.Errorf("io.ReadFull: %v", err)
			}
			stream.XORKeyStream(buffer[:3], buffer[:3])

			o.Header.Port = int(binary.BigEndian.Uint16(buffer[:2]))

			switch buffer[2] {
			case 0x01:
				{
					if _, err := io.ReadFull(o.Client, buffer[:4]); err != nil {
						return fmt.Errorf("io.ReadFull: %v", err)
					}
					stream.XORKeyStream(buffer[:4], buffer[:4])

					o.Header.Host = net.IP(buffer[:4]).String()
				}
			case 0x02:
				{
					if _, err := io.ReadFull(o.Client, buffer[:1]); err != nil {
						return fmt.Errorf("io.ReadFull: %v", err)
					}
					stream.XORKeyStream(buffer[:1], buffer[:1])

					length := int(buffer[0])
					if len(buffer) < length {
						buffer = make([]byte, length)
					}

					if _, err := io.ReadFull(o.Client, buffer[:length]); err != nil {
						return fmt.Errorf("io.ReadFull: %v", err)
					}
					stream.XORKeyStream(buffer[:length], buffer[:length])

					o.Header.Host = string(buffer[:length])
				}
			case 0x03:
				{
					if _, err := io.ReadFull(o.Client, buffer[:16]); err != nil {
						return fmt.Errorf("io.ReadFull: %v", err)
					}
					stream.XORKeyStream(buffer[:16], buffer[:16])

					o.Header.Host = net.IP(buffer[:16]).String()
				}
			default:
				return fmt.Errorf("unsupported address type: %d", buffer[2])
			}
		}
	case 0x03:
		o.Header.Host = "v1.mux.cool"
		o.Header.Port = 0
	default:
		return fmt.Errorf("unsupported command type: %d", o.Header.Type)
	}

	if len(buffer) < o.Header.Length {
		buffer = make([]byte, o.Header.Length)
	}

	if _, err := io.ReadFull(o.Client, buffer[:o.Header.Length]); err != nil {
		return fmt.Errorf("io.ReadFull: %v", err)
	}

	if len(buffer) < 4 {
		buffer = make([]byte, 4)
	}

	if _, err := io.ReadFull(o.Client, buffer[:4]); err != nil {
		return fmt.Errorf("io.ReadFull: %v", err)
	}

	return nil
}

func (o *Session) DecodeRequestContent() error {
	var parser crypto.ChunkSizeDecoder = &RawSizeParser{}
	if o.Header.ChunkMaskin {
		parser = NewShakeSizeParser(o.Header.V[:])
	}

	var paddin crypto.LengthGenerator
	if o.Header.ChunkPaddin {
		paddin = parser.(crypto.LengthGenerator)
	}

	switch o.Header.Method {
	case 5: // NONE
		if o.Header.ChunkStream {
			if o.Header.Type == 0x01 || o.Header.Type == 0x03 {
				o.DecryptionReader = crypto.NewChunkStreamReader(o.Client, parser)
				return nil
			}

			o.DecryptionReader = crypto.NewAuthenticationReader(&crypto.AEADAuthenticator{
				AEAD:                    &crypto.NoOpAuthenticator{},
				NonceGenerator:          crypto.GenerateEmptyBytes(),
				AdditionalDataGenerator: crypto.GenerateEmptyBytes(),
			}, o.Client, parser, paddin)
			return nil
		}

		o.DecryptionReader = o.Client
		return nil
	case 1: // LEGACY
		stream, err := crypto.NewAESCFBDecryptionStream(o.Header.K[:], o.Header.V[:])
		if err != nil {
			return nil
		}

		cipher := crypto.NewCryptionReader(o.Client, stream)
		if o.Header.ChunkStream {
			o.DecryptionReader = crypto.NewAuthenticationReader(&crypto.AEADAuthenticator{
				AEAD:                    &crypto.FnvAuthenticator{},
				NonceGenerator:          crypto.GenerateEmptyBytes(),
				AdditionalDataGenerator: crypto.GenerateEmptyBytes(),
			}, cipher, parser, paddin)
			return nil
		}

		o.DecryptionReader = cipher
		return nil
	case 3: // AES-128-GCM
		aead, err := crypto.NewAESGCM(o.Header.K[:])
		if err != nil {
			return fmt.Errorf("crypto.NewAESGCM: %v", err)
		}

		auth := &crypto.AEADAuthenticator{
			AEAD:                    aead,
			NonceGenerator:          crypto.GenerateChunkNonce(o.Header.V[:], uint32(aead.NonceSize())),
			AdditionalDataGenerator: crypto.GenerateEmptyBytes(),
		}

		o.DecryptionReader = crypto.NewAuthenticationReader(auth, o.Client, parser, paddin)
		return nil
	case 4: // CHACHA20-POLY1305
		aead, err := chacha20poly1305.New(crypto.GenerateChacha20Secret(o.Header.K[:]))
		if err != nil {
			return fmt.Errorf("chacha20poly1305.New: %v", err)
		}

		auth := &crypto.AEADAuthenticator{
			AEAD:                    aead,
			NonceGenerator:          crypto.GenerateChunkNonce(o.Header.V[:], uint32(aead.NonceSize())),
			AdditionalDataGenerator: crypto.GenerateEmptyBytes(),
		}

		o.DecryptionReader = crypto.NewAuthenticationReader(auth, o.Client, parser, paddin)
		return nil
	}

	return fmt.Errorf("unsupported decryption method: %d", o.Header.Method)
}

func (o *Session) EncodeResponseHeader() error {
	o.ResponseK = md5.Sum(o.Header.K[:])
	o.ResponseV = md5.Sum(o.Header.V[:])

	stream, err := crypto.NewAESCFBEncryptionStream(o.ResponseK[:], o.ResponseV[:])
	if err != nil {
		return fmt.Errorf("crypto.NewAESCFBEncryptionStream: %v", err)
	}

	buffer := []byte{o.Header.Header, o.Header.Option, 0x00, 0x00}
	stream.XORKeyStream(buffer, buffer)

	if _, err = o.Client.Write(buffer); err != nil {
		return fmt.Errorf("writer.Write: %v", err)
	}

	return nil
}

func (o *Session) EncodeResponseContent() error {
	var parser crypto.ChunkSizeEncoder = &RawSizeParser{}
	if o.Header.ChunkMaskin {
		parser = NewShakeSizeParser(o.ResponseV[:])
	}

	var paddin crypto.LengthGenerator
	if o.Header.ChunkPaddin {
		paddin = parser.(crypto.LengthGenerator)
	}

	switch o.Header.Method {
	case 5: // NONE
		if o.Header.ChunkStream {
			if o.Header.Type == 0x01 || o.Header.Type == 0x03 {
				o.EncryptionWriter = crypto.NewChunkStreamWriter(o.Client, parser)
				return nil
			}

			o.EncryptionWriter = crypto.NewAuthenticationWriter(&crypto.AEADAuthenticator{
				AEAD:                    &crypto.NoOpAuthenticator{},
				NonceGenerator:          crypto.GenerateEmptyBytes(),
				AdditionalDataGenerator: crypto.GenerateEmptyBytes(),
			}, o.Client, parser, paddin)
			return nil
		}

		o.EncryptionWriter = o.Client
		return nil
	case 1: // LEGACY
		if o.Header.ChunkStream {
			o.EncryptionWriter = crypto.NewAuthenticationWriter(&crypto.AEADAuthenticator{
				AEAD:                    &crypto.FnvAuthenticator{},
				NonceGenerator:          crypto.GenerateEmptyBytes(),
				AdditionalDataGenerator: crypto.GenerateEmptyBytes(),
			}, o.Client, parser, paddin)
			return nil
		}

		o.EncryptionWriter = o.Client
		return nil
	case 3: // AES-128-GCM
		aead, err := crypto.NewAESGCM(o.ResponseK[:])
		if err != nil {
			return fmt.Errorf("crypto.NewAESGCM: %v", err)
		}

		auth := &crypto.AEADAuthenticator{
			AEAD:                    aead,
			NonceGenerator:          crypto.GenerateChunkNonce(o.ResponseV[:], uint32(aead.NonceSize())),
			AdditionalDataGenerator: crypto.GenerateEmptyBytes(),
		}

		o.EncryptionWriter = crypto.NewAuthenticationWriter(auth, o.Client, parser, paddin)
		return nil
	case 4: // CHACHA20-POLY1305
		aead, err := chacha20poly1305.New(crypto.GenerateChacha20Secret(o.ResponseK[:]))
		if err != nil {
			return fmt.Errorf("chacha20poly1305.New: %v", err)
		}

		auth := &crypto.AEADAuthenticator{
			AEAD:                    aead,
			NonceGenerator:          crypto.GenerateChunkNonce(o.ResponseV[:], uint32(aead.NonceSize())),
			AdditionalDataGenerator: crypto.GenerateEmptyBytes(),
		}

		o.EncryptionWriter = crypto.NewAuthenticationWriter(auth, o.Client, parser, paddin)
		return nil
	}

	return fmt.Errorf("unsupported encryption method: %d", o.Header.Method)
}
