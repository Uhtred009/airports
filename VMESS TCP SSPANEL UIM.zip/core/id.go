package core

import (
	"bytes"
	"crypto/md5"

	"github.com/google/uuid"
)

type ID struct {
	Uuid uuid.UUID
	Hash [16]byte
}

func (o *ID) String() string {
	return o.Uuid.String()
}

func NewID(data uuid.UUID) *ID {
	h := md5.New()
	h.Write(data[:])
	h.Write([]byte("c48619fe-8f02-49e0-b9e9-edf763e17e21"))

	id := &ID{Uuid: data}
	h.Sum(id.Hash[:0])
	return id
}

func NextID(data uuid.UUID) uuid.UUID {
	h := md5.New()
	h.Write(data[:])
	h.Write([]byte("16167dc8-16b6-4e6d-b8bb-65dd68113a81"))

	var id uuid.UUID
	for {
		h.Sum(id[:0])
		if !bytes.Equal(id[:], data[:]) {
			return id
		}

		h.Write([]byte("533eff8a-4113-4b10-b5ce-0f5d76b98cd2"))
	}
}

func ComputeUserID(main uuid.UUID, length uint16) []*ID {
	last := main

	ids := make([]*ID, length)
	for idx := range ids {
		id := NextID(last)
		ids[idx] = NewID(id)
		last = id
	}

	return ids
}
