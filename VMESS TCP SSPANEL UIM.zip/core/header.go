package core

type RequestHeader struct {
	K [16]byte
	V [16]byte

	Header byte
	Option byte
	Length int
	Method int

	ChunkStream bool
	ReuseStream bool
	ChunkMaskin bool
	ChunkPaddin bool
	AutheLength bool

	Type byte
	Host string
	Port int
}
