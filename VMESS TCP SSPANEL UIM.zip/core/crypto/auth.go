package crypto

import (
	"crypto/cipher"
	"crypto/md5"
	"crypto/rand"
	"encoding/binary"
	"fmt"
	"hash/fnv"
	"io"
)

type BytesGenerator func() []byte

func GenerateEmptyBytes() BytesGenerator {
	var b [1]byte
	return func() []byte {
		return b[:0]
	}
}

func GenerateStaticBytes(content []byte) BytesGenerator {
	return func() []byte {
		return content
	}
}

func GenerateIncreasingNonce(nonce []byte) BytesGenerator {
	c := append([]byte(nil), nonce...)
	return func() []byte {
		for i := range c {
			c[i]++
			if c[i] != 0 {
				break
			}
		}
		return c
	}
}

func GenerateChunkNonce(nonce []byte, size uint32) BytesGenerator {
	c := append([]byte(nil), nonce...)
	count := uint16(0)
	return func() []byte {
		binary.BigEndian.PutUint16(c, count)
		count++
		return c[:size]
	}
}

func GenerateChacha20Secret(b []byte) []byte {
	key := make([]byte, 32)
	t := md5.Sum(b)
	copy(key, t[:])
	t = md5.Sum(key[:16])
	copy(key[16:], t[:])
	return key
}

func GenerateInitialAEADNonce() BytesGenerator {
	return GenerateIncreasingNonce([]byte{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF})
}

type Authenticator interface {
	NonceSize() int
	Overhead() int
	Open(dst, cipherText []byte) ([]byte, error)
	Seal(dst, plainText []byte) ([]byte, error)
}

type AEADAuthenticator struct {
	cipher.AEAD
	NonceGenerator          BytesGenerator
	AdditionalDataGenerator BytesGenerator
}

func (v *AEADAuthenticator) Open(dst, cipherText []byte) ([]byte, error) {
	iv := v.NonceGenerator()
	if len(iv) != v.AEAD.NonceSize() {
		return nil, fmt.Errorf("invalid AEAD nonce size: %d", len(iv))
	}

	var additionalData []byte
	if v.AdditionalDataGenerator != nil {
		additionalData = v.AdditionalDataGenerator()
	}
	return v.AEAD.Open(dst, iv, cipherText, additionalData)
}

func (v *AEADAuthenticator) Seal(dst, plainText []byte) ([]byte, error) {
	iv := v.NonceGenerator()
	if len(iv) != v.AEAD.NonceSize() {
		return nil, fmt.Errorf("invalid AEAD nonce size: %d", len(iv))
	}

	var additionalData []byte
	if v.AdditionalDataGenerator != nil {
		additionalData = v.AdditionalDataGenerator()
	}
	return v.AEAD.Seal(dst, iv, plainText, additionalData), nil
}

type AuthenticationReader struct {
	Auth   Authenticator
	Reader io.Reader
	Parser ChunkSizeDecoder
	Paddin LengthGenerator

	length [2]byte
	buffer []byte
	offset int
}

func NewAuthenticationReader(auth Authenticator, reader io.Reader, parser ChunkSizeDecoder, paddin LengthGenerator) *AuthenticationReader {
	return &AuthenticationReader{
		Auth:   auth,
		Reader: reader,
		Parser: parser,
		Paddin: paddin,
	}
}

func (o *AuthenticationReader) GetLength() (uint16, uint16, error) {
	if _, err := io.ReadFull(o.Reader, o.length[:]); err != nil {
		return 0, 0, fmt.Errorf("io.ReadFull: %v", err)
	}

	var paddin uint16
	if o.Paddin != nil {
		paddin = o.Paddin.NextLength()
	}

	return o.Parser.Decode(o.length[:]), paddin, nil
}

func (o *AuthenticationReader) Read(data []byte) (int, error) {
	if o.buffer != nil {
		size := copy(data, o.buffer[o.offset:])
		o.offset += size

		if len(o.buffer) == o.offset {
			o.buffer = nil
			o.offset = 0
		}

		return size, nil
	}

	length, paddin, err := o.GetLength()
	if err != nil {
		return 0, io.EOF
	}

	if length == uint16(o.Auth.Overhead())+paddin {
		return 0, io.EOF
	}

	buffer := make([]byte, length)
	if _, err := io.ReadFull(o.Reader, buffer[:length]); err != nil {
		return 0, io.EOF
	}
	length -= paddin

	decrypted, err := o.Auth.Open(nil, buffer[:length])
	if err != nil {
		return 0, io.EOF
	}

	size := copy(data, decrypted)
	if size < len(decrypted) {
		o.buffer = decrypted
		o.offset = size
	}
	return size, nil
}

type AuthenticationWriter struct {
	Auth   Authenticator
	Writer io.Writer
	Parser ChunkSizeEncoder
	Paddin LengthGenerator
}

func NewAuthenticationWriter(auth Authenticator, writer io.Writer, parser ChunkSizeEncoder, paddin LengthGenerator) *AuthenticationWriter {
	return &AuthenticationWriter{
		Auth:   auth,
		Writer: writer,
		Parser: parser,
		Paddin: paddin,
	}
}

func (o *AuthenticationWriter) Write(data []byte) (int, error) {
	if len(data) == 0 {
		encrypted, err := o.Auth.Seal(nil, []byte{})
		if err != nil {
			return 0, io.EOF
		}

		if _, err = o.Writer.Write(encrypted); err != nil {
			return 0, io.EOF
		}

		return 0, nil
	}

	length := len(data) + o.Auth.Overhead()

	paddin := 0
	if o.Paddin != nil {
		paddin = int(o.Paddin.NextLength())
	}

	buffer := make([]byte, int(o.Parser.Size())+length+paddin)
	binary.BigEndian.PutUint16(buffer, uint16(o.Parser.Encode(uint16(length+paddin))))

	if _, err := o.Auth.Seal(buffer[2:2], data); err != nil {
		return 0, io.EOF
	}

	if paddin > 0 {
		rand.Read(buffer[2+length:])
	}

	if _, err := o.Writer.Write(buffer); err != nil {
		return 0, io.EOF
	}

	return len(data), nil
}

type NoOpAuthenticator struct {
}

func (o *NoOpAuthenticator) NonceSize() int {
	return 0
}

func (o *NoOpAuthenticator) Overhead() int {
	return 0
}

func (o *NoOpAuthenticator) Seal(dst, nonce, plaintext, additionalData []byte) []byte {
	return append(dst[:0], plaintext...)
}

func (o *NoOpAuthenticator) Open(dst, nonce, ciphertext, additionalData []byte) ([]byte, error) {
	return append(dst[:0], ciphertext...), nil
}

type FnvAuthenticator struct {
}

func (o *FnvAuthenticator) Authenticate(b []byte) uint32 {
	fnv1hash := fnv.New32a()
	fnv1hash.Write(b)

	return fnv1hash.Sum32()
}

func (o *FnvAuthenticator) NonceSize() int {
	return 0
}

func (o *FnvAuthenticator) Overhead() int {
	return 4
}

func (o *FnvAuthenticator) Seal(dst, nonce, plaintext, additionalData []byte) []byte {
	dst = append(dst, 0, 0, 0, 0)
	binary.BigEndian.PutUint32(dst, o.Authenticate(plaintext))

	return append(dst, plaintext...)
}

func (o *FnvAuthenticator) Open(dst, nonce, ciphertext, additionalData []byte) ([]byte, error) {
	if binary.BigEndian.Uint32(ciphertext[:4]) != o.Authenticate(ciphertext[4:]) {
		return dst, fmt.Errorf("invalid authentication")
	}

	return append(dst, ciphertext[4:]...), nil
}
