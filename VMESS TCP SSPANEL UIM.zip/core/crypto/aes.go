package crypto

import (
	"crypto/aes"
	"crypto/cipher"
	"fmt"
)

func NewAESCFBEncryptionStream(k []byte, v []byte) (cipher.Stream, error) {
	b, err := aes.NewCipher(k)
	if err != nil {
		return nil, fmt.Errorf("aes.NewCipher: %v", err)
	}

	return cipher.NewCFBEncrypter(b, v), nil
}

func NewAESCFBDecryptionStream(k []byte, v []byte) (cipher.Stream, error) {
	b, err := aes.NewCipher(k)
	if err != nil {
		return nil, fmt.Errorf("aes.NewCipher: %v", err)
	}

	return cipher.NewCFBDecrypter(b, v), nil
}

func NewAESCTRStream(k []byte, v []byte) (cipher.Stream, error) {
	b, err := aes.NewCipher(k)
	if err != nil {
		return nil, fmt.Errorf("aes.NewCipher: %v", err)
	}

	return cipher.NewCTR(b, v), nil
}

func NewAESGCM(k []byte) (cipher.AEAD, error) {
	b, err := aes.NewCipher(k)
	if err != nil {
		return nil, fmt.Errorf("aes.NewCipher: %v", err)
	}

	a, err := cipher.NewGCM(b)
	if err != nil {
		return nil, fmt.Errorf("cipher.NewGCM: %v", err)
	}

	return a, nil
}
