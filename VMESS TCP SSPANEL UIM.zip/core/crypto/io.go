package crypto

import (
	"crypto/cipher"
	"fmt"
	"io"
)

type CryptionReader struct {
	Reader io.Reader
	Stream cipher.Stream
}

func NewCryptionReader(reader io.Reader, stream cipher.Stream) *CryptionReader {
	return &CryptionReader{
		Reader: reader,
		Stream: stream,
	}
}

func (o *CryptionReader) Read(data []byte) (int, error) {
	size, err := o.Reader.Read(data)
	if err != nil {
		return 0, fmt.Errorf("o.Reader.Read: %v", err)
	}

	if size > 0 {
		o.Stream.XORKeyStream(data[:size], data[:size])
	}

	return size, nil
}

type CryptionWriter struct {
	Writer io.Writer
	Stream cipher.Stream
}

func NewCryptionWriter(writer io.Writer, stream cipher.Stream) *CryptionWriter {
	return &CryptionWriter{
		Writer: writer,
		Stream: stream,
	}
}

func (o *CryptionWriter) Write(data []byte) (int, error) {
	o.Stream.XORKeyStream(data, data)

	size, err := o.Writer.Write(data)
	if err != nil {
		return 0, fmt.Errorf("o.Writer.Write: %v", err)
	}

	return size, nil
}
