package crypto

import (
	"encoding/binary"
	"fmt"
	"io"
)

type ChunkSizeEncoder interface {
	Size() int32
	Encode(uint16) uint16
}

type ChunkSizeDecoder interface {
	Size() int32
	Decode([]byte) uint16
}

type LengthGenerator interface {
	MaxLength() uint16
	NextLength() uint16
}

type ChunkStreamReader struct {
	io.Reader

	Decoder ChunkSizeDecoder

	length [2]byte
	buffer []byte
	offset int
}

func NewChunkStreamReader(reader io.Reader, decoder ChunkSizeDecoder) *ChunkStreamReader {
	return &ChunkStreamReader{
		Reader: reader,

		Decoder: decoder,
	}
}

func (o *ChunkStreamReader) Read(data []byte) (int, error) {
	if o.buffer != nil {
		length := copy(data, o.buffer[o.offset:])
		o.offset += length

		if len(o.buffer) == o.offset {
			o.buffer = nil
			o.offset = 0
		}

		return length, nil
	}

	if _, err := io.ReadFull(o.Reader, o.length[:]); err != nil {
		return 0, fmt.Errorf("io.ReadFull: %v", err)
	}

	buffer := make([]byte, o.Decoder.Decode(o.length[:]))
	if _, err := io.ReadFull(o.Reader, buffer); err != nil {
		return 0, fmt.Errorf("io.ReadFull: %v", err)
	}

	length := copy(data, buffer)
	if len(buffer) != length {
		o.buffer = buffer
		o.offset = length
	}
	return length, nil
}

type ChunkStreamWriter struct {
	io.Writer

	Encoder ChunkSizeEncoder
}

func NewChunkStreamWriter(writer io.Writer, encoder ChunkSizeEncoder) *ChunkStreamWriter {
	return &ChunkStreamWriter{
		Writer: writer,

		Encoder: encoder,
	}
}

func (o *ChunkStreamWriter) Write(data []byte) (int, error) {
	buffer := make([]byte, int(o.Encoder.Size())+len(data))
	binary.BigEndian.PutUint16(buffer, o.Encoder.Encode(uint16(len(data))))
	copy(buffer[o.Encoder.Size():], data)

	if _, err := o.Writer.Write(buffer); err != nil {
		return 0, fmt.Errorf("o.Writer.Write: %v", err)
	}

	return len(data), nil
}
