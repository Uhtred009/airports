package core

import (
	"testing"

	"github.com/google/uuid"
)

func TestHash(t *testing.T) {
	hash := ComputeUserHash(ComputeUserID(uuid.MustParse("80946db0-8642-4d25-a721-79b3b2cac94a"), 1)[0].Uuid, 1634829486)

	t.Logf("%x", hash[:])
}
