package core

import (
	"encoding/binary"

	"golang.org/x/crypto/sha3"
)

type RawSizeParser struct {
}

func (o *RawSizeParser) Size() int32 {
	return 2
}

func (o *RawSizeParser) Encode(size uint16) uint16 {
	return size
}

func (o *RawSizeParser) Decode(data []byte) uint16 {
	return binary.BigEndian.Uint16(data)
}

type ShakeSizeParser struct {
	Shake sha3.ShakeHash

	Buffer [2]byte
}

func NewShakeSizeParser(nonce []byte) *ShakeSizeParser {
	shake := sha3.NewShake128()
	shake.Write(nonce)

	return &ShakeSizeParser{Shake: shake}
}

func (o *ShakeSizeParser) Size() int32 {
	return 2
}

func (o *ShakeSizeParser) Next() uint16 {
	o.Shake.Read(o.Buffer[:])

	return binary.BigEndian.Uint16(o.Buffer[:])
}

func (o *ShakeSizeParser) Encode(size uint16) uint16 {
	return o.Next() ^ size
}

func (o *ShakeSizeParser) Decode(data []byte) uint16 {
	return o.Next() ^ binary.BigEndian.Uint16(data)
}

func (o *ShakeSizeParser) MaxLength() uint16 {
	return 64
}

func (o *ShakeSizeParser) NextLength() uint16 {
	return o.Next() % 64
}
