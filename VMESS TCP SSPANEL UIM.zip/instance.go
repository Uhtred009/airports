package main

import (
	"net"
	"sync"
	"time"

	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/api"
	"rixcloud.moe/v2ray/vmess-tcp-sspanel-uim/core"
)

var (
	instanceLock sync.RWMutex
	instanceList = make(map[int64]*Instance)

	instanceCacheLock sync.RWMutex
	instanceCacheList = make(map[string]*InstanceCache)
)

type InstanceCache struct {
	sync.Mutex

	Hit int64
	IDs []int64
}

func RunInstanceCache() {
	for {
		time.Sleep(time.Second * 10)

		date := time.Now().Unix()

		instanceCacheLock.Lock()
		for k, v := range instanceCacheList {
			if date-v.Hit >= 120 {
				delete(instanceCacheList, k)
			}
		}
		instanceCacheLock.Unlock()
	}
}

func NewInstanceCache(addr string, id int64) {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return
	}

	instanceCacheLock.Lock()
	defer instanceCacheLock.Unlock()

	data, ok := instanceCacheList[host]
	if !ok {
		instanceCacheList[host] = &InstanceCache{Hit: time.Now().Unix(), IDs: []int64{id}}
		return
	}

	data.Update(id)
}

func GetInstanceCache(addr string, hash [16]byte) (*Instance, int64) {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return GetInstance(hash)
	}

	instanceCacheLock.RLock()
	data, ok := instanceCacheList[host]
	instanceCacheLock.RUnlock()
	if !ok {
		instance, date := GetInstance(hash)
		if instance != nil {
			instanceCacheLock.Lock()
			instanceCacheList[host] = &InstanceCache{Hit: time.Now().Unix(), IDs: []int64{instance.UserInfo.ID}}
			instanceCacheLock.Unlock()
		}

		return instance, date
	}

	instanceLock.RLock()
	for i := 0; i < len(data.IDs); i++ {
		if instance, ok := instanceList[data.IDs[i]]; ok {
			if info, ok := instance.UserHash[hash]; ok {
				data.Update(-1)

				instanceLock.RUnlock()
				return instance, info
			}
		}
	}
	instanceLock.RUnlock()

	instance, date := GetInstance(hash)
	if instance != nil {
		instanceCacheLock.RLock()
		instanceCacheList[host].Update(instance.UserInfo.ID)
		instanceCacheLock.RUnlock()
	}

	return instance, date
}

func (o *InstanceCache) Update(id int64) {
	o.Lock()
	defer o.Unlock()

	o.Hit = time.Now().Unix()
	if id != -1 {
		o.IDs = append(o.IDs, id)
	}
}

type Instance struct {
	sync.RWMutex

	ID       *core.ID
	UserID   []*core.ID
	UserHash map[[16]byte]int64
	UserInfo *api.UserInfo

	Traffic *Traffic
	Updated int64
}

func NewInstance(info *api.UserInfo) *Instance {
	uuid, err := info.GetUUID()
	if err != nil {
		return nil
	}

	instance := &Instance{
		ID:       core.NewID(uuid),
		UserHash: make(map[[16]byte]int64),
		UserInfo: info,

		Traffic: NewTraffic(),
		Updated: 0,
	}
	instance.UserID = core.ComputeUserID(uuid, uint16(flags.ALTERID))

	instance.UpdateUserHash()
	return instance
}

func GetInstance(id [16]byte) (*Instance, int64) {
	instanceLock.RLock()
	defer instanceLock.RUnlock()

	for _, instance := range instanceList {
		if info, ok := instance.UserHash[id]; ok {
			return instance, info
		}
	}

	return nil, 0
}

func (o *Instance) UpdateUserHash() {
	o.Lock()
	defer o.Unlock()

	date := time.Now().Unix()
	last := date + 60

	if o.Updated == 0 {
		for i := date - 60; i < last; i++ {
			for _, v := range o.UserID {
				o.UserHash[core.ComputeUserHash(v.Uuid, i)] = i
			}
		}

		o.Updated = last
		return
	}

	if last-o.Updated <= 0 {
		return
	}

	for k, v := range o.UserHash {
		if date > v && date-v > 60 {
			delete(o.UserHash, k)
		}
	}

	diff := last - o.Updated
	for i := date; i < date+diff; i++ {
		for _, v := range o.UserID {
			o.UserHash[core.ComputeUserHash(v.Uuid, i)] = i
		}
	}

	o.Updated = last
}

type Traffic struct {
	sync.RWMutex

	UP int64
	DL int64
}

func NewTraffic() *Traffic {
	return &Traffic{
		UP: 0,
		DL: 0,
	}
}

func (o *Traffic) IncreaseUP(i int64) {
	o.Lock()
	defer o.Unlock()

	o.UP += i
}

func (o *Traffic) IncreaseDL(i int64) {
	o.Lock()
	defer o.Unlock()

	o.DL += i
}

func (o *Traffic) DecreaseUP(i int64) {
	o.Lock()
	defer o.Unlock()

	o.UP -= i
}

func (o *Traffic) DecreaseDL(i int64) {
	o.Lock()
	defer o.Unlock()

	o.DL -= i
}

func (o *Traffic) GetUP() int64 {
	o.RLock()
	defer o.RUnlock()

	return o.UP
}

func (o *Traffic) GetDL() int64 {
	o.RLock()
	defer o.RUnlock()

	return o.DL
}
