package tools

import (
	"os"
	"strconv"
)

func Atoi(data string, value int64) int64 {
	if v, err := strconv.ParseInt(data, 10, 64); err == nil {
		return v
	}

	return value
}

func Getenv(name string, value string) string {
	if v, ok := os.LookupEnv(name); ok {
		return v
	}

	return value
}
