package tools

import (
	"crypto/hmac"
	"crypto/md5"
	"hash"
	"log"
	"strconv"
)

func Atoi(s string) int {
	v, err := strconv.Atoi(s)
	if err != nil {
		log.Fatalf("[APP][tools.Atoi] %v", err)
	}

	return v
}

func Bool(s string) bool {
	v, err := strconv.ParseBool(s)
	if err != nil {
		log.Fatalf("[APP][tools.Bool] %v", err)
	}

	return v
}

func Float64(s string) float64 {
	v, err := strconv.ParseFloat(s, 10)
	if err != nil {
		log.Fatalf("[APP][tools.Float64] %v", err)
	}

	return v
}

func Sum(h func() hash.Hash, data []byte) []byte {
	m := h()
	_, _ = m.Write(data)

	return m.Sum(nil)
}

func HMAC(h func() hash.Hash, k []byte, data []byte) []byte {
	m := hmac.New(h, k)
	_, _ = m.Write(data)

	return m.Sum(nil)[:10]
}

func KDF(s string, length int) []byte {
	var a, b []byte
	h := md5.New()

	for len(a) < length {
		_, _ = h.Write(b)
		_, _ = h.Write([]byte(s))
		a = h.Sum(a)
		b = a[len(a)-h.Size():]
		h.Reset()
	}

	return a[:length]
}
