rm -Force go.*

go mod init
go mod tidy
exit 0