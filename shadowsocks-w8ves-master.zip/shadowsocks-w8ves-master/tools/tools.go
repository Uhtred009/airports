package tools

import (
	"log"
	"strconv"
)

func Atoi(s string) int {
	v, err := strconv.Atoi(s)
	if err != nil {
		log.Fatalf("[APP][tools.Atoi] %v", err)
	}

	return v
}

func Bool(s string) bool {
	v, err := strconv.ParseBool(s)
	if err != nil {
		log.Fatalf("[APP][tools.Bool] %v", err)
	}

	return v
}

func Float64(s string) float64 {
	v, err := strconv.ParseFloat(s, 10)
	if err != nil {
		log.Fatalf("[APP][tools.Float64] %v", err)
	}

	return v
}
