package obfs

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"hash/adler32"
	"hash/crc32"
	"io"
	"math/rand"
	"net"
	"time"

	"github.com/tebeka/strftime"
)

var (
	TCPBufferSize int

	Salt     = []byte("auth_sha1_v4")
	SaltLen  = len(Salt)
	HTTPCRLF = []byte{0x0d, 0x0a, 0x0d, 0x0a}

	ErrFormatDate = errors.New("Format Date")
)

type Auth struct {
	net.Conn

	Secret []byte

	backed        bool
	hasRecvHeader bool

	buffer []byte
	offset int
}

func (o *Auth) Read(data []byte) (int, error) {
	if o.buffer != nil {
		size := copy(data, o.buffer[o.offset:])
		o.offset += size

		if len(o.buffer) == o.offset {
			o.buffer = nil
		}

		return size, nil
	}

	if o.backed {
		return o.Conn.Read(data)
	}

	if !o.hasRecvHeader {
		o.hasRecvHeader = true

		buffer := make([]byte, TCPBufferSize)
		if _, err := io.ReadFull(o.Conn, buffer[:6]); err != nil {
			return 0, err
		}

		crc := make([]byte, 4)
		{
			crcbuffer := make([]byte, 2+SaltLen+len(o.Secret))
			copy(crcbuffer[:2], buffer[:2])
			copy(crcbuffer[2:], Salt)
			copy(crcbuffer[2+SaltLen:], o.Secret)

			binary.LittleEndian.PutUint32(crc, crc32.ChecksumIEEE(crcbuffer))
		}

		if !bytes.Equal(crc, buffer[2:6]) {
			o.backed = true

			length, err := o.Conn.Read(buffer[6:])
			if err != nil {
				return 0, err
			}
			length += 6

			size := copy(data, buffer[:length])
			if len(buffer) > size {
				o.buffer = buffer[:length]
				o.offset = size
			}

			return size, nil
		}

		length := int(binary.BigEndian.Uint16(buffer[:2]))
		if TCPBufferSize < length {
			buffer = make([]byte, length)
			binary.BigEndian.PutUint16(buffer, uint16(length))
			copy(buffer[2:], crc)
		}
		buffer = buffer[:length]

		if _, err := io.ReadFull(o.Conn, buffer[6:]); err != nil {
			return 0, err
		}

		offset := int(buffer[6])
		if offset < 0xff {
			offset += 6
		} else {
			offset = int(binary.BigEndian.Uint16(buffer[7:9])) + 6
		}

		if len(buffer[offset:length-10]) < 12 {
			o.backed = true

			size := copy(data, buffer)
			if len(buffer) > size {
				o.buffer = buffer
				o.offset = size
			}

			return size, nil
		}
		buffer = buffer[offset : length-10]
		buffer = buffer[12:]

		size := copy(data, buffer)
		if len(buffer) > size {
			o.buffer = buffer
			o.offset = size
		}

		return size, nil
	}

	var length uint16
	if err := binary.Read(o.Conn, binary.BigEndian, &length); err != nil {
		return 0, err
	}

	buffer := make([]byte, length)
	if _, err := io.ReadFull(o.Conn, buffer[2:]); err != nil {
		return 0, err
	}
	binary.BigEndian.PutUint16(buffer, length)

	offset := int(buffer[4])
	if offset < 0xff {
		offset += 4
	} else {
		offset = int(binary.BigEndian.Uint16(buffer[5:7])) + 4
	}
	buffer = buffer[offset : length-4]

	size := copy(data, buffer)
	if len(buffer) > size {
		o.buffer = buffer
		o.offset = size
	}

	return size, nil
}

func (o *Auth) Write(data []byte) (int, error) {
	if o.backed {
		return o.Conn.Write(data)
	}

	random := rand.Intn(10) + 1
	length := 2 + 2 + random + len(data) + 4

	buffer := make([]byte, length)
	binary.BigEndian.PutUint16(buffer, uint16(length))
	binary.LittleEndian.PutUint16(buffer[2:4], uint16(crc32.ChecksumIEEE(buffer[:2])&0xffff))
	_, _ = rand.Read(buffer[4 : 4+random])
	buffer[4] = byte(random)
	copy(buffer[4+random:], data)
	binary.LittleEndian.PutUint32(buffer[length-4:], adler32.Checksum(buffer[:length-4]))

	if _, err := o.Conn.Write(buffer); err != nil {
		return 0, err
	}

	return len(data), nil
}

func NewAuth(client net.Conn, secret []byte) net.Conn {
	return &Auth{Conn: client, Secret: secret}
}

type HTTP struct {
	net.Conn

	hasSentHeader bool
	hasRecvHeader bool

	buffer []byte
	offset int
}

func (o *HTTP) Read(data []byte) (int, error) {
	if o.buffer != nil {
		size := copy(data, o.buffer[o.offset:])
		o.offset += size

		if len(o.buffer) == o.offset {
			o.buffer = nil
			o.offset = 0
		}

		return size, nil
	}

	if !o.hasRecvHeader {
		buffer := make([]byte, TCPBufferSize)
		length, err := o.Conn.Read(buffer)
		if err != nil {
			return 0, err
		}

		if !bytes.Contains(buffer[:length], HTTPCRLF) {
			size := copy(data, buffer[:length])
			if length > size {
				o.buffer = buffer[:length]
				o.offset = size
			}

			o.hasRecvHeader = true
			o.hasSentHeader = true
			return size, nil
		}
		o.hasRecvHeader = true

		SPL := bytes.SplitN(buffer[:length], HTTPCRLF, 2)
		HDR := SplitHeader(SPL[0])

		if CheckHeader(HDR, "REQUEST") {
			header, err := GetHTTP(HDR["REQUEST"])
			if err != nil {
				return 0, err
			}

			SPL[1] = append(header, SPL[1]...)
		}

		if len(SPL[1]) == 0 {
			if _, err = o.Write(nil); err != nil {
				return 0, err
			}

			length, err = o.Conn.Read(buffer)
			if err != nil {
				return 0, err
			}

			size := copy(data, buffer[:length])
			if length > size {
				o.buffer = buffer[:length]
				o.offset = size
			}

			return size, nil
		}

		size := copy(data, SPL[1])
		if len(SPL[1]) > size {
			o.buffer = SPL[1]
			o.offset = size
		}

		return size, nil
	}

	return o.Conn.Read(data)
}

func (o *HTTP) Write(data []byte) (int, error) {
	if !o.hasSentHeader {
		o.hasSentHeader = true

		date, err := strftime.Format("%a, %d %b %Y %H:%M:%S GMT", time.Now())
		if err != nil {
			return 0, ErrFormatDate
		}

		buffer := []byte(fmt.Sprintf(""+
			"HTTP/1.1 200 OK\r\n"+
			"Connection: keep-alive\r\n"+
			"Content-Encoding: gzip\r\n"+
			"Content-Type: text/html\r\n"+
			"Date: %s\r\n"+
			"Server: nginx\r\n"+
			"Vary: Accept-Encoding\r\n"+
			"\r\n", date))

		if _, err = o.Conn.Write(append(buffer, data...)); err != nil {
			return 0, err
		}

		return len(data), nil
	}

	return o.Conn.Write(data)
}

func NewHTTP(client net.Conn) net.Conn {
	return &HTTP{Conn: client}
}
