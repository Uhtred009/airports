package obfs

import (
	"bytes"
	"encoding/hex"
	"strings"
)

func SplitHeader(data []byte) map[string]string {
	SPLB := bytes.Split(data, []byte{0x0d, 0x0a})
	list := make(map[string]string)

	for i, v := range SPLB {
		text := string(v)

		if i == 0 {
			list["REQUEST"] = text
			continue
		}

		if strings.Contains(text, ":") {
			SPL := strings.SplitN(text, ":", 2)

			name := strings.ToUpper(strings.TrimSpace(SPL[0]))
			content := strings.TrimSpace(SPL[1])

			list[name] = content
		}
	}

	return list
}

func CheckHeader(list map[string]string, name string) bool {
	_, ok := list[name]

	return ok
}

func GetHeader(list map[string]string, name string) string {
	if CheckHeader(list, name) {
		return list[name]
	}

	return ""
}

func GetHTTP(origin string) ([]byte, error) {
	SPL := strings.Split(origin, "%")[1:]
	HEX := ""

	for _, value := range SPL {
		if len(value) == 2 {
			HEX += value
		} else if len(value) > 2 {
			HEX += value[:2]
		}
	}

	return hex.DecodeString(HEX)
}
