package main

import "sync"

type Bandwidth struct {
	sync.RWMutex

	UP int64
	DL int64
}

func (bw *Bandwidth) IncreaseUP(size int64) {
	bw.Lock()
	defer bw.Unlock()

	bw.UP += size
}

func (bw *Bandwidth) IncreaseDL(size int64) {
	bw.Lock()
	defer bw.Unlock()

	bw.DL += size
}

func (bw *Bandwidth) DecreaseUP(size int64) {
	bw.Lock()
	defer bw.Unlock()

	if bw.UP < size {
		bw.UP = 0
	} else {
		bw.UP -= size
	}
}

func (bw *Bandwidth) DecreaseDL(size int64) {
	bw.Lock()
	defer bw.Unlock()

	if bw.DL < size {
		bw.DL = 0
	} else {
		bw.DL -= size
	}
}

func (bw *Bandwidth) GetUP() int64 {
	bw.RLock()
	defer bw.RUnlock()

	return bw.UP
}

func (bw *Bandwidth) GetDL() int64 {
	bw.RLock()
	defer bw.RUnlock()

	return bw.DL
}

func (bw *Bandwidth) Reset() {
	bw.Lock()
	defer bw.Unlock()

	bw.UP = 0
	bw.DL = 0
}

func newBandwidth() *Bandwidth {
	bw := new(Bandwidth)

	return bw
}
