package main

import (
	"log"
	"net"

	"github.com/juju/ratelimit"
	"rixcloud.moe/shadowsocks/shadowsocks/core"

	api "rixcloud.moe/shadowsocks/ls-api"
)

type Instance struct {
	Started    bool
	TCPStarted bool
	UDPStarted bool

	TCPSocket net.Listener
	UDPSocket net.PacketConn

	UserInfo  api.UserInfo
	Bandwidth *Bandwidth
	UPBucket  *ratelimit.Bucket
	DLBucket  *ratelimit.Bucket

	Cipher core.Cipher
}

func (i *Instance) Create() {
	if !i.Started {
		i.Started = true

		if i.Cipher == nil {
			cipher, err := core.PickCipher(i.UserInfo.Method, nil, i.UserInfo.Passwd)
			if err != nil {
				log.Printf("[APP][i.Create][%d] %v", i.UserInfo.ID, err)
				return
			}

			i.Cipher = cipher
		}
	}

	if flags.TCP && !i.TCPStarted {
		go i.tcpListen()
	}

	if flags.UDP && !i.UDPStarted {
		go i.udpListen()
	}
}

func (i *Instance) Delete() {
	if i.Started {
		i.Started = false

		if flags.TCP && i.TCPSocket != nil {
			i.TCPSocket.Close()
			i.TCPSocket = nil
		}

		if flags.UDP && i.UDPSocket != nil {
			i.UDPSocket.Close()
			i.UDPSocket = nil
		}
	}
}

func newInstance(data api.UserInfo) *Instance {
	var aBucket *ratelimit.Bucket
	if flags.ForceUPSpeedLimit > 0 {
		aBucket = ratelimit.NewBucketWithRate(1024*128*float64(flags.ForceUPSpeedLimit), 1024*128*int64(flags.ForceUPSpeedLimit))
	}

	instance := new(Instance)
	instance.Started = false
	instance.TCPStarted = false
	instance.UDPStarted = false
	instance.UserInfo = data
	instance.Bandwidth = newBandwidth()
	instance.UPBucket = aBucket
	instance.DLBucket = nil
	return instance
}
