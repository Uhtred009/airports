package main

import (
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"os"
	"runtime"
	"strings"
	"sync"
	"time"

	"rixcloud.moe/shadowsocks/shadowsocks-w8ves/obfs"

	"github.com/joho/godotenv"
	"rixcloud.moe/authorize/client"
	"rixcloud.moe/shadowsocks/shadowsocks-w8ves/adns"
	"rixcloud.moe/shadowsocks/shadowsocks-w8ves/structs"
	"rixcloud.moe/shadowsocks/shadowsocks-w8ves/tools"

	api "rixcloud.moe/shadowsocks/ls-api"
)

var (
	flags struct {
		Path    string
		VerCode bool

		SyncInterval      int
		Bind              string
		Dial              string
		SISO              bool
		DNS               string
		TTL               int64
		DNSHijack         bool
		TCP               bool
		UDP               bool
		UDPTimeout        int
		TCPBufferSize     int
		UDPBufferSize     int
		UPExternalRate    float64
		DLExternalRate    float64
		ForceUPSpeedLimit int
		EnableTrueIP      bool

		DNSAddr string
		DNSPort int
	}

	instanceList  = make(map[int]*Instance)
	instanceMutex sync.RWMutex
)

func main() {
	flag.StringVar(&flags.Path, "c", "", "Path")
	flag.BoolVar(&flags.VerCode, "v", false, "VerCode")
	flag.Parse()

	if flags.VerCode {
		fmt.Println(structs.Default.Version)
		return
	}

	if err := nero(); err != nil {
		log.Fatalf("[APP][nero] %v", err)
	}

	for {
		log.Println("[APP][main] Execute UpdateUserBandwidth")
		err := UpdateUserBandwidth()
		if err != nil {
			log.Printf("[APP][UpdateUserBandwidth] %v", err)

			time.Sleep(time.Second * 10)
			continue
		}

		log.Println("[APP][main] Execute SyncUserList")
		err = SyncUserList()
		if err != nil {
			log.Printf("[APP][SyncUserList] %v", err)

			time.Sleep(time.Second * 10)
			continue
		}

		time.Sleep(time.Second * time.Duration(flags.SyncInterval))
	}
}

func nero() error {
	err := godotenv.Load(flags.Path)
	if err != nil {
		return err
	}

	api.DBHost = os.Getenv("DBHOST")
	api.DBPort = tools.Atoi(os.Getenv("DBPORT"))
	api.DBUser = os.Getenv("DBUSER")
	api.DBPass = os.Getenv("DBPASS")
	api.DBName = os.Getenv("DBNAME")
	api.APIOut = time.Second * time.Duration(tools.Atoi(os.Getenv("DBTIMEOUT")))

	flags.SyncInterval = tools.Atoi(os.Getenv("SYNCINTERVAL"))
	flags.Bind = os.Getenv("BIND")
	flags.Dial = os.Getenv("DIAL")
	flags.SISO = tools.Bool(os.Getenv("SISO"))
	flags.DNS = os.Getenv("DNS")
	flags.TTL = int64(tools.Atoi(os.Getenv("DNSCACHE")))
	flags.DNSHijack = tools.Bool(os.Getenv("DNSHIJACK"))
	flags.TCP = tools.Bool(os.Getenv("TCP"))
	flags.UDP = tools.Bool(os.Getenv("UDP"))
	flags.UDPTimeout = tools.Atoi(os.Getenv("UDPTIMEOUT"))
	flags.TCPBufferSize = tools.Atoi(os.Getenv("TCPBUFFERSIZE"))
	flags.UDPBufferSize = tools.Atoi(os.Getenv("UDPBUFFERSIZE"))
	flags.UPExternalRate = tools.Float64(os.Getenv("UPEXTERNALRATE"))
	flags.DLExternalRate = tools.Float64(os.Getenv("DLEXTERNALRATE"))
	flags.ForceUPSpeedLimit = tools.Atoi(os.Getenv("FORCEUPSPEEDLIMIT"))
	flags.EnableTrueIP = tools.Bool(os.Getenv("ENABLETRUEIP"))
	obfs.TCPBufferSize = flags.TCPBufferSize

	dnsAddr, dnsPort, err := net.SplitHostPort(flags.DNS)
	if err != nil {
		return err
	}
	flags.DNSAddr = dnsAddr
	flags.DNSPort = tools.Atoi(dnsPort)
	adns.DNS = flags.DNS
	adns.TTL = flags.TTL
	adns.Run()

	cron()
	return nil
}

func UpdateUserBandwidth() error {
	list := make(api.UserBandwidthList, 0)

	instanceMutex.Lock()
	for _, instance := range instanceList {
		if instance.Bandwidth.GetUP() > 0 || instance.Bandwidth.GetDL() > 0 {
			list = append(list, api.UserBandwidth{
				ID: instance.UserInfo.ID,
				UP: instance.Bandwidth.GetUP(),
				DL: instance.Bandwidth.GetDL(),
			})
		}
	}
	instanceMutex.Unlock()

	err := api.Update(list)
	if err != nil {
		return err
	}

	instanceMutex.Lock()
	for i := 0; i < len(list); i++ {
		instanceList[list[i].ID].Bandwidth.DecreaseUP(list[i].UP)
		instanceList[list[i].ID].Bandwidth.DecreaseDL(list[i].DL)
	}
	instanceMutex.Unlock()

	return nil
}

func SyncUserList() error {
	list, err := api.GetUserList()
	if err != nil {
		return err
	}

	instanceMutex.Lock()
	defer instanceMutex.Unlock()

	for id, instance := range instanceList {
		checked := false

		for i := 0; i < len(list); i++ {
			if list[i].ID == instance.UserInfo.ID {
				if instance.UserInfo.Port != list[i].Port || instance.UserInfo.Passwd != list[i].Passwd || instance.UserInfo.Method != list[i].Method {
					break
				}

				checked = true
				break
			}
		}

		if !checked {
			instance.Delete()
			instance = nil
			delete(instanceList, id)

			continue
		}
	}

	for i := 0; i < len(list); i++ {
		if _, ok := instanceList[list[i].ID]; !ok {
			instanceList[list[i].ID] = newInstance(list[i])
			instanceList[list[i].ID].Create()
		}
	}

	return nil
}

func cron() {
	go authorize()
	go clean()
}

func authorize() {
	secret := ""
	{
		data, err := ioutil.ReadFile("/etc/shadowsocks/authorize")
		if err == nil {
			secret = strings.TrimSpace(string(data))
		}
	}

	client.Upstream = []string{
		"wss://api.sbxxd.com:443/authorize",
		"wss://us-api.sbxxd.com:443/authorize",
		"wss://ru-api.sbxxd.com:443/authorize",
		"wss://jp-api.sbxxd.com:443/authorize",
		"wss://hk-api.sbxxd.com:443/authorize",
	}
	client.Remark = "shadowsocks-w8ves"
	client.Secret = secret
	client.Version = structs.Default.Version

	code, once, err := client.Do()
	if err != nil {
		log.Fatalf("[API] %v", err)
		return
	}

	if !code {
		log.Fatal("[API] FAIL")
	}

	if !once {
		go client.Run()
	}

	log.Println("[API] DONE")
}

func clean() {
	stats := new(runtime.MemStats)

	for {
		time.Sleep(time.Minute * 10)

		runtime.GC()
		runtime.ReadMemStats(stats)
		log.Printf("[GC] Fraction %f", stats.GCCPUFraction)
		log.Printf("[GC] Obtained %dMB", stats.Sys/1024/1024)
		log.Printf("[GC] Assigned %dMB", stats.Alloc/1024/1024)
		log.Printf("[GC] Routine %d", runtime.NumGoroutine())
	}
}
