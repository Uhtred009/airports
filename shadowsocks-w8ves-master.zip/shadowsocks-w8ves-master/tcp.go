package main

import (
	"io"
	"log"
	"net"
	"strconv"
	"time"

	"github.com/juju/ratelimit"
	"rixcloud.moe/shadowsocks/shadowsocks-w8ves/adns"
	"rixcloud.moe/shadowsocks/shadowsocks-w8ves/obfs"
	"rixcloud.moe/shadowsocks/shadowsocks/core"
	"rixcloud.moe/shadowsocks/shadowsocks/socks"
)

func (i *Instance) tcpListen() {
	ln, err := net.Listen("tcp", net.JoinHostPort(flags.Bind, strconv.Itoa(int(i.UserInfo.Port))))
	if err != nil {
		log.Printf("[TCP][net.Listen][%d][%d] %v", i.UserInfo.ID, i.UserInfo.Port, err)
		return
	}
	defer func() {
		if ln != nil {
			ln.Close()
			ln = nil
		}

		i.TCPStarted = false
	}()

	i.TCPSocket = ln
	i.TCPStarted = true

	for i.Started {
		client, err := ln.Accept()
		if err != nil {
			log.Printf("[TCP][ln.Accept][%d][%d] %v", i.UserInfo.ID, i.UserInfo.Port, err)
			return
		}

		go i.tcpHandle(client)
	}
}

func (i *Instance) tcpHandle(client net.Conn) {
	from := ""
	if flags.EnableTrueIP {
		trueip, err := socks.ReadAddr(client)
		if err != nil {
			client.Close()
			return
		}

		from = trueip.String()
	} else {
		from = client.RemoteAddr().String()
	}

	client = obfs.NewHTTP(client)
	client = i.Cipher.StreamConn(client)
	client = obfs.NewAuth(client, i.Cipher.(*core.StreamCipher).Secret)
	defer client.Close()

	data := make([]byte, flags.TCPBufferSize)
	size, err := client.Read(data)
	if err != nil {
		return
	}

	target := socks.SplitAddr(data[:size])
	if target == nil {
		return
	}
	targetHost, targetPort := dnsHijack(target)

	adtr, err := adns.FetchOne(targetHost)
	if err != nil {
		return
	}

	dialer := net.Dialer{Timeout: time.Second * 10}
	if adtr.To4() != nil {
		if flags.Dial != "" {
			dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(flags.Dial)}
		} else if flags.SISO {
			addr, _, _ := net.SplitHostPort(client.LocalAddr().String())
			dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(addr)}
		}
	}

	remote, err := dialer.Dial("tcp", net.JoinHostPort(adtr.String(), strconv.Itoa(targetPort)))
	if err != nil {
		return
	}
	defer remote.Close()

	if _, err = remote.Write(data[len(target):size]); err != nil {
		return
	}
	data = nil

	log.Printf("[IN][%d][%d] New TCP connection from %s → %s:%d", i.UserInfo.ID, i.UserInfo.Port, from, targetHost, targetPort)
	tcpCopy(i, client, remote)
}

func tcpCopy(instance *Instance, client, remote net.Conn) {
	go func() {
		var reader io.Reader
		if instance.UPBucket != nil {
			reader = ratelimit.Reader(client, instance.UPBucket)
		} else {
			reader = client
		}

		size, _ := io.CopyBuffer(remote, reader, make([]byte, flags.TCPBufferSize))
		_ = client.SetDeadline(time.Now())
		_ = remote.SetDeadline(time.Now())
		instance.Bandwidth.IncreaseUP(int64(float64(size) * flags.UPExternalRate))
	}()

	var reader io.Reader
	if instance.DLBucket != nil {
		reader = ratelimit.Reader(remote, instance.DLBucket)
	} else {
		reader = remote
	}

	size, _ := io.CopyBuffer(client, reader, make([]byte, flags.TCPBufferSize))
	_ = client.SetDeadline(time.Now())
	_ = remote.SetDeadline(time.Now())
	instance.Bandwidth.IncreaseDL(int64(float64(size) * flags.DLExternalRate))
}
