package main

import (
	"log"
	"net"
	"strconv"
	"sync"
	"time"

	"rixcloud.moe/shadowsocks/shadowsocks-w8ves/adns"
	"rixcloud.moe/shadowsocks/shadowsocks/socks"
)

func (i *Instance) udpListen() {
	ln, err := net.ListenPacket("udp", net.JoinHostPort(flags.Bind, strconv.Itoa(int(i.UserInfo.Port))))
	if err != nil {
		log.Printf("[UDP][net.ListenPacket][%d][%d] %v", i.UserInfo.ID, i.UserInfo.Port, err)
		return
	}
	ln = i.Cipher.PacketConn(ln)
	defer func() {
		if ln != nil {
			ln.Close()
			ln = nil
		}

		i.UDPStarted = false
	}()

	nm := newNAT(time.Second * time.Duration(flags.UDPTimeout))
	buffer := make([]byte, flags.UDPBufferSize)

	i.UDPSocket = ln
	i.UDPStarted = true

	for i.Started {
		size, from, err := ln.ReadFrom(buffer)
		if err != nil {
			log.Printf("[UDP][ln.ReadFrom][%d][%d] %v", i.UserInfo.ID, i.UserInfo.Port, err)
			return
		}

		target := socks.SplitAddr(buffer[:size])
		if target == nil {
			continue
		}

		targetHost, targetPort, err := net.SplitHostPort(target.String())
		if err != nil {
			continue
		}

		targetAdtr, err := adns.FetchOne(targetHost)
		if err != nil {
			continue
		}

		targetAddr, err := net.ResolveUDPAddr("udp", net.JoinHostPort(targetAdtr.String(), targetPort))
		if err != nil {
			continue
		}

		conn := nm.Get(from.String())
		if conn == nil {
			addr := ""
			if flags.Dial != "" && targetAddr.IP.To4() != nil {
				addr = flags.Dial
			}

			conn, err = net.ListenPacket("udp", net.JoinHostPort(addr, ""))
			if err != nil {
				continue
			}

			nm.Create(i, conn, ln, from)
			log.Printf("[IN][%d][%d] New UDP connection from %s → %s", i.UserInfo.ID, i.UserInfo.Port, from, target.String())
		}

		if i.UPBucket != nil {
			i.UPBucket.Wait(int64(size))
		}
		i.Bandwidth.IncreaseUP(int64(float64(size) * flags.UPExternalRate))

		_, _ = conn.WriteTo(buffer[len(target):size], targetAddr)
	}
}

func udpCopy(instance *Instance, src, dst net.PacketConn, target net.Addr, timeout time.Duration) {
	buffer := make([]byte, flags.UDPBufferSize)

	for {
		_ = src.SetReadDeadline(time.Now().Add(timeout))
		size, from, err := src.ReadFrom(buffer)
		if err != nil {
			return
		}

		source := socks.ParseAddr(from.String())
		length := len(source) + size
		if length > flags.UDPBufferSize {
			continue
		}

		copy(buffer[len(source):], buffer[:size])
		copy(buffer, source)

		if instance.DLBucket != nil {
			instance.DLBucket.Wait(int64(size))
		}
		instance.Bandwidth.IncreaseDL(int64(float64(size) * flags.DLExternalRate))

		if _, err = dst.WriteTo(buffer[:length], target); err != nil {
			return
		}
	}
}

type NAT struct {
	sync.RWMutex
	m map[string]net.PacketConn
	t time.Duration
}

func (n *NAT) Get(id string) net.PacketConn {
	n.RLock()
	defer n.RUnlock()

	return n.m[id]
}

func (n *NAT) Set(id string, conn net.PacketConn) {
	n.Lock()
	defer n.Unlock()

	n.m[id] = conn
}

func (n *NAT) Create(instance *Instance, src, dst net.PacketConn, target net.Addr) {
	n.Set(target.String(), src)

	go func() {
		udpCopy(instance, src, dst, target, n.t)
		if conn := n.Delete(target.String()); conn != nil {
			conn.Close()
		}
	}()
}

func (n *NAT) Delete(id string) net.PacketConn {
	n.Lock()
	defer n.Unlock()

	conn, ok := n.m[id]
	if ok {
		delete(n.m, id)

		return conn
	}

	return nil
}

func newNAT(timeout time.Duration) *NAT {
	n := NAT{}
	n.m = make(map[string]net.PacketConn)
	n.t = timeout

	return &n
}
