package api

type NodeInfo struct {
	ID      int64
	GroupID int64
}

type UserInfo struct {
	ID     int64
	Port   int
	Method string
	Passwd string
}
type UserList []*UserInfo

func (o *UserInfo) Equals(info *UserInfo) bool {
	if o.Port != info.Port {
		return false
	}

	if o.Method != info.Method {
		return false
	}

	if o.Passwd != info.Passwd {
		return false
	}

	return true
}

type UserBandwidth struct {
	ID int64
	UP int64
	DL int64
}
type UserBandwidthList []*UserBandwidth
