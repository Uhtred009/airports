package main

import (
	"bytes"
	"encoding/hex"
	"fmt"
	"io"
	"net"
	"strings"
	"time"

	"github.com/lestrrat-go/strftime"
)

const (
	shadowsocksResponseHeader = "" +
		"HTTP/1.1 101 Switching Protocols\r\n" +
		"Server: nginx/1.20.1\r\n" +
		"Date: %s\r\n" +
		"Upgrade: websocket\r\n" +
		"Connection: Upgrade\r\n" +
		"Sec-WebSocket-Accept: %s\r\n" +
		"\r\n"

	shadowsocksrResponseHeader = "" +
		"HTTP/1.1 200 OK\r\n" +
		"Connection: keep-alive\r\n" +
		"Content-Encoding: gzip\r\n" +
		"Content-Type: text/html\r\n" +
		"Date: %s\r\n" +
		"Server: nginx\r\n" +
		"Vary: Accept-Encoding\r\n" +
		"\r\n"
)

type OBFS struct {
	net.Conn

	hasRecvHeader bool
	hasSentHeader bool
	isShadowsocks bool

	secret string

	buffer []byte
	offset int
}

func NewOBFS(client net.Conn) net.Conn {
	return &OBFS{Conn: client}
}

func (o *OBFS) Read(data []byte) (int, error) {
	if o.buffer != nil {
		size := copy(data, o.buffer[o.offset:])
		o.offset += size

		if len(o.buffer) == o.offset {
			o.buffer = nil
			o.offset = 0
		}

		return size, nil
	}

	if !o.hasRecvHeader {
		buffer := make([]byte, flags.TCPBUFFERSIZE)
		length, err := o.Conn.Read(buffer)
		if err != nil {
			return 0, err
		}

		if !bytes.Contains(buffer[:length], []byte{0x0d, 0x0a, 0x0d, 0x0a}) {
			o.hasRecvHeader = true
			o.hasSentHeader = true

			size := copy(data, buffer[:length])
			if length > size {
				o.buffer = buffer[:length]
				o.offset = size
			}
			return size, nil
		}

		o.hasRecvHeader = true

		listhd := bytes.SplitN(buffer[:length], []byte{0x0d, 0x0a, 0x0d, 0x0a}, 2)
		header := o.SplitHeader(listhd[0])

		o.isShadowsocks = o.IsShadowsocks(header)
		if !o.isShadowsocks {
			chunk, err := o.GetShadowsocksR(header["REQUEST"])
			if err != nil {
				return 0, io.EOF
			}

			listhd[1] = append(chunk, listhd[1]...)
		}

		if len(listhd[1]) == 0 {
			if _, err := o.Write(nil); err != nil {
				return 0, err
			}

			length, err := o.Conn.Read(buffer)
			if err != nil {
				return 0, err
			}

			size := copy(data, buffer[:length])
			if length > size {
				o.buffer = buffer[:length]
				o.offset = size
			}
			return size, nil
		}

		size := copy(data, listhd[1])
		if len(listhd[1]) > size {
			o.buffer = listhd[1]
			o.offset = size
		}
		return size, nil
	}

	return o.Conn.Read(data)
}

func (o *OBFS) Write(data []byte) (int, error) {
	if !o.hasSentHeader {
		o.hasSentHeader = true

		date, _ := strftime.Format("%a, %d %b %Y %H:%M:%S GMT", time.Now())

		length := 0
		if o.isShadowsocks {
			length = len(shadowsocksResponseHeader) - 4 + len(date) + len(o.secret) + len(data)
		} else {
			length = len(shadowsocksrResponseHeader) - 2 + len(date) + len(data)
		}
		buffer := make([]byte, length)

		copied := 0
		if o.isShadowsocks {
			copied = copy(buffer, []byte(fmt.Sprintf(shadowsocksResponseHeader, date, o.secret)))
		} else {
			copied = copy(buffer, []byte(fmt.Sprintf(shadowsocksrResponseHeader, date)))
		}
		copy(buffer[copied:], data)

		if _, err := o.Conn.Write(buffer); err != nil {
			return 0, err
		}
		return len(data), nil
	}

	return o.Conn.Write(data)
}

func (o *OBFS) GetHeader(list map[string]string, name string) string {
	if !o.CheckHeader(list, name) {
		return ""
	}

	return list[name]
}

func (o *OBFS) CheckHeader(list map[string]string, name string) bool {
	_, ok := list[name]

	return ok
}

func (o *OBFS) SplitHeader(data []byte) map[string]string {
	splited := bytes.Split(data, []byte{0x0d, 0x0a})

	list := make(map[string]string)
	for i := 0; i < len(splited); i++ {
		text := strings.TrimSpace(string(splited[i]))

		if i == 0 {
			list["REQUEST"] = text
		}

		if strings.Contains(text, ":") {
			SPL := strings.SplitN(text, ":", 2)
			if len(SPL) != 2 {
				continue
			}

			list[strings.ToUpper(strings.TrimSpace(SPL[0]))] = strings.TrimSpace(SPL[1])
		}
	}

	return list
}

func (o *OBFS) GetShadowsocksR(origin string) ([]byte, error) {
	splited := strings.Split(origin, "%")[1:]
	data := ""

	for _, value := range splited {
		if len(value) == 2 {
			data += value
		} else if len(value) > 2 {
			data += value[:2]
		}
	}

	return hex.DecodeString(data)
}

func (o *OBFS) IsShadowsocks(list map[string]string) bool {
	if o.CheckHeader(list, "UPGRADE") && o.CheckHeader(list, "CONNECTION") && o.CheckHeader(list, "SEC-WEBSOCKET-KEY") && strings.Contains(o.GetHeader(list, "USER-AGENT"), "curl") {
		o.secret = o.GetHeader(list, "SEC-WEBSOCKET-KEY")
		return true
	}

	return false
}
