package main

import "sync"

type Bandwidth struct {
	sync.RWMutex

	UP int64
	DL int64
}

func NewBandwidth() *Bandwidth {
	return &Bandwidth{
		UP: 0,
		DL: 0,
	}
}

func (o *Bandwidth) IncreaseUP(i int64) {
	o.Lock()
	defer o.Unlock()

	o.UP += i
}

func (o *Bandwidth) IncreaseDL(i int64) {
	o.Lock()
	defer o.Unlock()

	o.DL += i
}

func (o *Bandwidth) DecreaseUP(i int64) {
	o.Lock()
	defer o.Unlock()

	if o.UP > i {
		o.UP -= i
	} else {
		o.UP = 0
	}
}

func (o *Bandwidth) DecreaseDL(i int64) {
	o.Lock()
	defer o.Unlock()

	if o.DL > i {
		o.DL -= i
	} else {
		o.DL = 0
	}
}

func (o *Bandwidth) GetUP() int64 {
	o.RLock()
	defer o.RUnlock()

	return o.UP
}

func (o *Bandwidth) GetDL() int64 {
	o.RLock()
	defer o.RUnlock()

	return o.DL
}
