package main

import (
	"fmt"
	"log"
	"math/rand"
	"os"
	"runtime"
	"time"

	"rixcloud.moe/shadowsocks/shadowsocks-ssrcloud/api"
	"rixcloud.moe/shadowsocks/shadowsocks-ssrcloud/dns"
	"rixcloud.moe/shadowsocks/shadowsocks-ssrcloud/tools"

	"net/http"
	_ "net/http/pprof"
)

var (
	flags struct {
		NODEID  int64
		DBTYPE  string
		DBSPEC  string
		GROUPED bool

		SYNCINTERVAL time.Duration

		LISN string
		DIAL string
		SISO bool

		DNS    string
		DNSTTL int64

		TCP           bool
		TCPBUFFERSIZE int

		UDP           bool
		UDPTIMEOUT    time.Duration
		UDPBUFFERSIZE int

		ENABLETRUEIP   bool
		STREAMENHANCED bool

		AUTOGC     bool
		AUTOREBOOT bool
	}
)

func main() {
	go func() { http.ListenAndServe(":8080", nil) }()

	log.Printf("[APP] shadowsocks-ssrcloud v1.0.0")

	if err := nero(); err != nil {
		log.Printf("[APP] initialization failed: %v", err)
		return
	}

	for {
		if err := api.GetNodeInfo(); err != nil {
			log.Printf("[APP] get node info failed: %v", err)
			return
		}

		if err := UpdateUserBandwidth(); err != nil {
			log.Printf("[APP] update user bandwidth failed: %v", err)

			time.Sleep(time.Second * time.Duration(rand.Intn(10)))
			continue
		}

		if err := UpdateUserList(); err != nil {
			log.Printf("[APP] update user list failed: %v", err)

			time.Sleep(time.Second * time.Duration(rand.Intn(10)))
			continue
		}

		time.Sleep(flags.SYNCINTERVAL + (time.Second * time.Duration(rand.Intn(30))))
	}
}

func nero() (err error) {
	flags.NODEID = tools.GetInt64("NODEID", 1)
	flags.DBTYPE = os.Getenv("DBTYPE")
	flags.DBSPEC = os.Getenv("DBSPEC")
	flags.GROUPED = tools.GetBool("GROUPED", true)

	flags.SYNCINTERVAL = time.Second * time.Duration(tools.GetInt64("SYNCINTERVAL", 120))

	flags.LISN = os.Getenv("LISN")
	flags.DIAL = os.Getenv("DIAL")
	flags.SISO = tools.GetBool("SISO", false)

	flags.DNS = tools.Getenv("DNS", "1.1.1.1:53")
	flags.DNSTTL = tools.GetInt64("DNSTTL", 120)

	flags.TCP = tools.GetBool("TCP", true)
	flags.TCPBUFFERSIZE = tools.GetInt("TCPBUFFERSIZE", 1446)

	flags.UDP = tools.GetBool("UDP", true)
	flags.UDPTIMEOUT = time.Second * time.Duration(tools.GetInt64("UDPTIMEOUT", 30))
	flags.UDPBUFFERSIZE = tools.GetInt("UDPBUFFERSIZE", 1458)

	flags.ENABLETRUEIP = tools.GetBool("ENABLETRUEIP", false)
	flags.STREAMENHANCED = tools.GetBool("STREAMENHANCED", false)

	flags.AUTOGC = tools.GetBool("AUTOGC", false)
	flags.AUTOREBOOT = tools.GetBool("AUTOREBOOT", false)

	api.NODEID = flags.NODEID
	api.DBTYPE = flags.DBTYPE
	api.DBSPEC = flags.DBSPEC
	api.GROUPED = flags.GROUPED

	dns.DNS = flags.DNS
	dns.DNSTTL = flags.DNSTTL
	dns.Run()

	go clean()
	go reboot()
	return nil
}

func UpdateUserList() error {
	list, err := api.GetUserList()
	if err != nil {
		return fmt.Errorf("api.GetUserList: %v", err)
	}

	instanceLock.Lock()
	defer instanceLock.Unlock()

	for id, instance := range instanceList {
		ok := false

		for i := 0; i < len(list); i++ {
			if list[i].ID != id {
				continue
			}

			if !list[i].Equals(instance.UserInfo) {
				break
			}

			ok = true
		}

		if !ok {
			instance.Delete()
			instance = nil

			delete(instanceList, id)
		}
	}

	for i := 0; i < len(list); i++ {
		if _, ok := instanceList[list[i].ID]; !ok {
			instance, err := NewInstance(list[i])
			if err != nil {
				log.Printf("[APP] create instance failed: %v", err)
				continue
			}

			instance.Create()
			instanceList[list[i].ID] = instance
		}
	}

	return nil
}

func UpdateUserBandwidth() error {
	list := make(api.UserBandwidthList, 0)

	instanceLock.RLock()
	for id, instance := range instanceList {
		UP := instance.Bandwidth.GetUP()
		DL := instance.Bandwidth.GetDL()
		if UP <= 0 && DL <= 0 {
			continue
		}

		list = append(list, &api.UserBandwidth{
			ID: id,
			UP: UP,
			DL: DL,
		})
	}
	instanceLock.RUnlock()

	if err := api.UpdateUserBandwidthList(list); err != nil {
		return fmt.Errorf("api.UpdateUserBandwidthList: %v", err)
	}

	instanceLock.RLock()
	for i := 0; i < len(list); i++ {
		instanceList[list[i].ID].Bandwidth.DecreaseUP(list[i].UP)
		instanceList[list[i].ID].Bandwidth.DecreaseDL(list[i].DL)
	}
	instanceLock.RUnlock()
	return nil
}

func clean() {
	if !flags.AUTOGC {
		return
	}

	stats := runtime.MemStats{}
	for {
		time.Sleep(time.Minute * 30)

		runtime.GC()
		runtime.ReadMemStats(&stats)
		log.Printf("[GC] Fraction %f", stats.GCCPUFraction)
		log.Printf("[GC] Obtained %dMB", stats.Sys/1024/1024)
		log.Printf("[GC] Assigned %dMB", stats.Alloc/1024/1024)
		log.Printf("[GC] Routine %d", runtime.NumGoroutine())
	}
}

func reboot() {
	if !flags.AUTOREBOOT {
		return
	}

	zone := time.FixedZone("Asia/Shanghai", int((time.Hour * 8).Seconds()))
	date, err := time.ParseInLocation("2006-01-02", time.Now().In(zone).Format("2006-01-02"), zone)
	if err != nil {
		return
	}

	diff := date.AddDate(0, 0, 1).Add(time.Hour * 4).Add(time.Minute * 10).Sub(time.Now().In(zone))
	log.Printf("[REBOOT] Scheduled after %s", diff)

	time.Sleep(diff)
	time.Sleep(time.Second * time.Duration(rand.Intn(300)))
	os.Exit(0)
}
