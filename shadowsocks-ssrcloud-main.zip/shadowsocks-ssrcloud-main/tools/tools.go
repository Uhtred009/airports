package tools

import (
	"os"
	"strconv"
)

func Getenv(name string, value string) string {
	if v, ok := os.LookupEnv(name); ok {
		return v
	}

	return value
}

func GetBool(name string, value bool) bool {
	if v, ok := os.LookupEnv(name); ok {
		if i, err := strconv.ParseBool(v); err == nil {
			return i
		}
	}

	return value
}

func GetInt(name string, value int) int {
	if v, ok := os.LookupEnv(name); ok {
		if i, err := strconv.Atoi(v); err == nil {
			return i
		}
	}

	return value
}

func GetInt64(name string, value int64) int64 {
	if v, ok := os.LookupEnv(name); ok {
		if i, err := strconv.ParseInt(v, 10, 64); err == nil {
			return i
		}
	}

	return value
}
