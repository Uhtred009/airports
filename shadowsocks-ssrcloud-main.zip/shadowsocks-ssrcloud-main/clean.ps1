if ( Test-Path release ) {
    rm -Recurse -Force release
}

exit 0