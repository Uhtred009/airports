package main

import (
	"fmt"
	"net"
	"sync"

	"rixcloud.moe/shadowsocks/shadowsocks-ssrcloud/api"
	"rixcloud.moe/shadowsocks/shadowsocks/core"
)

var (
	instanceLock sync.RWMutex
	instanceList map[int64]*Instance = make(map[int64]*Instance)
)

type Instance struct {
	UserInfo  *api.UserInfo
	Bandwidth *Bandwidth

	cipher core.Cipher

	tcpSocket net.Listener
	udpSocket net.PacketConn
}

func NewInstance(info *api.UserInfo) (*Instance, error) {
	cipher, err := core.PickCipher(info.Method, nil, info.Passwd)
	if err != nil {
		return nil, fmt.Errorf("unsupported encrypt method: %s", info.Method)
	}

	return &Instance{
		UserInfo:  info,
		Bandwidth: NewBandwidth(),

		cipher: cipher,

		tcpSocket: nil,
		udpSocket: nil,
	}, nil
}

func (o *Instance) Create() {
	if o.tcpSocket == nil {
		go o.tcpListen()
	}

	if o.udpSocket == nil {
		go o.udpListen()
	}
}

func (o *Instance) Delete() {
	if o.tcpSocket != nil {
		o.tcpSocket.Close()
	}

	if o.udpSocket != nil {
		o.udpSocket.Close()
	}

	o.tcpSocket = nil
	o.udpSocket = nil
}
