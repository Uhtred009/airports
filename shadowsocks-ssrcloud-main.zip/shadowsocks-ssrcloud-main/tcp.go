package main

import (
	"io"
	"log"
	"net"
	"strconv"
	"time"

	"rixcloud.moe/shadowsocks/shadowsocks-ssrcloud/dns"
	"rixcloud.moe/shadowsocks/shadowsocks/socks"
)

func (o *Instance) tcpListen() {
	ln, err := net.Listen("tcp", net.JoinHostPort(flags.LISN, strconv.Itoa(o.UserInfo.Port)))
	if err != nil {
		log.Printf("[TCP][%d] net.Listen: %v", o.UserInfo.ID, err)
		return
	}
	o.tcpSocket = ln
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			return
		}

		go o.tcpHandle(client)
	}
}

func (o *Instance) tcpHandle(client net.Conn) {
	from := ""
	if flags.ENABLETRUEIP {
		trueip, err := socks.ReadAddr(client)
		if err != nil {
			client.Close()
			return
		}

		from = trueip.String()
	} else {
		from = client.RemoteAddr().String()
	}

	client = NewOBFS(client)
	client = o.cipher.StreamConn(client)
	defer client.Close()

	data := make([]byte, flags.TCPBUFFERSIZE)
	size, err := client.Read(data)
	if err != nil {
		return
	}

	target := socks.SplitAddr(data[:size])
	if target == nil {
		return
	}

	targetHost, targetPort, err := net.SplitHostPort(target.String())
	if err != nil {
		return
	}

	targetIP, err := dns.Fetch(targetHost)
	if err != nil {
		return
	}

	dialer := net.Dialer{
		Timeout:   time.Second * 10,
		KeepAlive: time.Second * 10,
	}
	if flags.SISO {
		addr, _, _ := net.SplitHostPort(client.LocalAddr().String())

		dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(addr)}
	} else if flags.DIAL != "" {
		dialer.LocalAddr = &net.TCPAddr{IP: net.ParseIP(flags.DIAL)}
	}

	remote, err := dialer.Dial("tcp", net.JoinHostPort(targetIP.String(), targetPort))
	if err != nil {
		return
	}
	defer remote.Close()

	log.Printf("[TCP][%d] %s <-> %s (%s)", o.UserInfo.ID, from, target, targetIP)

	if _, err = remote.Write(data[len(target):size]); err != nil {
		return
	}
	data = nil

	tcpPipe(o, client, remote)
}

func tcpPipe(instance *Instance, client, remote net.Conn) {
	channel := make(chan int, 1)
	UP := int64(0)
	DL := int64(0)

	go func() {
		UP, _ = io.CopyBuffer(remote, client, make([]byte, flags.TCPBUFFERSIZE))
		client.SetDeadline(time.Now())
		remote.SetDeadline(time.Now())

		channel <- 1
	}()

	DL, _ = io.CopyBuffer(client, remote, make([]byte, flags.TCPBUFFERSIZE))
	client.SetDeadline(time.Now())
	remote.SetDeadline(time.Now())

	<-channel
	instance.Bandwidth.IncreaseUP(UP)
	instance.Bandwidth.IncreaseDL(DL)
}
