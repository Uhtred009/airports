package main

import (
	"log"
	"net"
	"strconv"
	"sync"
	"time"

	"rixcloud.moe/shadowsocks/shadowsocks-ssrcloud/dns"
	"rixcloud.moe/shadowsocks/shadowsocks/socks"
)

func (o *Instance) udpListen() {
	ln, err := net.ListenPacket("udp", net.JoinHostPort(flags.LISN, strconv.Itoa(o.UserInfo.Port)))
	if err != nil {
		log.Printf("[UDP][%d] net.ListenPacket: %v", o.UserInfo.ID, err)
		return
	}
	ln = o.cipher.PacketConn(ln)
	o.udpSocket = ln
	defer ln.Close()

	nm := NewNAT()
	buffer := make([]byte, flags.UDPBUFFERSIZE)

	for {
		size, from, err := ln.ReadFrom(buffer)
		if err != nil {
			return
		}
		o.Bandwidth.IncreaseUP(int64(size))

		target := socks.SplitAddr(buffer[:size])
		if target == nil {
			continue
		}

		targetHost, targetPort, err := net.SplitHostPort(target.String())
		if err != nil {
			continue
		}

		targetIP, err := dns.Fetch(targetHost)
		if err != nil {
			continue
		}

		targetAddr, err := net.ResolveUDPAddr("udp", net.JoinHostPort(targetIP.String(), targetPort))
		if err != nil {
			continue
		}

		remote := nm.Get(from.String())
		if remote == nil {
			addr := ""
			if flags.SISO && flags.LISN != "" {
				addr = flags.LISN
			} else if flags.DIAL != "" {
				addr = flags.DIAL
			}

			remote, err = net.ListenPacket("udp", net.JoinHostPort(addr, ""))
			if err != nil {
				continue
			}
			nm.Create(o, remote, ln, from)

			log.Printf("[UDP][%d] %s <-> %s (%s)", o.UserInfo.ID, from, target, targetIP)
		}

		remote.WriteTo(buffer[len(target):size], targetAddr)
	}
}

type NAT struct {
	sync.RWMutex

	m map[string]net.PacketConn
}

func NewNAT() *NAT {
	return &NAT{m: make(map[string]net.PacketConn)}
}

func (o *NAT) Get(id string) net.PacketConn {
	o.RLock()
	defer o.RUnlock()

	return o.m[id]
}

func (o *NAT) Set(id string, conn net.PacketConn) {
	o.Lock()
	defer o.Unlock()

	o.m[id] = conn
}

func (o *NAT) Create(instance *Instance, src, dst net.PacketConn, target net.Addr) {
	o.Set(target.String(), src)

	go func() {
		udpPipe(instance, src, dst, target)
		if conn := o.Delete(target.String()); conn != nil {
			conn.Close()
		}
	}()
}

func (o *NAT) Delete(id string) net.PacketConn {
	o.Lock()
	defer o.Unlock()

	conn, ok := o.m[id]
	if ok {
		delete(o.m, id)

		return conn
	}

	return nil
}

func udpPipe(instance *Instance, src, dst net.PacketConn, target net.Addr) {
	buffer := make([]byte, flags.UDPBUFFERSIZE)

	for {
		src.SetReadDeadline(time.Now().Add(flags.UDPTIMEOUT))
		size, from, err := src.ReadFrom(buffer)
		if err != nil {
			break
		}
		instance.Bandwidth.IncreaseDL(int64(size))

		source := socks.ParseAddr(from.String())
		length := len(source) + size
		if length > flags.UDPBUFFERSIZE {
			continue
		}

		copy(buffer[len(source):], buffer[:size])
		copy(buffer, source)

		if _, err = dst.WriteTo(buffer[:length], target); err != nil {
			break
		}
	}
}
