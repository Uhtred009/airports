package dns

import (
	"errors"
	"fmt"
	"net"
	"sync"
	"time"

	"github.com/miekg/dns"
)

var (
	DNS    string = "1.1.1.1:53"
	DNSTTL int64  = 120

	list   = &sync.Map{}
	client = &dns.Client{}
)

type DNSRecord struct {
	Unix int64

	IPv4 []net.IP
	IPv6 []net.IP
}

func (o *DNSRecord) Get() net.IP {
	if len(o.IPv4) != 0 {
		return o.IPv4[0]
	}

	if len(o.IPv6) != 0 {
		return o.IPv6[0]
	}

	return nil
}

func rawFetch(name uint16, value string) ([]net.IP, error) {
	m := dns.Msg{}
	m.SetQuestion(value, name)

	i, _, err := client.Exchange(&m, DNS)
	if err != nil {
		return nil, fmt.Errorf("client.Exchange: %v", err)
	}

	ips := make([]net.IP, 0)
	for _, rr := range i.Answer {
		if name == dns.TypeA {
			if answer, ok := rr.(*dns.A); ok {
				ips = append(ips, answer.A)
			}
		}

		if name == dns.TypeAAAA {
			if answer, ok := rr.(*dns.AAAA); ok {
				ips = append(ips, answer.AAAA)
			}
		}
	}

	return ips, nil
}

func fetch(name string) (*DNSRecord, error) {
	v, ok := list.Load(name)
	if ok {
		return v.(*DNSRecord), nil
	}

	ipv4, ipv4err := rawFetch(dns.TypeA, name)
	ipv6, ipv6err := rawFetch(dns.TypeAAAA, name)

	if ipv4err != nil && ipv6err != nil {
		if ipv4err != nil {
			return nil, fmt.Errorf("rawFetch: %v", ipv4err)
		}

		if ipv6err != nil {
			return nil, fmt.Errorf("rawFetch: %v", ipv6err)
		}
	}

	if len(ipv4) == 0 && len(ipv6) == 0 {
		return nil, errors.New("no ip resolved")
	}

	v = &DNSRecord{
		Unix: time.Now().Unix(),
		IPv4: ipv4,
		IPv6: ipv6,
	}

	list.Store(name, v)
	return v.(*DNSRecord), nil
}

func Run() {
	go func() {
		for {
			time.Sleep(time.Second * 120)

			last := time.Now().Unix()
			list.Range(func(k, v interface{}) bool {
				if last-v.(*DNSRecord).Unix >= DNSTTL {
					list.Delete(k)
				}

				return true
			})
		}
	}()
}

func Fetch(name string) (net.IP, error) {
	if addr := net.ParseIP(name); addr != nil {
		return addr, nil
	}

	data, err := fetch(dns.Fqdn(name))
	if err != nil {
		return nil, fmt.Errorf("fetch: %v", err)
	}

	return data.Get(), nil
}
