package main

import (
	"io"
	"log"
	"net"
	"strconv"
	"time"

	"github.com/juju/ratelimit"
	"rixcloud.moe/shadowsocks/shadowsocks/socks"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-amy/adns"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-amy/alive"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-amy/alog"
	"rixcloud.moe/shadowsocks/shadowsocksr-sm-amy/audit"
)

func tcpServe(addr net.IP) {
	if !flags.TCP {
		return
	}

	for {
		tcpListen(addr)

		time.Sleep(time.Second * 4)
	}
}

func tcpListen(addr net.IP) {
	ln, err := net.Listen("tcp", net.JoinHostPort(addr.String(), strconv.Itoa(flags.Port)))
	if err != nil {
		log.Printf("[TCP] net.Listen: %v", err)
		return
	}
	defer ln.Close()

	for {
		client, err := ln.Accept()
		if err != nil {
			log.Printf("[TCP] ln.Accept: %v", err)
		}

		go tcpHandle(client, addr)
	}
}

func tcpHandle(client net.Conn, addr net.IP) {
	from := ""
	if flags.EnableTrueIP {
		trueip, err := socks.ReadAddr(client)
		if err != nil {
			client.Close()
			return
		}

		from = trueip.String()
	} else {
		from = client.RemoteAddr().String()
	}

	client = instanceCipher.StreamConn(client)
	client = newTCPOBFS(client)
	defer client.Close()

	data := make([]byte, flags.TCPBufferSize)
	size, err := client.Read(data)
	if err != nil {
		return
	}

	target := socks.SplitAddr(data[:size])
	if target == nil {
		return
	}

	targetHost, targetPort, err := net.SplitHostPort(target.String())
	if err != nil {
		return
	}

	instanceMutex.RLock()
	instance := instanceList[client.(*TCPOBFS).UserID]
	instanceMutex.RUnlock()

	if alive.Scan(instance.UserInfo.ID, from) {
		return
	}

	if audit.Scan(instance.UserInfo.ID, data[:size]) {
		return
	}

	adtr, err := adns.FetchOne(targetHost)
	if err != nil {
		return
	}

	dialer := net.Dialer{
		Timeout:   time.Second * 10,
		KeepAlive: time.Second * 10,
	}
	if flags.SISO {
		dialer.LocalAddr = &net.TCPAddr{IP: addr, Port: 0}
	}

	remote, err := dialer.Dial("tcp", net.JoinHostPort(adtr.String(), targetPort))
	if err != nil {
		return
	}
	defer remote.Close()

	if _, err := remote.Write(data[len(target):size]); err != nil {
		return
	}
	data = nil

	log.Printf("[IN][%d] New TCP connection from %s → %s:%s", instance.UserInfo.ID, from, targetHost, targetPort)
	tcpRelay(instance, client, remote, alog.Rule{
		UserID: int64(instance.UserInfo.ID),
		Server: remote.LocalAddr().String(),
		Client: from,
		Target: net.JoinHostPort(targetHost, targetPort),
		Create: time.Now().Unix(),
	})
}

func tcpRelay(instance *Instance, client, remote net.Conn, data alog.Rule) {
	go func() {
		var reader io.Reader
		if instance.UPBucket != nil {
			reader = ratelimit.Reader(client, instance.UPBucket)
		} else {
			reader = client
		}

		size, _ := io.CopyBuffer(remote, reader, make([]byte, flags.TCPBufferSize))
		_ = client.SetDeadline(time.Now())
		_ = remote.SetDeadline(time.Now())
		instance.Bandwidth.IncreaseUP(int64(float64(size) * flags.UPExternalRate))
	}()

	var reader io.Reader
	if instance.DLBucket != nil {
		reader = ratelimit.Reader(remote, instance.DLBucket)
	} else {
		reader = remote
	}

	size, _ := io.CopyBuffer(client, reader, make([]byte, flags.TCPBufferSize))
	_ = client.SetDeadline(time.Now())
	_ = remote.SetDeadline(time.Now())
	instance.Bandwidth.IncreaseDL(int64(float64(size) * flags.DLExternalRate))

	data.Length = size
	data.Finish = time.Now().Unix()
	alog.Set(data)
}
