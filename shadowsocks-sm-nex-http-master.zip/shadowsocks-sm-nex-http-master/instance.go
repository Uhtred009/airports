package main

import (
	"github.com/juju/ratelimit"

	api "rixcloud.moe/shadowsocks/nex-api"
)

type InstanceList map[string]*Instance
type Instance struct {
	UserInfo  api.UserInfo
	Bandwidth *Bandwidth
	DLBucket  *ratelimit.Bucket
	UPBucket  *ratelimit.Bucket
}

func newInstance(data api.UserInfo) *Instance {
	var aBucket *ratelimit.Bucket
	if flags.ForceUPSpeedLimit > 0 {
		aBucket = ratelimit.NewBucketWithRate(1024*128*float64(flags.ForceUPSpeedLimit), 1024*128*int64(flags.ForceUPSpeedLimit))
	} else if data.UPSpeed > 0 {
		aBucket = ratelimit.NewBucketWithRate(1024*128*float64(data.UPSpeed), 1024*128*int64(data.UPSpeed))
	}

	var xBucket *ratelimit.Bucket
	if data.DLSpeed > 0 {
		xBucket = ratelimit.NewBucketWithRate(1024*128*float64(data.DLSpeed), 1024*128*int64(data.DLSpeed))
	} else if flags.ForceDLSpeedLimit > 0 {
		xBucket = ratelimit.NewBucketWithRate(1024*128*float64(flags.ForceDLSpeedLimit), 1024*128*int64(flags.ForceDLSpeedLimit))
	}

	instance := new(Instance)
	instance.UserInfo = data
	instance.Bandwidth = newBandwidth()
	instance.UPBucket = aBucket
	instance.DLBucket = xBucket
	return instance
}
