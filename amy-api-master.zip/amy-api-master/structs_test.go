package api

import (
	"crypto/md5"
	"testing"
)

func Test(t *testing.T) {
	info := UserInfo{
		ID:     0,
		Port:   114514,
		Passwd: "LWEoRzDZPQ",
		Speed:  0,
	}

	t.Logf("ID         => %d", info.ID)
	t.Logf("Port       => %d", info.Port)
	t.Logf("Passwd     => %s", info.Passwd)
	t.Logf("Speed      => %d", info.Speed)
	t.Logf("Passwd MD5 => %x", md5.Sum([]byte(info.Passwd)))
	t.Logf("Suffix     => %s", Suffix)
	t.Logf("Prefix     => %s", Prefix)
	t.Logf("Output     => %s", info.Get())
}
