package api

import (
	"crypto/md5"
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

type Audit struct {
	ID   int
	Name string
	Text string

	Compiled *regexp.Regexp
}
type AuditList []Audit

type AuditInfo struct {
	UserID int
	RuleID int
}
type AuditInfoList []AuditInfo

type AliveInfo struct {
	UserID int
	IP     string
}
type AliveInfoList []AliveInfo

type ProhibitInfo struct {
	UserID int
	IP     string
}
type ProhibitList []ProhibitInfo

type UserInfo struct {
	ID      int
	Port    uint32
	Passwd  string
	UPSpeed int
	DLSpeed int
}
type UserList []UserInfo

func (o *UserInfo) Get() string {
	text := strings.Replace(Prefix, "%suffix", Suffix, -1)
	text = strings.Replace(text, "%id", fmt.Sprintf("%d", o.ID), -1)
	text = strings.Replace(text, "%port", fmt.Sprintf("%d", o.Port), -1)
	text = strings.Replace(text, "%passwd", o.Passwd, -1)
	checksum := md5.Sum([]byte(o.Passwd))

	regex := regexp.MustCompile(`"|%-?[1-9]\d*m|U"`)
	for _, checked := range regex.FindAllString(text, -1) {
		size, _ := strconv.Atoi(strings.Replace(strings.Replace(checked, "%", "", -1), "m", "", -1))

		text = strings.Replace(text, checked, fmt.Sprintf("%x", checksum)[:size], 1)
	}

	return text
}

type UserBandwidth struct {
	ID int
	UP int64
	DL int64
}
type UserBandwidthList []UserBandwidth
