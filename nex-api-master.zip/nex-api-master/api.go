package api

import (
	"database/sql"
	"fmt"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

var (
	DBHost string
	DBPort int
	DBUser string
	DBPass string
	DBName string

	Suffix string = "microsoft.com"
	Prefix string = "%passwd.%suffix"

	APIOut time.Duration = time.Second * 30
)

func newConn() (*sql.DB, error) {
	db, err := sql.Open("mysql", fmt.Sprintf("%s:%s@tcp(%s:%d)/%s", DBUser, DBPass, DBHost, DBPort, DBName))
	if err != nil {
		return nil, err
	}
	db.SetConnMaxLifetime(APIOut)
	db.SetMaxIdleConns(4)
	db.SetMaxOpenConns(8)

	return db, nil
}

func GetAuditList() (AuditList, error) {
	client, err := newConn()
	if err != nil {
		return nil, err
	}
	defer client.Close()

	results, err := client.Query("SELECT id, name, text FROM audit_rule")
	if err != nil {
		return nil, err
	}
	defer results.Close()

	list := make(AuditList, 0)
	for results.Next() {
		var item Audit

		err = results.Scan(&item.ID, &item.Name, &item.Text)
		if err != nil {
			return nil, err
		}

		list = append(list, item)
	}

	return list, nil
}

func GetProhibitList() (ProhibitList, error) {
	client, err := newConn()
	if err != nil {
		return nil, err
	}
	defer client.Close()

	results, err := client.Query("SELECT mid, ip FROM block_ip")
	if err != nil {
		return nil, err
	}
	defer results.Close()

	list := make(ProhibitList, 0)
	for results.Next() {
		var item ProhibitInfo

		err = results.Scan(&item.UserID, &item.IP)
		if err != nil {
			return nil, err
		}

		list = append(list, item)
	}

	return list, nil
}

func GetUserList() (UserList, error) {
	client, err := newConn()
	if err != nil {
		return nil, err
	}
	defer client.Close()

	results, err := client.Query("SELECT mid, port, passwd, upmaxspeed, downmaxspeed FROM user WHERE u+d<transfer_enable AND enable=1")
	if err != nil {
		return nil, err
	}
	defer results.Close()

	list := make(UserList, 0)
	for results.Next() {
		var item UserInfo

		err = results.Scan(&item.ID, &item.Port, &item.Passwd, &item.UPSpeed, &item.DLSpeed)
		if err != nil {
			return nil, err
		}

		list = append(list, item)
	}

	return list, nil
}

func Update(list UserBandwidthList) error {
	if len(list) == 0 {
		return nil
	}

	client, err := newConn()
	if err != nil {
		return err
	}
	defer client.Close()

	when1 := ""
	when2 := ""
	in := ""

	for i := 0; i < len(list); i++ {
		when1 += fmt.Sprintf(" WHEN %d THEN u+%d", list[i].ID, list[i].UP)
		when2 += fmt.Sprintf(" WHEN %d THEN d+%d", list[i].ID, list[i].DL)

		if in != "" {
			in += fmt.Sprintf(", %d", list[i].ID)
		} else {
			in = fmt.Sprintf("%d", list[i].ID)
		}
	}

	if _, err := client.Exec(fmt.Sprintf("UPDATE user SET u = CASE mid %s END, d = CASE mid %s END, t = %d WHERE mid IN (%s)", when1, when2, time.Now().Unix(), in)); err != nil {
		return err
	}

	return nil
}

func UpdateAliveInfoList(list AliveInfoList) error {
	if len(list) == 0 {
		return nil
	}

	client, err := newConn()
	if err != nil {
		return err
	}
	defer client.Close()

	in := ""
	for i := 0; i < len(list); i++ {
		if in == "" {
			in = fmt.Sprintf(`(%d, "%s")`, list[i].UserID, list[i].IP)
		} else {
			in += fmt.Sprintf(`, (%d, "%s")`, list[i].UserID, list[i].IP)
		}
	}

	if _, err := client.Exec(fmt.Sprintf("INSERT INTO alive_ip (mid, ip) VALUES %s", in)); err != nil {
		return err
	}

	return nil
}

func UpdateAuditInfoList(list AuditInfoList) error {
	if len(list) == 0 {
		return nil
	}

	client, err := newConn()
	if err != nil {
		return err
	}
	defer client.Close()

	in := ""
	for i := 0; i < len(list); i++ {
		if in == "" {
			in = fmt.Sprintf("(%d, %d)", list[i].UserID, list[i].RuleID)
		} else {
			in += fmt.Sprintf(", (%d, %d)", list[i].UserID, list[i].RuleID)
		}
	}

	if _, err := client.Exec(fmt.Sprintf("INSERT INTO audit_log (mid, rid) VALUES %s", in)); err != nil {
		return err
	}

	return nil
}
